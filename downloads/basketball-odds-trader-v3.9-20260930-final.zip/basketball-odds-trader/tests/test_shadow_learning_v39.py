import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import sys

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

from repair_v22.model import POLICY, _history_weight_profile
from repair_v22.pace_evidence import derive_possessions_from_box_score
from repair_v22.shadow_learning import (annotate_decision, freeze_learning_records,
                                         settle_learning_records, build_shadow_learning_analytics)


class PaceFallbackTests(unittest.TestCase):
    def test_complete_box_score_is_level_b(self):
        result = derive_possessions_from_box_score([
            {"FGA": 80, "FTA": 20, "ORB": 10, "TOV": 12},
            {"FGA": 78, "FTA": 18, "ORB": 9, "TOV": 11},
        ])
        self.assertEqual(result["possessions_level"], "LEVEL_B")
        self.assertEqual(result["pace_source"], "DERIVED_BOX_SCORE")
        self.assertAlmostEqual(result["team_possessions_estimates"][0], 90.8)

    def test_missing_orb_or_tov_never_raises_and_downgrades(self):
        rows = [{"FGA": 80, "FTA": 20, "TOV": 12}, {"FGA": 78, "FTA": 18, "ORB": 9}]
        result = derive_possessions_from_box_score(rows)
        self.assertEqual(result["possessions_level"], "LEVEL_D")
        self.assertIn("TEAM_1_ORB_MISSING", result["missing_fields"])
        self.assertIn("TEAM_2_TOV_MISSING", result["missing_fields"])
        prior = derive_possessions_from_box_score(rows, 72.5)
        self.assertEqual(prior["possessions_level"], "LEVEL_C")


class EssPerformanceTests(unittest.TestCase):
    def test_weight_profile_is_in_memory_and_has_weighted_diversity(self):
        games = []
        for i, opponent in enumerate(("X", "Y", "Z", "X"), 1):
            games.append({"event_id": f"a{i}", "team1_id": "A", "team2_id": opponent,
                          "tip_at": f"2026-09-{i:02d}T00:00:00+00:00"})
            games.append({"event_id": f"b{i}", "team1_id": "B", "team2_id": opponent,
                          "tip_at": f"2026-09-{i + 4:02d}T00:00:00+00:00"})
        relations = {g["event_id"]: "NATIVE" for g in games}
        with patch.object(Path, "read_text", side_effect=AssertionError("history loop performed file I/O")):
            profile = _history_weight_profile(games, ("A", "B"), "2026-09-20T00:00:00+00:00",
                                              POLICY["CLUB_MATURE"], relations, False)
        self.assertGreater(profile["history_ess"], 0)
        self.assertGreater(profile["effective_opponent_diversity"], 2)


class ProvisionalIsolationTests(unittest.TestCase):
    def event(self):
        return {"event_id": "g1", "team1_id": "A", "team2_id": "B", "team1_name": "A", "team2_name": "B",
                "tip_at": "2026-10-01T12:00:00+00:00", "bj_date": "2026-10-01", "league": "Tier 3",
                "competition_key": "CZECH_NBL"}

    def test_provisional_ledger_and_pnl_are_separate(self):
        pricing = {"mu_raw": 4.0, "total_raw": 160.0, "history_ess": 6.2,
                   "effective_opponent_diversity": 2.4, "total_diagnostic": {"evidence_level": "LEVEL_C"}}
        market = {"comparison_ready": True, "model_state": "EDGE", "triggered": False,
                  "blockers": ["ROSTER_STABILITY_MISSING"], "uncertainty_flags": [],
                  "selected": {"quote_id": "q1", "market_type": "SPREAD", "selection": "TEAM1", "line": -2.5,
                               "decimal_odds": 1.91, "bookmaker": "Book", "ot_rule": "INCLUDING_OT",
                               "p_win": .58, "p_loss": .42, "ev": .10, "adverse_ev": .04,
                               "research_edge_pass": True}}
        decision = {"prediction_id": "p1", "event_id": "g1", "asof": "2026-10-01T00:00:00+00:00",
                    "archive_type": "FORWARD_NATIVE", "blockers": ["ROSTER_STABILITY_MISSING"],
                    "market_decisions": {"SPREAD": market}, "forecast_fingerprint": "abc"}
        annotation = annotate_decision(self.event(), pricing, decision)
        self.assertEqual(annotation["markets"]["SPREAD"]["shadow_level"], "PROVISIONAL_SHADOW")
        self.assertFalse(annotation["markets"]["SPREAD"]["strategy_return_eligible"])
        with tempfile.TemporaryDirectory() as tmp:
            records = freeze_learning_records(tmp, "run1", self.event(), pricing, decision)
            self.assertEqual(len(records), 1)
            fact = {"event_id": "g1", "team1_id": "A", "team2_id": "B", "status": "FINAL",
                    "known_final_at": "2026-10-01T15:00:00+00:00", "score1_full": 90, "score2_full": 80,
                    "score1_regulation": 90, "score2_regulation": 80}
            settle_learning_records(tmp, [fact], "2026-10-01T16:00:00+00:00")
            settlement = next((Path(tmp) / "ledger" / "repair_v22_provisional_settlements").glob("*.json")).read_text(encoding="utf-8")
            self.assertIn('"provisional_pnl"', settlement)
            self.assertIn('"paper_pnl": null', settlement)
            analytics = build_shadow_learning_analytics(tmp, "2026-10-01T16:00:00+00:00", {"execution_records": []})
            self.assertTrue(analytics["ledger_isolation"]["passed"])
            self.assertEqual(analytics["QUALIFIED_SHADOW"]["N"], 0)
            self.assertEqual(analytics["PROVISIONAL_SHADOW"]["N"], 1)


if __name__ == "__main__":
    unittest.main()
