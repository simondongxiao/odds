from __future__ import annotations
import math
import yaml
from collections import Counter, defaultdict
from datetime import timedelta
from pathlib import Path
from statistics import median
from .common import iso, stamp, fingerprint, competition_key, load
from .verified_core import _ridge, t_cdf, threshold_probability, ev_and_kelly, display_fair_margin, margin_cdf
from .tier_policy import tier_for, evaluation_channel
from .score_context import build_score_context
from .evidence_context import evaluate_tier3_roster_stability

MODEL_VERSION='score-ridge-production-2.3.0'
MARKET_INTEGRITY=load(Path(__file__).resolve().parents[2]/'config'/'market_integrity.json',{
 'minimum_fresh_main_quotes':2,'max_deviation_from_cross_book_median':{'SPREAD':4.0,'TOTAL':8.0}})
POLICY={
 'CLUB_MATURE':dict(min_games=3,max_days=550,half_life=90,ridge=8,sd_margin=13,sd_total=18,df=7,mean_margin=2,mean_total=3,buffer=.025),
 'NATIONAL_TEAM':dict(min_games=3,max_days=730,half_life=180,ridge=12,sd_margin=16,sd_total=20,df=6,mean_margin=3,mean_total=4,buffer=.045),
 'HIGH_UNCERTAINTY':dict(min_games=3,max_days=180,half_life=45,ridge=16,sd_margin=19,sd_total=25,df=5,mean_margin=4,mean_total=5,buffer=.08)}


def _cold_start_config():
    path = Path(__file__).resolve().parents[2] / 'config' / 'cold_start_pricing.yaml'
    try:
        return yaml.safe_load(path.read_text(encoding='utf-8')) or {}
    except (OSError, yaml.YAMLError):
        return {}


COLD_START = _cold_start_config()


def _total_evidence_policy():
    path = Path(__file__).resolve().parents[2] / 'config' / 'total_evidence_policy.yaml'
    try:
        return yaml.safe_load(path.read_text(encoding='utf-8')) or {}
    except (OSError, yaml.YAMLError):
        return {}


TOTAL_EVIDENCE_POLICY = _total_evidence_policy()


def _bootstrap_match(event, game):
    """Return a conservative bootstrap relation, never a generic label match.

    H2H rows are deliberately excluded. Cross-season and cross-competition
    borrowing is restricted to TEAM_HISTORY rows with the same gender and a
    recognized competition family (or a national-team window).
    """
    if game.get('evidence_kind') != 'TEAM_HISTORY' or game.get('gender') != event.get('gender'):
        return None
    if competition_match(event, game):
        return 'CANONICAL_SOURCE_LABEL'
    family = str(event.get('model_family') or '')
    ekey = str(event.get('competition_key') or competition_key(event.get('league'), event.get('gender')) or '')
    gkey = str(game.get('competition_key') or competition_key(game.get('league'), game.get('gender')) or '')
    if family == 'NATIONAL_TEAM':
        return 'NATIONAL_WINDOW' if ekey or gkey else None
    professional = {
        'NBA', 'WNBA', 'EUROLEAGUE', 'EUROCUP', 'EUROLEAGUE_WOMEN',
        'EUROCUP_WOMEN', 'FIBA_EUROPE_CUP', 'ENBL', 'EUROPE_DOMESTIC',
        'AUSTRALIA_NBL', 'AUSTRALIA_WNBL', 'JAPAN_BLEAGUE', 'KOREA_KBL',
        'CBA_REGULAR', 'CBA_PLAYOFF', 'B_LEAGUE',
    }
    if family in ('CLUB_MATURE', 'HIGH_UNCERTAINTY') and ekey in professional and gkey in professional:
        return 'CROSS_COMPETITION_ADJUSTED'
    return None


def _season_bucket(game, cutoff):
    age = max(0.0, (iso(cutoff) - iso(game['tip_at'])).total_seconds() / 86400.0)
    if age <= 180:
        return 'current_season'
    if age <= 450:
        return 'previous_season'
    return 'older_history'


def _competition_adjustment(relation, game):
    if relation == 'NATIONAL_WINDOW':
        key = 'NATIONAL_WINDOW'
    elif relation == 'CROSS_COMPETITION_ADJUSTED':
        label = str(game.get('competition_key') or game.get('league') or '').lower()
        key = 'CUP' if any(x in label for x in ('cup', '杯')) else 'TIER2_DOMESTIC'
    elif relation == 'CANONICAL_SOURCE_LABEL':
        key = 'SAME_COMPETITION'
    else:
        key = 'UNKNOWN'
    return key, float((COLD_START.get('competition_adjustments') or {}).get(key, 0.55))


def _bootstrap_history(event, history, cutoff, mode, native, rejections):
    """Add only time-valid TEAM_HISTORY facts for cold-start research."""
    c = iso(cutoff)
    p = POLICY[event['model_family']]
    max_age = float((COLD_START.get('thresholds') or {}).get('max_age_days', 730))
    added = []
    relations = {}
    native_ids = {g['event_id'] for g in native}
    for g in history:
        if g.get('event_id') in native_ids:
            relations[g['event_id']] = 'NATIVE'
            continue
        reason = None
        relation = _bootstrap_match(event, g)
        if g.get('event_id') == event.get('event_id'):
            reason = 'TARGET_GAME_EXCLUDED'
        elif not relation:
            reason = 'BOOTSTRAP_COMPETITION_MISMATCH'
        elif g.get('status') != 'FINAL':
            reason = 'NOT_CONFIRMED_FINAL'
        elif iso(g['tip_at']) >= c:
            reason = 'NOT_BEFORE_CUTOFF'
        elif (c - iso(g['tip_at'])).total_seconds() / 86400.0 > max_age:
            reason = 'BOOTSTRAP_HISTORY_TOO_OLD'
        elif mode == 'FORWARD_NATIVE' and (not g.get('known_final_at') or iso(g['known_final_at']) > c):
            reason = 'FINAL_NOT_OBSERVED_BY_CUTOFF'
        elif mode == 'RECONSTRUCTED_SCORE_ONLY' and iso(g['tip_at']) + timedelta(hours=24) > c:
            reason = 'RECONSTRUCTION_24H_AVAILABILITY_BUFFER'
        if reason:
            rejections[reason] = rejections.get(reason, 0) + 1
            continue
        relations[g['event_id']] = relation
        added.append(g)
    byid = {g['event_id']: g for g in native}
    for g in added:
        old = byid.get(g['event_id'])
        if old and any(old.get(k) != g.get(k) for k in ('team1_id', 'team2_id', 'score1_full', 'score2_full', 'tip_at')):
            rejections['CONFLICTING_SCORE_FACT'] += 1
            continue
        byid[g['event_id']] = g
    return sorted(byid.values(), key=lambda g: g['tip_at']), relations


def _effective_sample_size(games, targets, cutoff, policy, relations, bootstrap_used):
    if not bootstrap_used:
        weights = [2 ** (-max(0, (iso(cutoff) - iso(g['tip_at'])).total_seconds() / 86400) / policy['half_life']) for g in games]
    else:
        source_weights = COLD_START.get('source_weights') or {}
        weights = []
        for g in games:
            relation = relations.get(g['event_id'], 'UNKNOWN')
            season = _season_bucket(g, cutoff)
            _, competition_weight = _competition_adjustment(relation, g)
            age_weight = 2 ** (-max(0, (iso(cutoff) - iso(g['tip_at'])).total_seconds() / 86400) / policy['half_life'])
            weights.append(age_weight * float(source_weights.get(season, 0.3)) * competition_weight)
    by_team = {}
    for team in targets:
        ws = [w for w, g in zip(weights, games) if team in (g['team1_id'], g['team2_id'])]
        total = sum(ws)
        by_team[team] = (total * total / sum(w * w for w in ws)) if ws else 0.0
    return min(by_team.values(), default=0.0), by_team, weights

def total_diagnostic(event,games,context,policy,predictive_spread=None,scale_multiplier=1.0):
    """Expose total evidence with hard blockers separated from soft missing data."""
    score_context = build_score_context(event, games, context.get('cutoff_at') or event.get('tip_at'))
    totals=[g['score1_full']+g['score2_full'] for g in games]
    target_ids={event.get('team1_id'),event.get('team2_id')}
    q4_close=[];q4_blowout=[]
    for g in games:
        if not target_ids.intersection((g.get('team1_id'),g.get('team2_id'))):continue
        p1,p2=g.get('period_points_team1'),g.get('period_points_team2')
        if not (isinstance(p1,list) and isinstance(p2,list) and len(p1)>=4 and len(p2)>=4):continue
        q4_total=p1[3]+p2[3];margin_before_q4=abs(sum(p1[:3])-sum(p2[:3]))
        if margin_before_q4<=8:q4_close.append(q4_total)
        elif margin_before_q4>=15:q4_blowout.append(q4_total)
    hard_blockers=[];soft_missing=[]
    if not event.get('game_minutes'):hard_blockers.append('GAME_RULE_UNKNOWN')
    evidence_level=str(context.get('possessions_level') or '')
    if not context.get('possessions_verified') and evidence_level not in ('LEVEL_A','LEVEL_B','LEVEL_C'):
        hard_blockers.append('POSSESSIONS_EVIDENCE_MISSING')
    if not context.get('basic_offense_verified') and not games:
        hard_blockers.append('BASIC_OFFENSE_EVIDENCE_MISSING')
    if not context.get('injury_verified'):soft_missing.append('INJURY_UNKNOWN')
    if not context.get('roster_verified'):soft_missing.append('ROTATION_UNKNOWN')
    if not context.get('three_point_verified'):soft_missing.append('THREE_POINT_PROFILE_UNKNOWN')
    if not context.get('late_foul_verified'):soft_missing.append('LATE_FOUL_ENVIRONMENT_UNKNOWN')
    if len(q4_close)<3:soft_missing.append('CLOSE_GAME_Q4_SAMPLE_INSUFFICIENT')
    if len(q4_blowout)<3:soft_missing.append('GARBAGE_TIME_Q4_SAMPLE_INSUFFICIENT')
    close_game_probability=None
    if predictive_spread is not None:
        adjusted_margin_sd=policy['sd_margin']*scale_multiplier
        close_game_probability=t_cdf(4.5,predictive_spread,adjusted_margin_sd,policy['df'])-t_cdf(-4.5,predictive_spread,adjusted_margin_sd,policy['df'])
    close_game_expected=bool(predictive_spread is not None and abs(float(predictive_spread))<=4.5)
    if close_game_expected and not context.get('ot_premium_verified'):soft_missing.append('OT_PREMIUM_UNAVAILABLE')
    execution_eligible=not hard_blockers
    total_adjustment = None
    if not close_game_expected:
        total_adjustment = 0.0
    elif context.get('late_foul_verified') and context.get('ot_premium_verified'):
        try:
            total_adjustment = float(context['late_foul_premium']) + float(context['ot_premium'])
        except (KeyError, TypeError, ValueError):
            hard_blockers.append('CLOSE_GAME_PREMIUM_VALUE_INVALID')
            execution_eligible = False
    soft_policy=TOTAL_EVIDENCE_POLICY.get('soft_missing_uncertainty') or {}
    per_item=float(soft_policy.get('per_item_multiplier',1.05))
    maximum=float(soft_policy.get('maximum_multiplier',1.25))
    soft_multiplier=min(maximum,per_item**len(set(soft_missing))) if soft_missing else 1.0
    diagnostic_sigma=policy['sd_total']*scale_multiplier*soft_multiplier
    return {'status':'EVIDENCE_GATED_TOTAL_DIAGNOSTIC','game_minutes':event.get('game_minutes'),
            'game_minutes_source':event.get('game_minutes_source','UNKNOWN_NO_MINUTES_ASSUMED'),
            'recent_total_mean':sum(totals)/len(totals) if totals else None,
            'recent_total_median':sorted(totals)[len(totals)//2] if totals else None,
            'recent_total_observations':len(totals),'pace_quality':'DIRECT_ONLY_NOT_IMPUTED',
            'close_game_q4_total_mean':sum(q4_close)/len(q4_close) if q4_close else None,
            'close_game_q4_observations':len(q4_close),
            'blowout_q4_total_mean':sum(q4_blowout)/len(q4_blowout) if q4_blowout else None,
            'blowout_q4_observations':len(q4_blowout),
            'garbage_time_proxy':'Q4_SCORE_BY_PRE_Q4_MARGIN',
            'source_context_variables':context.get('available_variables',[]),
            'recent_score_context':score_context,
            'score_context_status':score_context.get('status'),
            'score_context_method':score_context.get('method'),
            'score_context_warning':'比分与分节数据用于状态/波动诊断；未将比分反推为回合数、三分率或犯规率',
            'score_context_team_windows':{k:{'last_5':v['windows']['last_5'], 'last_10':v['windows']['last_10']}
                                         for k,v in score_context.get('team_context',{}).items()},
            'evidence_level':evidence_level or 'LEVEL_D',
            'predictive_spread':predictive_spread,'close_game_probability':close_game_probability,
            'close_game_expected':close_game_expected,
            'late_foul_premium':context.get('late_foul_premium') if context.get('late_foul_verified') else None,
            'ot_premium':context.get('ot_premium') if context.get('ot_premium_verified') else None,
            'close_game_total_adjustment':total_adjustment,
            'hard_blockers':list(dict.fromkeys(hard_blockers)),
            'soft_missing':list(dict.fromkeys(soft_missing)),
            'uncertainty_flags':list(dict.fromkeys(hard_blockers+soft_missing)),
            'diagnostic_sigma_total':diagnostic_sigma,
            'base_sigma_total':policy['sd_total']*scale_multiplier,
            'soft_missing_uncertainty_multiplier':soft_multiplier,
            'uncertainty_policy_source':'config/total_evidence_policy.yaml',
            'used_in_pricing':not hard_blockers,'used_in_execution':not hard_blockers,'used_in_kelly':not hard_blockers,
            'execution_eligible':execution_eligible,
            'execution_blockers':list(dict.fromkeys(hard_blockers)) if not execution_eligible else []}

def competition_match(event,g):
    """Use a source id when both surfaces expose one; otherwise require a
    conservative canonical label from the verified team-history endpoint."""
    eid=event.get('competition_id');gid=g.get('competition_id')
    if eid and gid:return 'EXACT_SOURCE_ID' if eid==gid else None
    if g.get('evidence_kind')!='TEAM_HISTORY':return None
    ek=event.get('competition_key') or competition_key(event.get('league'),event.get('gender'))
    gk=g.get('competition_key') or competition_key(g.get('league'),g.get('gender'))
    return 'CANONICAL_SOURCE_LABEL' if ek and ek==gk else None

def eligible_history(event,history,cutoff,mode):
    c=iso(cutoff);p=POLICY[event['model_family']];good=[];reject=Counter()
    for g in history:
        reason=None
        if g['event_id']==event['event_id']:reason='TARGET_GAME_EXCLUDED'
        elif g.get('gender')!=event.get('gender'):reason='GENDER_MISMATCH'
        elif not competition_match(event,g):reason='COMPETITION_MISMATCH'
        elif g.get('status')!='FINAL':reason='NOT_CONFIRMED_FINAL'
        elif iso(g['tip_at'])>=c:reason='NOT_BEFORE_CUTOFF'
        elif (c-iso(g['tip_at'])).total_seconds()/86400>p['max_days']:reason='HISTORY_TOO_OLD'
        elif mode=='FORWARD_NATIVE' and (not g.get('known_final_at') or iso(g['known_final_at'])>c):reason='FINAL_NOT_OBSERVED_BY_CUTOFF'
        elif mode=='RECONSTRUCTED_SCORE_ONLY' and iso(g['tip_at'])+timedelta(hours=24)>c:reason='RECONSTRUCTION_24H_AVAILABILITY_BUFFER'
        if reason:reject[reason]+=1
        else:good.append(g)
    # Deduplicate facts, do not let multiple mirrors multiply evidence.
    byid={};conflict=set()
    for g in good:
        old=byid.get(g['event_id'])
        if old and any(old.get(k)!=g.get(k) for k in ('team1_id','team2_id','score1_full','score2_full','tip_at')):conflict.add(g['event_id'])
        else:byid[g['event_id']]=g
    reject['CONFLICTING_SCORE_FACT']+=len(conflict)
    return sorted([g for k,g in byid.items() if k not in conflict],key=lambda g:g['tip_at']),dict(reject)

def price_event(event,history,cutoff,mode,context=None):
    """Actually called by the daily runner. Inputs contain only source score facts.

    This is an explicitly uncalibrated baseline, not invented ORtg/Pace or a
    roster-impact model. A diagnosis can be computed without roster data;
    incomplete/high-uncertainty evidence cannot become a paper entry.
    """
    context=dict(context or {});context.setdefault('cutoff_at',cutoff)
    family=event['model_family'];p=POLICY[family]
    tier,tier_spec=tier_for(event);native_scale_multiplier=float(tier_spec.get('residual_scale_multiplier',1.45))
    roster_stability=evaluate_tier3_roster_stability(event,context,cutoff)
    if roster_stability.get('verified'):
        context['roster_stability_30d_verified']=True
        context['roster_stability_30d_evidence']=roster_stability
    cold_scale_multiplier=float((COLD_START.get('residual_scale') or {}).get('cold_start',1.25))
    evaluation,league_policy=evaluation_channel(event)
    base={'event_id':event['event_id'],'asof':cutoff,'archive_type':mode,'model_family':family,'model_version':MODEL_VERSION,
      'pricing_status':'UNPRICEABLE','mu_raw':None,'mu_structural':None,'mu_market':None,'mu_blended':None,
      'total_raw':None,'total_structural':None,'total_market':None,'total_blended':None,'pricing_data_quality':0,
      'model_source':'真实比分的正则化对手校正基线；非阵容/回合模型','probability_calibration_status':'UNVALIDATED',
      'real_execution_allowed':False,'paper_model_eligible':False,'uncertainty_source':'UNVALIDATED_RESEARCH_PRIOR',
      'roster_status':context.get('roster_status','UNKNOWN'),'injury_status':context.get('injury_status','UNKNOWN'),
      'total_model_status':'EVIDENCE_GATED_TOTAL_DIAGNOSTIC','league_tier':tier,
      'roster_stability_30d':roster_stability,
      'residual_scale_multiplier':native_scale_multiplier,'evaluation_channel':evaluation,
      'pricing_state':'UNPRICEABLE','research_priceable':False,'cold_start_priceable':False,
      'prior_only_price':False,'effective_sample_size':0.0,'effective_sample_size_by_team':{},
      'current_season_games':0,'previous_season_games':0,'older_history_games':0,
      'bootstrap_history_used':False,'competition_strength_adjustment':{},
      'cold_start_residual_multiplier':1.0,'shadow_eligible':False,'executable_eligible':False,
      'league_lifecycle_state':'DISCOVERY'}
    # Keep score/period context visible even when pricing stops at an earlier
    # history or identity gate. This is diagnostic evidence, not a gate bypass.
    base['recent_score_context']=build_score_context(event, history, cutoff)
    if iso(cutoff)>=iso(event['tip_at']):return dict(base,blockers=['TARGET_ALREADY_STARTED'],input_games=0)
    if not event.get('identity_verified'):return dict(base,blockers=['IDENTITY_CONFLICT'],input_games=0)
    native_games,rejections=eligible_history(event,history,cutoff,mode)
    games=native_games
    relations={g['event_id']:'NATIVE' for g in native_games}
    targets=(event['team1_id'],event['team2_id']);counts={t:sum(t in (g['team1_id'],g['team2_id']) for g in games) for t in targets}
    bootstrap_used=False
    if min(counts.values(),default=0) < p['min_games']:
        games,relations=_bootstrap_history(event,history,cutoff,mode,native_games,rejections)
        bootstrap_used=any(relations.get(g['event_id']) not in (None,'NATIVE') for g in games)
        counts={t:sum(t in (g['team1_id'],g['team2_id']) for g in games) for t in targets}
    effective_ess,ess_by_team,bootstrap_weights=_effective_sample_size(games,targets,cutoff,p,relations,bootstrap_used)
    season_counts=Counter(_season_bucket(g,cutoff) for g in games
                          if any(t in (g['team1_id'],g['team2_id']) for t in targets)) if bootstrap_used else Counter()
    opponents={t:sorted({g['team2_id'] if g['team1_id']==t else g['team1_id'] for g in games if t in (g['team1_id'],g['team2_id'])}) for t in targets}
    match_methods=Counter(competition_match(event,g) for g in games)
    audit={'input_games':len(games),'team_game_counts':counts,'team_opponent_counts':{t:len(v) for t,v in opponents.items()},'history_exclusions':rejections,
      'competition_match_methods':{k:v for k,v in match_methods.items() if k},
      'used_history_ids':[g['event_id'] for g in games],'input_fingerprint':fingerprint({'event':event,'history':games,'cutoff':cutoff}),
      'last_game_at':{t:max((g['tip_at'] for g in games if t in (g['team1_id'],g['team2_id'])),default=None) for t in targets},
      'effective_sample_size':effective_ess,'effective_sample_size_by_team':ess_by_team,
      'current_season_games':season_counts.get('current_season',0),
      'previous_season_games':season_counts.get('previous_season',0),
      'older_history_games':season_counts.get('older_history',0),
      'bootstrap_history_used':bootstrap_used,
      'bootstrap_relations':{k:v for k,v in relations.items() if v!='NATIVE'}}
    research_min=float((COLD_START.get('thresholds') or {}).get('research_ess_min',3.0))
    cold_min=float((COLD_START.get('thresholds') or {}).get('cold_start_ess_min',6.0))
    if min(counts.values(),default=0)<p['min_games'] or (bootstrap_used and effective_ess<research_min):
        return dict(base,**audit,blockers=['INSUFFICIENT_PRE_CUTOFF_HISTORY'],
                    paper_evidence_blockers=['INSUFFICIENT_HISTORY'],
                    league_lifecycle_state='DISCOVERY')
    cold_state='NATIONAL_TEAM_BOOTSTRAP' if family=='NATIONAL_TEAM' and bootstrap_used else 'COLD_START_PRICEABLE' if bootstrap_used else 'NATIVE_PRICEABLE'
    scale_multiplier=native_scale_multiplier*(cold_scale_multiplier if bootstrap_used else 1.0)
    competition_adjustments=Counter()
    for g in games:
        relation=relations.get(g['event_id'],'UNKNOWN')
        if relation=='NATIVE':continue
        name,weight=_competition_adjustment(relation,g);competition_adjustments[name]+=weight
    # Only the connected component of the two targets; disjoint leagues cannot lend fake precision.
    component=set(targets)
    while True:
        nxt=component|{t for g in games if component.intersection((g['team1_id'],g['team2_id'])) for t in (g['team1_id'],g['team2_id'])}
        if nxt==component:break
        component=nxt
    games=[g for g in games if g['team1_id'] in component and g['team2_id'] in component][-800:]
    teams=sorted(component);ix={t:i for i,t in enumerate(teams)};n=len(teams)
    if n>180:return dict(base,**audit,blockers=['COHORT_TOO_LARGE_FOR_BASELINE'])
    weights=bootstrap_weights if bootstrap_used else [2**(-max(0,(iso(cutoff)-iso(g['tip_at'])).total_seconds()/86400)/p['half_life']) for g in games]
    eff={t:sum(w for w,g in zip(weights,games) if t in (g['team1_id'],g['team2_id'])) for t in targets}
    if min(eff.values())<.25:return dict(base,**audit,blockers=['NEGLIGIBLE_RECENT_HISTORY'],effective_weight=eff)
    scenarios={}
    for rule,suffix in [('REGULATION_ONLY','regulation'),('INCLUDING_OT','full')]:
        margins=[];totals=[]
        for g,w in zip(games,weights):
            x=[0.]*n;xt=[0.]*n;a=ix[g['team1_id']];b=ix[g['team2_id']];x[a]=1;x[b]=-1;xt[a]=xt[b]=1
            sa,sb=g['score1_'+suffix],g['score2_'+suffix]
            margins.append((x,sa-sb,w));totals.append((xt,sa+sb,w))
        center=sum(y*w for _,y,w in totals)/sum(weights)
        bm=_ridge(margins,p['ridge']);bt=_ridge([(x,y-center,w) for x,y,w in totals],p['ridge'])
        mu=bm[ix[targets[0]]]-bm[ix[targets[1]]];tot=center+bt[ix[targets[0]]]+bt[ix[targets[1]]]
        pts1,pts2=(tot+mu)/2,(tot-mu)/2
        if min(pts1,pts2)<0:return dict(base,**audit,blockers=['INVALID_MODEL_SCORE'])
        scenarios[rule]={'mu_margin':mu,'mu_total':tot,'team1_points':pts1,'team2_points':pts2,
          'raw_team_strength_team1':bm[ix[targets[0]]],'raw_team_strength_team2':bm[ix[targets[1]]],
          'sd_margin':p['sd_margin']*scale_multiplier,'sd_total':p['sd_total']*scale_multiplier,
          'base_sd_margin':p['sd_margin'],'base_sd_total':p['sd_total'],'residual_scale_multiplier':scale_multiplier,
          'df':p['df'],'score_rule':rule}
    full=scenarios['INCLUDING_OT'];warnings=['UNVALIDATED_SCORE_BASELINE']
    if any(len(v)<2 for v in opponents.values()):warnings.append('ONLY_H2H_OR_SINGLE_OPPONENT')
    if min(counts.values())<8:warnings.append('SMALL_SAMPLE')
    if any(g['evidence_kind']=='H2H' for g in games) and not any(g['evidence_kind']=='TEAM_HISTORY' for g in games):warnings.append('TEAM_HISTORY_FEED_NOT_CAPTURED')
    if family!='CLUB_MATURE' and not context.get('roster_verified'):warnings.append('CURRENT_ROSTER_UNVERIFIED')
    if not context.get('injury_verified'):warnings.append('INJURY_UNKNOWN')
    paper_evidence_blockers=[]
    if min(counts.values(),default=0)<8:paper_evidence_blockers.append('INSUFFICIENT_HISTORY')
    if any(len(v)<3 for v in opponents.values()):paper_evidence_blockers.append('INSUFFICIENT_OPPONENT_DIVERSITY')
    if not any(g['evidence_kind']=='TEAM_HISTORY' for g in games):paper_evidence_blockers.append('TEAM_HISTORY_FEED_NOT_CAPTURED')
    if family!='CLUB_MATURE' and not context.get('roster_verified',False):paper_evidence_blockers.append('CURRENT_ROSTER_UNVERIFIED')
    eligible=not paper_evidence_blockers
    blockers=[]
    if tier=='TIER_3' and not context.get('roster_stability_30d_verified'):
        eligible=False
        paper_evidence_blockers.append('ROSTER_STABILITY_MISSING')
        blockers.append('ROSTER_STABILITY_MISSING')
    spread_requires=league_policy.get('spread_paper_entry_requires',[])
    context_keys={
        'injury_status': ('injury_status_verified', 'injury_verified'),
        'rotation_or_expected_minutes': ('rotation_or_expected_minutes_verified', 'rotation_verified', 'roster_verified'),
        'net_rating_context': ('net_rating_context_verified',),
    }
    missing_spread_context=[name for name in spread_requires if not any(context.get(key) for key in context_keys.get(name, (name+'_verified',)))]
    if missing_spread_context:
        blockers.append('SPREAD_CONTEXT_INCOMPLETE')
    quality=min(74,round(20+min(20,min(counts.values())*2)+min(20,min(len(v) for v in opponents.values())*4)+(14 if context.get('roster_verified') else 0)))
    diagnostic=total_diagnostic(event,games,context,p,full['mu_margin'],scale_multiplier)
    # Soft-missing evidence widens only the total residual.  It never changes
    # the fair mean, the 8-game/3-opponent gate, or an edge threshold.
    total_uncertainty_multiplier=float(diagnostic.get('soft_missing_uncertainty_multiplier') or 1.0)
    for scenario in scenarios.values():
        scenario['sd_total_before_soft_missing']=scenario['sd_total']
        scenario['sd_total']*=total_uncertainty_multiplier
        scenario['total_soft_missing_uncertainty_multiplier']=total_uncertainty_multiplier
    # A close-game premium can only affect a total after both components are
    # independently evidenced. It is never imputed from the market or score mean.
    if diagnostic['close_game_total_adjustment'] is not None:
        for rule, scenario in scenarios.items():
            adjustment = diagnostic['close_game_total_adjustment']
            if rule == 'REGULATION_ONLY' and diagnostic['close_game_expected']:
                adjustment -= float(diagnostic.get('ot_premium') or 0)
            scenario['mu_total'] += adjustment
            scenario['team1_points'] = (scenario['mu_total'] + scenario['mu_margin']) / 2
            scenario['team2_points'] = (scenario['mu_total'] - scenario['mu_margin']) / 2
    full=scenarios['INCLUDING_OT']
    shadow_ess=float((COLD_START.get('thresholds') or {}).get('shadow_ess_min',8.0))
    current_min=int((COLD_START.get('thresholds') or {}).get('current_season_min_games_for_shadow',2))
    shadow_eligible=bool(eligible and (not bootstrap_used or (effective_ess>=shadow_ess and season_counts.get('current_season',0)>=current_min and context.get('roster_stability_30d_verified'))))
    if bootstrap_used and not shadow_eligible and 'COLD_START_SHADOW_GATE_NOT_MET' not in blockers:
        blockers.append('COLD_START_SHADOW_GATE_NOT_MET')
    lifecycle='SHADOW' if shadow_eligible else 'BOOTSTRAP' if bootstrap_used else 'PROVISIONAL'
    decomposition={
      'model_version':MODEL_VERSION,
      'raw_team_strength_home':full.get('raw_team_strength_team1'),
      'raw_team_strength_away':full.get('raw_team_strength_team2'),
      'raw_expected_home_score':full.get('team1_points'),
      'raw_expected_away_score':full.get('team2_points'),
      'raw_independent_margin':full.get('mu_margin'),
      'after_mean_calibration_margin':None,
      'after_deep_spread_calibration_margin':None,
      'market_spread':None,
      'model_market_gap':None,
      'betting_fair_spread':full.get('mu_margin'),
      'base_residual_scale':full.get('base_sd_margin'),
      'tier_residual_multiplier':native_scale_multiplier,
      'league_residual_multiplier':1.0,
      'deep_spread_residual_multiplier':None,
      'raw_cover_probability':None,
      'calibrated_cover_probability':None,
      'final_cover_probability':None,
      'expected_value':None,
      'selected_side':None,
      'calibration_status':'NOT_IMPLEMENTED_IN_PRODUCTION; NULLS_ARE_INTENTIONAL',
    }
    return dict(base,**audit,pricing_status='PRICED_LOW_CONFIDENCE',mu_raw=full['mu_margin'],mu_structural=full['mu_margin'],
      total_raw=full['mu_total'],total_structural=full['mu_total'],team1_points=full['team1_points'],team2_points=full['team2_points'],
      score_contract='INCLUDING_OT',scenarios=scenarios,pricing_data_quality=quality,effective_weight=eff,paper_model_eligible=bool(eligible),
      paper_evidence_blockers=list(dict.fromkeys(paper_evidence_blockers)),
      model_warnings=warnings,structured_method='SCORE_RIDGE_NO_QUALITY_MULTIPLIER',
      fair_spread_decomposition=decomposition,
      fair_spread_text=display_fair_margin(event,full['mu_margin']),
      total_diagnostic=diagnostic,total_execution_eligible=diagnostic['execution_eligible'],
      spread_execution_eligible=not missing_spread_context,
      spread_context_missing=missing_spread_context,
      pricing_state=cold_state,research_priceable=True,cold_start_priceable=bootstrap_used,
      cold_start_residual_multiplier=cold_scale_multiplier if bootstrap_used else 1.0,
      residual_scale_multiplier=scale_multiplier,
      competition_strength_adjustment=dict(competition_adjustments),
      shadow_eligible=shadow_eligible,executable_eligible=False,
      league_lifecycle_state=lifecycle,blockers=blockers)

def quote_state(q,event,asof):
    reasons=list(q.get('migration_blockers',[]));c=iso(asof)
    if not q.get('raw_verified'):reasons.append('RAW_QUOTE_NOT_VERIFIED')
    if not event.get('identity_verified'):reasons.append('EVENT_IDENTITY_UNVERIFIED')
    if q.get('event_id') != event.get('event_id'):reasons.append('QUOTE_EVENT_MISMATCH')
    if not q.get('bookmaker_id'):reasons.append('BOOKMAKER_UNKNOWN')
    if q.get('period') != 'FULL_GAME':reasons.append('PERIOD_UNVERIFIED_OR_UNSUPPORTED')
    if q.get('status') in ('SUSPENDED','CLOSED','STALE','UNAVAILABLE'):reasons.append('MARKET_NOT_OPEN')
    if q.get('status') != 'OPEN' and not q.get('current_board_contract_verified'):reasons.append('OPEN_STATUS_UNVERIFIED')
    if iso(event['tip_at'])<=c:reasons.append('EVENT_ALREADY_STARTED')
    rec=iso(q['received_at']) if q.get('received_at') else None
    qt=iso(q['source_quote_at']) if q.get('source_quote_at') else None
    if qt and qt>c+timedelta(seconds=5):reasons.append('QUOTE_TIME_IN_FUTURE')
    if rec and rec>c+timedelta(seconds=5):reasons.append('CAPTURE_AFTER_CUTOFF')
    minutes=(iso(event['tip_at'])-c).total_seconds()/60
    ttl=300 if minutes<=30 else 600 if minutes<=120 else 1800 if minutes<=360 else 3600
    # Unknown timestamp semantics never turn a fresh download into a verified live offer.
    basis=qt
    if q.get('source_timestamp_semantics')=='LAST_CHANGE' and q.get('current_board_contract_verified'):basis=rec
    age=(c-basis).total_seconds() if basis else None
    if age is None:reasons.append('QUOTE_TIME_UNKNOWN')
    elif age>ttl:reasons.append('STALE_QUOTE')
    if not q.get('price_format_verified'):reasons.append('PRICE_FORMAT_UNVERIFIED')
    if not q.get('direction_verified'):reasons.append('SELECTION_DIRECTION_UNVERIFIED')
    if q.get('ot_rule') not in ('INCLUDING_OT','REGULATION_ONLY') or not q.get('rule_evidence'):reasons.append('UNKNOWN_OT_RULE')
    if q.get('main_or_alt')!='MAIN':reasons.append('MAIN_MARKET_UNVERIFIED')
    return {'reasons':list(dict.fromkeys(reasons)),'age_seconds':age,'ttl_seconds':ttl,
      'raw_observation':bool(q.get('raw_verified')),'fresh_observation':bool(q.get('raw_verified') and age is not None and 0<=age<=ttl and iso(event['tip_at'])>c),
      'paper_quote_eligible':not reasons}

def market_integrity(quotes,event,asof):
    """Quarantine divergent fresh MAIN quotes while preserving every raw observation."""
    grouped=defaultdict(list)
    for q in quotes:
        state=quote_state(q,event,asof)
        if not state['paper_quote_eligible'] or q.get('main_or_alt')!='MAIN':
            continue
        line=q.get('line_team1') if q.get('market_type')=='SPREAD' else q.get('raw_line')
        if not isinstance(line,(int,float)):
            continue
        key=(q.get('market_type'),q.get('period'),q.get('ot_rule'))
        grouped[key].append((q,float(line)))
    minimum=int(MARKET_INTEGRITY.get('minimum_fresh_main_quotes',2))
    limits=MARKET_INTEGRITY.get('max_deviation_from_cross_book_median',{})
    result={}
    for key,rows in grouped.items():
        if len(rows)<minimum:
            continue
        center=median([line for _,line in rows])
        limit=float(limits.get(key[0],float('inf')))
        for q,line in rows:
            deviation=abs(line-center)
            result[q['quote_id']]={'median_line':center,'line':line,'deviation':deviation,
                'max_allowed_deviation':limit,'outlier':deviation>limit,'quote_count':len(rows)}
    return result

def decide_market(event,forecast,quotes,cutoff,mode):
    base={'event_id':event['event_id'],'asof':cutoff,'archive_type':mode,'model_state':'UNASSESSED','shadow_action':'BLOCKED',
          'display_action':'不可投','real_stake':0,'real_bet_flag':False,'kelly_usable':False,'triggered':False,'real_execution_allowed':False,
          'blockers':[],'uncertainty_flags':[],'candidates':[],'ev':None,'comparison_ready':False}
    integrity=market_integrity(quotes,event,cutoff)
    base['market_integrity']=integrity
    if forecast['pricing_status']=='UNPRICEABLE':base['blockers']+=forecast.get('blockers',['UNPRICEABLE']);base['model_state']='UNPRICEABLE'
    if not quotes:
        base['blockers'].append('NO_MARKET')
        if forecast['pricing_status']!='UNPRICEABLE':base.update(shadow_action='WATCH',display_action='观察')
        return base
    if not forecast.get('paper_model_eligible'):
        evidence=list(forecast.get('paper_evidence_blockers') or [])
        if evidence:
            base['blockers']+=evidence
        elif not forecast.get('blockers'):
            base['blockers'].append('MODEL_EVIDENCE_NOT_PAPER_ELIGIBLE')
    valid=[];p=POLICY[event['model_family']]
    for q in quotes:
        qs=quote_state(q,event,cutoff);mi=integrity.get(q['quote_id'])
        item={'quote_id':q['quote_id'],'bookmaker':q.get('bookmaker'),'market_type':q['market_type'],'quote_state':qs,'market_integrity':mi}
        base['candidates'].append(item)
        if not qs['paper_quote_eligible']:
            base['blockers']+=qs['reasons'];continue
        if mi and mi['outlier']:
            base['blockers'].append('PROVIDER_DISAGREEMENT')
            continue
        if q['market_type']=='TOTAL' and not forecast.get('total_execution_eligible',False):
            hard=list((forecast.get('total_diagnostic') or {}).get('hard_blockers') or [])
            base['blockers']+=['TOTAL_CONTEXT_INCOMPLETE']+hard
            continue
        if q['market_type']=='TOTAL':
            base['uncertainty_flags']+=list((forecast.get('total_diagnostic') or {}).get('soft_missing') or [])
        if q['market_type']=='SPREAD' and not forecast.get('spread_execution_eligible',True):
            base['blockers'].append('SPREAD_CONTEXT_INCOMPLETE')
            continue
        s=forecast.get('scenarios',{}).get(q['ot_rule'])
        if not s:continue
        sides=('TEAM1','TEAM2') if q['market_type']=='SPREAD' else ('OVER','UNDER')
        prices=q.get('decimal_prices')
        if not prices or len(prices)!=2 or any(x is None or x<=1 for x in prices):continue
        for i,side in enumerate(sides):
            threshold=-q['line_team1'] if q['market_type']=='SPREAD' else q['raw_line']
            mu=s['mu_margin'] if q['market_type']=='SPREAD' else s['mu_total'];sd=s['sd_margin'] if q['market_type']=='SPREAD' else s['sd_total']
            direction='OVER' if side in ('TEAM1','OVER') else 'UNDER';shift=p['mean_margin'] if q['market_type']=='SPREAD' else p['mean_total']
            adverse=mu-shift if direction=='OVER' else mu+shift
            cdf_actual=margin_cdf(mu,sd,s['df'],q['ot_rule']) if q['market_type']=='SPREAD' else (lambda x:t_cdf(x,mu,sd,s['df']))
            cdf_adverse=margin_cdf(adverse,sd,s['df'],q['ot_rule']) if q['market_type']=='SPREAD' else (lambda x:t_cdf(x,adverse,sd,s['df']))
            wpl=threshold_probability(cdf_actual,threshold,direction)
            low=threshold_probability(cdf_adverse,threshold,direction)
            a=ev_and_kelly(wpl,prices[i]);b=ev_and_kelly(low,prices[i]);edge=b['p_win_conditional_nonpush']-1/prices[i]
            z={'quote_id':q['quote_id'],'bookmaker':q.get('bookmaker'),'selection':side,'market_type':q['market_type'],
               'line':(q['line_team1'] if i==0 else -q['line_team1']) if q['market_type']=='SPREAD' else q['raw_line'],
               'decimal_odds':prices[i],'ev':a['ev'],'adverse_ev':b['ev'],'conditional_edge':edge,
               'p_win':wpl.win,'p_push':wpl.push,'p_loss':wpl.loss,'ot_rule':q['ot_rule'],
               'research_edge_pass':b['ev']>=.025 and edge>=p['buffer']}
            if q['market_type']=='SPREAD':
                decomposition=dict(forecast.get('fair_spread_decomposition') or {})
                decomposition.update({
                    'market_spread':q.get('line_team1'),
                    'model_market_gap':(forecast.get('mu_raw') - q.get('line_team1')) if isinstance(forecast.get('mu_raw'), (int, float)) and q.get('line_team1') is not None else None,
                    'raw_cover_probability':wpl.win,
                    'calibrated_cover_probability':None,
                    'final_cover_probability':wpl.win,
                    'expected_value':a['ev'],
                    'selected_side':side,
                })
                z['pricing_decomposition']=decomposition
            valid.append(z)
    if valid:
        # Best single actual offered quote, never median line + another book's price.
        best=max(valid,key=lambda z:z['adverse_ev']);base.update(comparison_ready=True,comparison_rows=valid,selected=best,ev=best['ev'],
          model_state='EDGE' if best['research_edge_pass'] else 'LEAN' if best['ev']>0 else 'NO_EDGE')
        if best.get('pricing_decomposition'):
            base['fair_spread_decomposition']=best['pricing_decomposition']
        # Other invalid book quotes do not poison a valid book; retain them under candidates.
        persistent=set(forecast.get('blockers',[]))|set(forecast.get('paper_evidence_blockers',[]))
        if any(q.get('market_type')=='TOTAL' for q in quotes):
            persistent|=set((forecast.get('total_diagnostic') or {}).get('hard_blockers') or [])
            if not forecast.get('total_execution_eligible',False):persistent.add('TOTAL_CONTEXT_INCOMPLETE')
        if any(q.get('market_type')=='SPREAD' for q in quotes) and not forecast.get('spread_execution_eligible',True):
            persistent.add('SPREAD_CONTEXT_INCOMPLETE')
        persistent.add('PROVIDER_DISAGREEMENT')
        base['blockers']=[x for x in base['blockers'] if x in persistent]
        if not base['blockers']:
            passed=best['research_edge_pass']
            # Replay is computation audit, never a live paper fill.
            if mode=='FORWARD_NATIVE' and passed:base.update(shadow_action='SHADOW_BET',display_action='纸面可投',triggered=True)
            else:base.update(shadow_action='PASS',display_action='不可投')
    base['blockers']=list(dict.fromkeys(base['blockers']))
    base['uncertainty_flags']=list(dict.fromkeys(base['uncertainty_flags']))
    return base

def decide(event,forecast,quotes,cutoff,mode):
    """Decide each market independently; retain a legacy best-selection view."""
    market_decisions={}
    for market_type in ('SPREAD','TOTAL'):
        market_quotes=[q for q in quotes if q.get('market_type')==market_type]
        market_decisions[market_type]=decide_market(event,forecast,market_quotes,cutoff,mode)
    comparable=[d for d in market_decisions.values() if d.get('comparison_ready') and d.get('selected')]
    selected=max((d['selected'] for d in comparable),key=lambda x:x.get('adverse_ev',float('-inf')),default=None)
    triggered=[d for d in market_decisions.values() if d.get('triggered')]
    base=market_decisions.get('SPREAD',{}).copy()
    if not comparable:
        base=market_decisions.get('TOTAL',base).copy()
    base['market_decisions']=market_decisions
    base['comparison_ready']=bool(comparable)
    base['selected']=selected
    base['ev']=selected.get('ev') if selected else None
    base['triggered']=bool(triggered)
    base['shadow_action']='SHADOW_BET' if triggered else base.get('shadow_action','BLOCKED')
    base['display_action']='纸面可投' if triggered else base.get('display_action','不可投')
    base['market_types_with_comparison']=[m for m,d in market_decisions.items() if d.get('comparison_ready')]
    base['market_types_triggered']=[m for m,d in market_decisions.items() if d.get('triggered')]
    blockers=[]
    for d in market_decisions.values(): blockers.extend(d.get('blockers',[]))
    base['blockers']=list(dict.fromkeys(blockers))
    return base
