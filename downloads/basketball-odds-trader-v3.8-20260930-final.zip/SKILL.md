---
name: basketball-odds-trader
description: 篮球数据核验、真实比分独立研究定价、盘口采集与纸面模拟。v3.8加入Titan007赛程/让分/大小分生产源与全日覆盖审计；不允许真实下注，不把工程测试当作策略有效性。
---
# 篮球研究与纸面模拟 v3.8

## 唯一生产入口

```powershell
python D:\codex\skills\basketball-odds-trader\scripts\run_basketball_daily.py --live --backtest-recent 6 --publish-beta --push
```

实际调用链：`repair_v22.cli -> pipeline.execute -> source.collect_live -> model.price_event（逐场） -> 冻结输入/预测 -> model.decide -> 不可变决定/结算 -> 逐日JSON/中文页面`。
禁止恢复旧 runner 中写死的 `coupled=[]`、`enrichment=False`、零定价漏斗。禁止再执行 `run_step5rf2.py`；其中153分与排名差定价已被证明不具备真实输入链，只能保留为旧版错误审计。

## 执行与访问

本版本真实资金执行恒为关闭。公开源采集只用正常HTTP，最多6线程、有限超时；不绕过验证码/付费/登录/访问控制。不能取到数据时保存具体URL、错误、原文路径，不把HTTP200、输出文件存在或测试数当成数据成功。

7M真实页面/数据先进入原始快照，每个响应分别记录请求/接收时间、哈希与来源。页面里的明确链接才可用于进一步取身份和球队 `n_history.js`。同一批下载不是原子市场快照，不要声称文件绝对同时产生。

### Titan007 全日赛程与盘口源（v3.8）

用户指定的公开页面 `https://lq3.titan007.com/nba.htm` 是生产链的补充赛程与盘口源，不能只把它当作人工参考。正常HTTP采集使用页面实际调用的公开接口：

- `https://lq3.titan007.com/NBA/today2.xml?t=<epoch_ms>`：当天赛程、联赛、球队、北京时间和状态；按目标北京时间日期过滤后，所有行必须保留为事件。
- `https://lq3.titan007.com/NBA/nbaGoal{1,2,3,8,9}.xml?t=<epoch_ms>`：各公开公司的当前让分与大小分快照。`goal`是带符号的team1让分，正数表示team1受让；大小分字段分别是总分、 大分水位、小分水位。正香港盘水位转十进制为`1 + water`。
- 页面明确链接的 `https://nba.titan007.com/analysis/{source_event_id}.htm` 可用于逐场分析页；已有7M详情页和球队历史链路仍是互补证据，不得用截图或搜索摘要替代原始比分。

Titan007当前盘口XML没有逐报价的最后变动时间，也没有在该接口中独立声明全场加时结算规则。因此：原始让分/大小分必须保存并在Dashboard显示为`MARKET_FOUND`，但只有在现有同场、同市场、同规则、时间新鲜和证据门禁全部满足时才可升级；不能把当前板抓到直接写成可纸面执行。缺少某一公司报价不删除赛事，写入`NO_CURRENT_BOARD_QUOTE`及具体source_event_id；不能再把“某接口没有报价”泛化为“数据抓取不到”。

Titan007、7M、ESPN、SofaScore的赛程/盘口/历史能力必须分源记录健康状态、原始快照、请求时间、接收时间、哈希、解析条数和失败原因。Titan007新源只有在当天实际解析到目标日事件、球队和盘口字段后才能标记`PRODUCTION_VERIFIED`；历史统计仍按截止时间和同赛事过滤，不能用最终赛果倒推盘前数据。

## 身份、时间与市场

7M源ID使用`7m:<id>`，不将会变动的开赛时间作为永久ID。源内ID匹配后还必须检查球队、比赛时间、联赛和冲突；旧2025年赛事不能计成2026年今日比赛。

已取得的7M详情页明确默认GMT+0800。无时区的7M年月日数组据此转换，原文和证据保留；不能附上UTC而将开赛时间推迟8小时。当前日按真实北京时间筛选，已开赛不允许生成盘前记录。

聚合源、公司命名空间和实际公司身份分开。保留每家公司每条盘口的完整数组、两侧水位、时间、主/替代盘、时段。不能将一侧水位复制给另一侧，也不能把所有公司改成4。缺失的原始`.raw`不能靠旧标准化JSON自动变成“已核验真盘”。

盘口解析规则放在`config/repair_market_contracts.json`。没有证据时不要激活示例。确认格式、让分符号、当前开放状态、时段、实际公司结算规则后才可纸面执行。7M是展示源，不能替所有公司制定统一加时规则。未知规则只阻止合同EV/执行，不阻止观察和独立研究定价。

新下载不等于新报价。区分报价变化时间、收到时间、仍挂牌确认时间；只有已验证当前挂牌契约才允许以确认时间刷新稳定盘口。不能仅因事件已绑定就写`quote_age=0`。

## 数据补全与独立模型

实际解析7M身份脚本里的`a_wf`是交锋资料，不是完整球队最近比赛。必须继续跟随原页面公开的`Basketball_Team_Data/<team>/gb/n_history.js`取得球队历史；该请求成功不等于解析成功，必须输出实际比赛条数。

模型只使用截止前已确认完场的实际比分、对手、同赛事身份；排除当前比赛、未来比赛、异性别、不同competition、冲突比分及过旧资料。分节和半场总分进行一致性校验。无需高级统计就能运行的比分基线单独命名为`SCORE_BASELINE_UNVALIDATED`，不伪造ORtg、Pace、球员评级、阵容或伤停。

独立研究定价使用带时间衰减的对手校正岭回归。总分另做同数据域回归，双方预测得分由同一分差/总分一致拆分。置信度低不等于预测分差乘0.38；不以未知作为“无人受伤”。模型原始输入不得含任何盘口、赢盘率或大小分盘路。

缺高级统计时研究定价最少每队3场同赛事有效历史；这不是投注门槛。纸面模型证据还要求每队至少8场、至少3个不同对手、有真正TEAM_HISTORY流；国家队/高不确定赛事额外要求当前名册核验。该初始政策和Student-t残差参数都是未校准研究先验，不是盈利证明。只有交锋资料的2条离线基线不能升级成纸面可投。

规则与输入不足仍可返回`UNPRICEABLE`，但必须保存实际调用痕迹、解析条数、具体拒绝原因，而不是先写死结果。所有真实市场赛事均应尝试，不仅第一场。

## 概率、执行与不可变账本

采用真正Student-t CDF（标准差与scale不同）；整数盘独立计算赢/走/输。EV为`P(win)*(decimal-1)-P(loss)`；条件于非走水的盈亏平衡为`1/decimal`。胜率不替代让分覆盖率，不使用人为线性每半分+/-固定概率。

比较必须同一场、同市场、同规则。总分不能拿让分倾向代替；共识盘口不能与另书赔率拼接成可成交价格。实际报价无方向/价格/时段/OPEN/OT证据不计算正式EV。保守情景是参数压力测试，不可冒充经验置信区间或已校准概率。

新纸面单还必须经过跨公司主盘完整性检查。对同场、同市场、同全场时段、同加时规则的本轮新鲜主盘，至少两家公司可比时，按`config/market_integrity.json`计算中位数；让分偏离中位数超过4分、总分超过8分的报价标记`PROVIDER_DISAGREEMENT`。该报价及原始`.raw`、时间和双边水位必须完整保留，但不能单独触发纸面单；整场在分歧未由后续新鲜快照消除前只能观察。此规则不修改公平盘口、概率、sigma、Kelly、模型权重、历史首写或已冻结结算。

预测输入与预测结果先独立冻结，再形成比较与决定。采集器可能先看到市场，但独立模型函数输入中不含市场，采用输入哈希与隔离测试证明；禁止仅写一个`market_accessed=false`口号。

同场最多一张已触发的纸面主单；后续checkpoint记录更新观点，不重复下注计数。不改变旧首写。结算单独追加，核对球队顺序、全场/常规时间；没有有效终盘不制造CLV。真钱stake恒为0。

每次实时更新必须新建盘口采集批次，并对所有未开赛的首写纸面单执行“当前盘口复核”：仅以本轮同场、同公司、同市场、同方向、同加时结算规则，且方向与赔率均已核验并未过期的报价运行既有纸面门槛。另一公司、另一盘口或另一方向即使本轮通过，也只能是新的独立观察，不能写作旧纸面单“仍可投”。复核结果仅可为`STILL_QUALIFIES`、`NO_LONGER_QUALIFIES`、`REVALIDATION_UNAVAILABLE`或`EVENT_STARTED`，并记录本轮时间、选择、盘口、赔率和阻塞原因。首写盘口、预测、决定和结算永不被复核覆盖；网页必须同时区分“首写纸面记录”和“本轮复核”。没有新鲜、同规则盘口时只能写“无法复核”，不能使用旧首写盘口说仍可投。

复核必须计算首写与本轮真实报价的盘口差、赔率差，并用`config/execution_lifecycle.json`中的同市场初始限额标记“需要显式复核”；限额不是自动否决。让分必须按被选方向判断：同一受让方由`+6.5`变`+10.5`、或同一让球方由`-6.5`变`-3.5`，均为更有利；受让分变少或让球分变深，均为不利。大小分同理：大分总分下降更有利、上升不利；小分总分上升更有利、下降不利。赔率升高更有利、降低不利。任何大幅变化都必须以本轮同公司、同市场、同方向、同加时规则重新运行既有纸面门槛：当前门槛通过即为`STILL_QUALIFIES`，即使盘口不利；只有重新审核未通过才为`NO_LONGER_QUALIFIES`。页面只有该后者才用红色加粗显示“真实盘口差异过大，经重新审核后本轮不投注”；有利变化应明确显示“当前盘口对原方向更有利”。该复核仅影响当前是否仍可进入，不覆盖历史首写、首写结算或回测记录。

## 回测与网页

每次更新必须扫描所有原生前向纸面首写记录并尝试追加赛果结算，不限于昨天。以 prediction_id 和 event_id 核对结算，按首写盘口、赔率和加时规则计算赢/输/走水；可靠赛果缺失保持 PENDING。将已确认结算同步到全部对应历史日期 JSON 及 latest.json，输出 audits/paper_settlement_tracking.json。保留原始预测、选择、盘口、赔率和时间，不能重算覆盖。昨日回顾另行保留。

同一次更新还必须输出`audits/paper_market_revalidation.json`，分别统计仍符合、当前失效、无法复核和已开赛的首写纸面单；公开页面显示每场本轮复核状态和依据。`纸面可投`首写标签表示当时的不可变决定，不等价于当前仍可按该价格纸面进入。

`--backtest-recent 6`是最近6个已结束北京时间日，不含今天。现有代码执行真实逐场留出比分重建，重建资料有24小时可得性假设，永久标记`RECONSTRUCTED_SCORE_ONLY`；不是当时原始页面状态。无历史盘口就无投注、ROI、CLV。0个合格样本要说明无可评估样本，而非0收益或策略通过。

网页由本轮全部实际结果生成。`events`数组与同口径漏斗必须一致，场数不等于报价条数。缺失为null不变0；中文优先，最大状态条为纸面可投/观察/不可投；所有让分带具体球队。正的预测分差=team1领先，对应team1公平让分为负，不能根据球队名气反转。未知方向显示待核验。

原生前向、包内核查、历史重建、旧版迁移分别存储。旧153分演示和旧硬编码漏斗不计修复版校准。历史账本、旧`basketball.html`和足球/金融Skill不动。复制到发布仓库与GitHub Pages实际上线不同，`--push`必须明确指定；不得宣称已验证公共网页，除非真的访问验收。

checkpoint入口是`run_basketball_checkpoint.py`，仅当外部Windows计划任务调用时执行；创建脚本不等于后台调度已启用。所有错过时点标missed，禁止回填。

## 首写信号、纸面执行、价格透支与总分诊断（v2.2 补充）

每日生产入口在冻结每场输入、定价和决定后，必须生成派生分析
`calibration/spread_execution_total_analytics.json`。它只读取不可变的
`FORWARD_NATIVE`首写、原始7M快照和追加结算；不得改写历史预测、首写盘口、赔率、决定、赛果或账本。

统计必须严格分三层：

1. **让分信号层**：保留每个“canonical event + market”的最早有效赛前首写方向，并按其冻结盘口与赛果记录WIN/LOSS/PUSH/PENDING。它是方向研究记录，页面和报告不得称为“策略胜率”。
2. **纸面执行层**：只计当时`triggered=true`的纸面条目，按首写盘口、赔率、结算规则计算纸面P&L/ROI。重复刷新产生的同场记录不得成为额外样本。
3. **价格透支层**：只能在同公司、同市场、同方向、同加时规则的首写与后续新鲜复核都存在，且后续仅因价格已不通过而失效时标记`PRICE_EXHAUSTED`。缺少新盘口、不同公司、不同方向或事件已开始都不是价格透支；此类记录不得计纸面P&L。

首次纸面记录按`config/execution_lifecycle.json`标注：T-4h至T-90m为`EARLY_PAPER_ENTRY`，更早仅为`SIGNAL_BEFORE_EARLY_WINDOW`，T-90m以内为`LATE_PAPER_ENTRY`。初始阈值来源固定为`INITIAL_PRIOR`，不得根据赛果自动校准。T-30/T-10/T-5的复核只能追加到`outputs/basketball_odds_trader/revisions/repair_v22/<prediction_id>/`，不会覆盖早盘选择、价格或纸面结算。

市场路径必须保留首见、首写、T-90、T-30、T-10、最后观察和已验证终盘（若有）。最后观察不等于终盘；没有可验证终盘不得计算CLV。盘口向模型移动/背离仅为研究诊断，不得改变概率、sigma、Kelly、模型权重或执行门槛。

总分的基础均值与残差仍以独立比分基线保存，但纸面执行一律遵循下文的`EVIDENCE_GATED_TOTAL_DIAGNOSTIC`：缺少可核验的节奏、三分、阵容、伤停或末节情景资料时，只能诊断与观察，不能以分数均值替代关键变量，也不能自动偏向大分或小分。

总分纸面执行改为`EVIDENCE_GATED_TOTAL_DIAGNOSTIC`，不是“比分均值看到低就买小”的替代品。必须先按截止时间取得并留存：双方实际回合数或可复算的回合构成、进攻/防守效率或等价可审计拆分、三分出手与命中资料、当前阵容/预计上场时间与伤停、联赛常规时间规则；历史分节比分还要分开统计胶着局（末节前分差不超过8分）与大分差局（不少于15分）的末节得分，作为末节犯规与垃圾时间的**结果代理**，不得把它冒充犯规或回合原始数据。7M公开`avgpoint/standings/pointstat/totalstat/bqcstat`可保存为节次和赛季聚合证据，但数组语义未证实前不得推导回合数、三分或犯规。

缺任一上述关键输入时总分仅显示为诊断与观察，必须阻止总分纸面单（`TOTAL_CONTEXT_INCOMPLETE`），不能从得分反推回合数或用未知阵容偏向小分。未知输入只提高不确定度、不制造方向。盘口总分上调/下调是市场路径信息而非交易方向：必须先做同公司、同市场、同结算规则的首见/首写/T-90/T-30/T-10/最后观察路径，再以独立的节奏、效率、末节情景、三分和阵容证据确认或反驳。连续小分后盘口上调只能标为“可能大分被冷落”，不能自动买大；常态大分队的低阻力大分盘口只能标为“可能诱导”，不能自动买小。任何“诱导/阻上/阻下”均仅是审计标签，不进入公平总分、概率、EV、Kelly或执行门槛。只有足量原生前向样本和独立校准申请，才能提出参数变更，禁止依历史回测自动调参。

页面顶端必须显示：让分首写方向数及W/L/P/Pending、纸面执行数及纸面P&L、已证实价格透支数、总分已结算诊断样本数，并固定说明真实执行关闭。每场详情需要显示首写阶段、阈值来源、临场复核和总分证据诊断；旧首写不因临场价格变化消失。

## v2.3 分级风险、执行滑点、总分与联赛隔离

### 联赛分级与残差不确定性

联赛分级唯一来源是`config/league_tier_registry.yaml`。未明确映射的联赛必须按`TIER_3`处理，不得因为盘口存在、球队名气或历史胜率而降级风险。Tier 1 为 NBA/WNBA；Tier 2 为 EuroLeague、CBA 常规赛和季后赛；Tier 3 包括夏季联赛、邀请赛、热身赛、青年赛、低覆盖次级联赛及其它未分类赛事。不得把 CBA 夏联、季前赛或俱乐部杯混入 CBA 常规赛的 Tier 2 评估。

Student-t 残差必须按联赛 Tier 采用`scale_adj = base_scale * residual_scale_multiplier`，而非仅在页面上标示不确定性。Tier 1 系数为 1.00，Tier 2 为 1.15，Tier 3 强制为 1.45。`df`、基础 scale 与调整后 scale 都要冻结到预测输入和输出中；不得在结算或回测后回填改变。此规则展平 Tier 3 的覆盖率和总分概率分布，所有执行门槛仍使用同一已冻结概率与 EV 合同，禁止以降低阈值抵消风险惩罚。

Tier 3 若没有可审计的近 30 个自然日内部阵容稳定性资料（名单变动、实际轮换或预计上场时间的来源、发布时间与覆盖窗口），只能输出`DIAGNOSTIC_ONLY`。该状态可以展示独立研究、盘口和缺失项，但无论模型 edge、赔率或市场路径如何，均不得生成`PAPER_ENTRY`、纸面方向或纸面 P&L。来源缺失、日期不明、赛后资料或用最终名单倒推都视为缺失。

### 价格透支、滑点和 CLV 路径

`PRICE_EXHAUSTED`是首写之后可观测到的真实水位/盘口滑点归因，不是“盘口向不利方向移动即作废”的同义词，也不得删除、覆盖或追溯排除已冻结的纸面单。首写纸面单的资格和结算永远只由其首写时的冻结合同决定；本轮是否还可以按当前报价重新进入，仍按既有同公司、同市场、同方向、同加时规则复核。

当后续同规则新鲜报价使原选择不再满足当前纸面门槛时，记录`slippage_loss`：首写与复核的让分/总分差、赔率差、方向上的有利或不利变化、复核时间和未通过的门槛。`PRICE_EXHAUSTED`只能作为该滑点事实的子状态或分析标签，不能代替`NO_LONGER_QUALIFIES`，更不能将尚未复核、不同公司、不同市场、不同结算规则或已开赛事件标为价格透支。

结算账本和`calibration/spread_execution_total_analytics.json`必须按首写、T-90、T-30、T-5 三种**可实际取得同规则报价**分别模拟执行延迟；每条路径记录可执行样本数、WIN/LOSS/PUSH/PENDING、纸面 P&L、ROI、相对首写的盘口/赔率滑点与样本删失原因。没有该时点原始报价的记录是`UNAVAILABLE`，不是零滑点，也不得用之后报价补齐。所有统计必须按联赛 Tier 与具体联赛拆分；样本不足仅报告计数和区间，不宣称真实胜率、CLV 优势或策略有效。

### EVIDENCE_GATED_TOTAL_DIAGNOSTIC：胶着局、加时与末节情景

总分模型必须将独立比分基线与以下可审计输入分开保存：预期回合数或可复算回合构成、双方进攻/防守效率、三分出手/命中与波动区间、阵容和预计上场时间、伤停、联赛加时规则、胶着局末节与大分差垃圾时间的历史分节情景。不能只使用历史总分均值，也不得把盘口上调/下调、连续大小分或历史盘路当作这些变量的替代。

以已冻结的`predictive_spread`评估胶着局：当绝对预测分差`<= 4.5`时，必须计算并单列`close_game_probability`，并在总分诊断中加入两项独立、可追溯的期望得分：`late_foul_premium`与`ot_premium`。前者只可由同联赛的胶着末节、罚球/犯规或可验证结果代理资料估计；后者只可由联赛加时规则与同联赛可用的加时发生资料估计。必须记录来源、窗口、样本数、适用性和不确定性；不存在可审计证据时为`UNAVAILABLE`，不得凭常识填默认分数。

胶着局溢价会修正独立总分的期望和残差不确定性，但不自动产生大分观点；同理，垃圾时间风险、三分回归和阵容变化必须可以支持或反驳大/小分，而非把上升盘口解释为买大、下降盘口解释为买小。只有全部关键总分输入、溢价证据和同规则市场合同都完整时，才可通过总分纸面门槛；否则维持`EVIDENCE_GATED_TOTAL_DIAGNOSTIC`或`TOTAL_CONTEXT_INCOMPLETE`，不能创建总分`PAPER_ENTRY`。

### WNBA、NBA 与 CBA 的独立评估通道

训练、校准、回测、残差、CLV/滑点和策略统计必须至少按具体联赛分开输出，禁止用 WNBA 样本校准 NBA/CBA，或用 NBA/CBA 的残差、特征权重、阈值和结果替代 WNBA。WNBA 只使用 WNBA 可验证的基础数据、时间衰减对手校正岭回归及其自身冻结的残差合同；WNBA 数据不足时降级为诊断，而不是借用男子联赛样本补足。

NBA 与 CBA 的让分纸面决策除通用数据门槛外，强制要求赛前可核验的伤停状态、轮休/预计上场时间和 NetRtg（或同定义、同窗口的可审计高级效率上下文）。任何一项缺失、过期、赛后才发布、口径不明或球队映射冲突，必须输出`SPREAD_CONTEXT_INCOMPLETE`并禁止让分`PAPER_ENTRY`；仍可保留独立诊断和缺失证据。该拦截不允许用盘口、最终比分、默认健康阵容或跨联赛平均数绕过。

每轮生产报告、公开 JSON 和页面必须显示：league、tier、基础/调整后残差 scale、`DIAGNOSTIC_ONLY`或上下文阻塞原因、总分胶着局/OT/末节证据状态，以及按联赛分开的执行延迟样本计数。首写、冻结预测、真实盘口原始快照、历史账本和真实执行关闭原则优先于任何新规则；新规则只能约束未来生成的诊断与纸面决定，不得回写既有记录。

## v2.4 同场双市场、总分分层证据与联赛覆盖

### 同一比赛允许让分与总分各有一条独立建议

同一 `canonical_event_id` 可以同时产生一条 `SPREAD` 建议和一条 `TOTAL` 建议，但两条建议必须是两个互相隔离的市场记录：

- 决策主键为 `canonical_event_id + market_type`；同一场同一市场仍最多一条首写纸面决定。
- 每个市场分别保存 `selected`、盘口、赔率、概率、EV、阻塞项、首写时间、复核状态、结算和审计字段；不得用一个全场 `selected` 覆盖另一个市场。
- 让分通过而总分被阻断时，允许输出“让分纸面可投、总分诊断观察”；总分通过而让分未通过时反之。两条建议都必须单独显示，不能因另一市场失败而隐藏。
- 纸面执行计数、结算、P&L、CLV 和 `PRICE_EXHAUSTED` 均按 `market_type` 分组；同场双市场不是重复下注同一市场，也不允许合并成一张模糊建议。
- 真实执行仍永久关闭；页面使用“纸面让分建议”和“纸面大小分建议”，不得显示实盘下注。

### 总分证据门禁改为 Hard Blocker 与 Soft Missing 两层

`TOTAL_CONTEXT_INCOMPLETE` 不能再把所有缺失都视为完全不能定方向。总分必须先按以下层级处理：

**Hard Blocker：只能 `TOTAL_DIAGNOSTIC_ONLY`，不得给出大/小分纸面方向**

- 比赛身份、球队映射或联赛规则冲突/无法确认；
- 没有真实、同场、同规则的总分盘口；
- 没有基础攻防数据，且没有足够 Box Score 反推回合数；
- 只有最终得分、没有任何可审计的 FGA/FTA/ORB/TO 或 Pace 证据；
- 关键数据明显过期、互相矛盾，或使用了赛后才获得的信息。

**Soft Missing：允许形成带不确定性的总分预测，但不得伪装成完整证据**

- 伤停未知；
- 轮换/预计时间不完整；
- 三分资料部分缺失；
- 末节犯规环境或加时发生率暂时无法直接确认。

Soft Missing 必须扣减数据质量、扩大总分残差区间并在输出中列明缺项；不得因为这些缺项自动偏向大分或小分。只有总分市场存在、基本攻防和回合层级达到可执行最低等级、加时/常规时间规则已核验且纸面门槛仍通过时，才可输出 `SHADOW_BET` 或 `SHADOW_LIMIT_ONLY`；否则输出 `TOTAL_DIAGNOSTIC_ONLY`。

### 回合数、三分与比赛规则必须补全并冻结

总分核心使用：`ExpectedTotal = ExpectedPossessions × (ExpectedPPP_team1 + ExpectedPPP_team2)`，并在同一输入截止时间加入 ORtg/DRtg、eFG%、3PA rate、3P%、FT rate、ORB%、TOV%、阵容、休息、旅行、主场、末节和加时证据。历史总分均值只能作为辅助特征，不能单独决定方向。

回合数按证据等级计算并记录：

- `LEVEL_A`：来源直接提供 Possessions/Pace；
- `LEVEL_B`：双方至少有 `FGA + 0.44*FTA - ORB + TO` 的完整构成，按比赛复算；
- `LEVEL_C`：只有部分 Box Score 与历史 Pace，允许估计但扩大不确定度并降级；
- `LEVEL_D`：连上述资料都没有，触发 Hard Blocker。

生产采集必须优先解析 7M 或其它公开来源的 `Basketball_Team_Data/<team>/gb/n_history.js`。双方至少取得最近 8 场有效比赛的回合构成或直接 Pace，并保存每场的 FGA、FTA、ORB、TO、3PA、3PM、来源 URL、发布时间/抓取时间和输入哈希。三分至少计算赛前 3P% 均值、标准差及 3PA rate，供总分诊断和 `THREE_POINT_VARIANCE` 错因审计使用；不能用最终赛果倒填赛前资料。

常规时间与加时规则必须从 `config/game_rule_registry.json` 或等价官方规则来源确认并冻结。预测分差绝对值不超过 4.5 分时计算 `close_game_probability`；`late_foul_premium` 和 `ot_premium` 只可用同联赛真实样本估计，样本不足标为 `UNAVAILABLE`，不能写死默认分值。

### NBL、NCAA 与欧篮联覆盖规则

`NBL_AU`、`NCAAB`、`WNCAAB`、`EUROLEAGUE` 已属于正式联赛池，必须执行 broad source、官方/联赛专项源、球队历史源和盘口源的独立 UNION；不得因为当前日期没有赛事、单个源返回空数组或尚无可投建议而从页面和 coverage manifest 删除。

- `EUROLEAGUE` 当前按 Tier 2 进入成熟职业联赛通道；若没有至少 3 场同赛事有效历史、同场真实盘口、球队身份/规则确认或市场完整性验证，只能 `UNPRICEABLE`、`WATCH` 或 `PASS`，必须显示具体原因。
- `NBL_AU`、`NCAAB`、`WNCAAB` 当前按 Tier 3 高不确定性通道处理；这表示它们会被发现、抓取、独立定价和展示，但缺少近 30 天阵容稳定性/预计时间证据时只能 `DIAGNOSTIC_ONLY`，不能生成纸面单。补齐合格阵容稳定性、历史样本、规则和同场盘口后才可进入纸面门槛。
- NBL/NCAA 不推荐的原因必须拆成可审计枚举：`NO_EVENT_FOUND`、`NO_MARKET`、`INSUFFICIENT_HISTORY`、`ROSTER_STABILITY_MISSING`、`TOTAL_CONTEXT_INCOMPLETE`、`SPREAD_CONTEXT_INCOMPLETE`、`PROVIDER_DISAGREEMENT` 或 `EDGE_BELOW_THRESHOLD`；禁止统一写成“数据不足”。
- 每轮报告必须分别输出这些联赛的 `events_found`、`market_observed`、`independent_priceable`、`spread_recommendations`、`total_recommendations` 和各阻塞原因。未推荐不等于没有比赛。

### 深盘受让偏多：先校准中心，再校准残差

深受让比例偏高不得通过强行平衡方向、增加热门方权重、压低受让概率、手工修改公平分差或单纯放大残差解决。必须分开审计：

1. `Raw Independent Margin -> League/Global Mean Calibration -> Deep-Spread Calibration -> Calibrated Fair Margin`。使用冻结的严格 OOS/walk-forward 数据检查 `actual_margin = a + b * raw_model_margin`、intercept、slope、mean error、MAE、RMSE，并至少拆分 `NORMAL abs(market_spread)<10` 与 `DEEP abs(market_spread)>=10`。
2. 中心校准完成后才使用 Student-t residual scale 描述不确定性。scale 优先级为联赛 OOS 实证乘数、Tier prior、global fallback；Tier 1/2/3 的 1.00/1.15/1.45 只是 cold-start prior，不得当成永久参数，也不能改变 Calibrated Fair Margin 中心。
3. 深受让比例异常只触发 `DEEP_SPREAD_BIAS_DIAGNOSTIC`，检查 Margin Compression、联赛漂移、伤停/轮换覆盖、垃圾时间、板凳深度、大胜概率和热门方上限，不自动改变估值。

每条信号必须分离保存 `raw_model_margin`、`calibrated_fair_margin`、`market_spread_at_signal`、`cover_probability`、`expected_value`、`residual_scale`、`league_multiplier` 和 `model_version`；执行层另存实际执行盘口、价格、终盘、slippage 与 CLV。`Line Movement`、`CLV` 和 `Execution Slippage` 不得混称。盘口向模型方向移动不自动等于 `PRICE_EXHAUSTED`，只有当前剩余 EV 低于最低门槛才可标记。

### 结算错因审计（Failure Audit Ledger）

错因审计的唯一策略配置是`config/failure_audit_policy.yaml`。每次新增或修正为已验证`LOSS`的结算，必须在冻结预测、首写合同和赛果结算之后，自动向`outputs/basketball_odds_trader/audits/post_mortem.json`追加一条审计卡。审计只解释已发生的偏差，绝不回写首写预测、盘口、决定、赛果、结算、残差参数、Kelly 或模型权重；真实执行仍永久关闭。

每条审计至少写入`prediction_id`、`event_id`、`settlement_id`、`market_type`、首写方向与合同、冻结输入哈希、赛果来源、审计时间和如下 JSON 核心字段。`hard_evidence`只能填入实际取得且可复核的原始指标、数值、阈值与来源；不得以“表现不佳”“防守松懈”“手感火热”等主观形容词替代指标。

```json
{
  "event_id": "7m:xxxx",
  "failure_label": "GARBAGE_TIME_COVER | THREE_POINT_VARIANCE | ROSTER_NOISE | FOUL_ENGINE_BURST | CAUSE_UNKNOWN_INSUFFICIENT_DATA",
  "hard_evidence": {
    "metric_name": "Q4_margin",
    "metric_value": -12,
    "threshold_triggered": "<= -8",
    "source_ref": "immutable raw score snapshot"
  },
  "audit_passed": true,
  "reasoning_chain": "首写让分合同在第三节结束时仍覆盖；所选一方第四节净负12分，最终让分结算为LOSS，满足已配置的Q4净负至少8分阈值。"
}
```

标签必须按以下可量化规则判定，并且只有全部`requires`字段来自赛前冻结记录或可信赛后原始赛果/技术统计时才能`audit_passed=true`：

1. `GARBAGE_TIME_COVER`仅适用于让分 LOSS：第三节结束时所选方向按首写让分仍覆盖、所选方第四节净负至少8分、最终为 LOSS，并具备分节比分与让分合同。标签是量化末节吞噬模式，不得据此声称已证明替补上场或比赛态度。
2. `THREE_POINT_VARIANCE`适用于让分或总分 LOSS：必须有赛前冻结的同赛事最近10场三分命中率均值和标准差，以及双方赛后命中/出手。所选方或对手的实际三分命中率相对该赛前基线绝对 z-score 至少2.5，记录是哪支队、基线、实际值和 z-score。没有赛前基线，不能以赛后十场回填。
3. `ROSTER_NOISE`适用于让分或总分 LOSS：冻结赛前资料显示核心球员预计至少20分钟，赛后正式出场时间少于10分钟，且首写阵容快照没有捕捉到相应限制。必须记录球员、预计/实际分钟、赛前来源和赛后技术统计；没有预计分钟或实际分钟时不得推断伤停或轮休。
4. `FOUL_ENGINE_BURST`仅适用于总分 LOSS：常规时间最后120秒得分超过常规时间总分的15%，且与首写总分合同的失效方向一致。记录末120秒得分、常规时间总分、比例、是否含加时和总分结算。加时得分不得混入该指标。

若某条 LOSS 缺分节、三分、分钟、赛前基线或其它必要证据，或者所有可验证规则均未触发，必须写`CAUSE_UNKNOWN_INSUFFICIENT_DATA`，`audit_passed=false`，并在`reasoning_chain`逐项列明缺失的字段/来源。不得猜测原因，也不得仅因最终比分偏离预测给出特定标签。存在多个已满足标签时，按`ROSTER_NOISE`、`GARBAGE_TIME_COVER`、`FOUL_ENGINE_BURST`、`THREE_POINT_VARIANCE`的顺序选定一个主标签；其余已验证指标可附于`secondary_hard_evidence`，每项同样必须有数值、阈值与来源。

错因审计是风险监控，而不是赛后自动调参器：`GARBAGE_TIME_COVER`只能提出未来深盘末节风险的研究假设；`THREE_POINT_VARIANCE`归为不可控随机噪声，不调整基础参数；`ROSTER_NOISE`必须记录数据时效性缺失并加强未来赛前来源要求；`FOUL_ENGINE_BURST`只能进入同联赛胶着局溢价的候选校准队列。任何参数、权重、阈值或执行规则的改变都需要足量独立原生前向样本、分联赛评估和单独授权，禁止因单场或小样本失败自动修改。

页面与日报必须显示已结算纸面 LOSS 是否已有错因审计、主标签和`audit_passed`。不存在足够证据时必须明确显示“错因未确认：数据不足”，不能用空白、默认原因或主观文案掩盖。`post_mortem.json`为追加式账本；后续补充证据只能新建带版本与时间戳的审计修订，不得覆盖初版审计。

## v3.1 Pricing Funnel Diagnostic（只读诊断）

每次真实生产运行在不改变模型、阈值、Evidence Gate、fallback、纸面决定、账本或真实执行状态的前提下，必须生成定价漏斗诊断。诊断只读取本轮冻结的 `event`、`market`、`pricing` 和 `execution` 行，不把诊断结果反写回这些字段。

标准阶段为：`DISCOVERED -> CANONICALIZED -> MARKET_FOUND -> LEAGUE_RULE_READY -> TEAM_MAPPING_READY -> HISTORY_READY -> BASE_STATS_READY`，之后让分与大小分分叉为 `SPREAD_FEATURES_READY -> SPREAD_PRICEABLE` 和 `TOTAL_FEATURES_READY -> TOTAL_PRICEABLE`，再分别进入 `EVIDENCE_GATE -> EDGE_GATE -> EXECUTION_GATE`。大小分缺证据不得把整场让分一起标成无法定价。

每个市场只能有一个 `primary_block_stage` 与 `primary_block_reason`，按第一个未通过阶段确定；其余阻塞只进入 `secondary_warnings[]`。状态必须区分：`NOT_PRICEABLE`、`PRICEABLE_NO_EDGE`、`EDGE_FOUND_EVIDENCE_BLOCKED`、`EDGE_FOUND_EXECUTION_BLOCKED`、`SHADOW_TRIGGERED`。缺失数字保持 `null`/空值，不得填零。

诊断至少区分以下归因：`FIXABLE_DATA_ENGINEERING`、`GENUINE_DATA_ABSENCE`、`MODEL_LIMITATION`、`INTENTIONAL_RISK_BLOCK`。必须检查联赛/层级/地区/全局注册表、历史与球队别名链、回合数可复算路径、联赛规则和残差 scale fallback 是否实际被调用；“文件存在”不等于 fallback 已生产验证。Hard Missing 与 Soft Missing 分开统计，伤停未知、轮换未知、三分细节缺失、末节犯规样本不足和 OT 证据不足不能未经现有规则明确规定就被诊断为 Hard Block。

生产入口每轮输出：

```text
D:\codex\outputs\basketball_odds_trader\diagnostics\pricing_funnel_YYYYMMDD.csv
D:\codex\outputs\basketball_odds_trader\diagnostics\pricing_funnel_summary_YYYYMMDD.json
D:\codex\outputs\basketball_odds_trader\diagnostics\pricing_funnel_summary_YYYYMMDD.md
```

CSV 每行一场比赛，必须同时含赛事身份、北京时间、让分/大小分盘口存在性、canonical/规则/球队映射/历史/基础数据阶段、两条市场的 feature ready 与 priceable、各自 primary 阶段/原因、secondary warnings、data/evidence quality、fair/market 值、edge 与最终状态。JSON/Markdown 必须包含总赛事、让分/大小分独立漏斗、每一步转化率、按联赛与地区统计、各市场 Top blocking reasons 及占全部阻塞比例、Hard/Soft 清单、四类归因、fallback 审计和 15 项结论：市场为何未定价、让分数、大小分数、最大损耗阶段、Top 10 原因、四类问题、工程修复上限、仍应不可定价数、提前 return 证据、Hard/Soft 混淆、已配置但未使用的 registry、工程修复后的非保证性估计。

页面必须增加可展开的“定价漏斗诊断”区域，展示总赛事、盘口、映射、历史、基础数据、让分可定价、大小分可定价、Edge、纸面触发、最大瓶颈和前五阻塞；逐场详情必须能查看两条市场的阶段和主次原因。该区域是审计信息，不是额外的下注建议。诊断结束后只给出 P0/P1/P2 修复优先级，禁止在同一阶段实施修复或为了增加纸面机会降低任何门槛。

## v3.2 Pricing Funnel Terminal Accounting & History Readiness（只读诊断）

定价漏斗诊断必须把每个 `event × market_type` 记录分配到且仅分配到一个终态：`NO_MARKET`、`STALE_MARKET`、`RULE_BLOCKED`、`MAPPING_BLOCKED`、`HISTORY_BLOCKED`、`BASE_STATS_BLOCKED`、`FEATURE_BLOCKED`、`PRICEABLE_NO_EDGE`、`EVIDENCE_BLOCKED`、`EXECUTION_BLOCKED` 或 `SHADOW_TRIGGERED`。`events_total × market_types` 必须等于终态计数总和；不相等必须输出 `FUNNEL_ACCOUNTING_ERROR`，不能用 `events - priceable` 作为“未定价”。

漏斗顺序固定为：`events_total -> market_found -> FRESH_MARKET -> canonical/rule/mapping -> history -> base/features -> priceable -> evidence/edge/execution`。没有盘口与盘口过期分别记为 `NO_MARKET` 与 `STALE_MARKET`；过期盘口不得静默进入历史或执行分支。摘要必须同时提供 `market_found_but_not_priceable` 与 `fresh_market_but_not_priceable`，并分别列出 `no_market`、`stale_market`、`fresh_market` 与 `priceable`。

每次生产运行还必须生成球队级历史就绪瀑布：原始抓取 -> 球队别名匹配 -> 联赛/competition 匹配 -> 截止时间前 -> 有效比分 -> 去重 -> 可用样本。每个球队至少保存 canonical id、原始队名、联赛、来源、抓取是否尝试/成功、各阶段场次、最低要求、是否 ready 和首要失败原因。失败原因使用固定枚举：`HISTORY_SOURCE_FAILED`、`TEAM_ALIAS_HISTORY_MISMATCH`、`LEAGUE_ALIAS_HISTORY_MISMATCH`、`NO_PRE_CUTOFF_HISTORY`、`TOO_FEW_PRE_CUTOFF_GAMES`、`HISTORY_FILTER_TOO_STRICT`、`SEASON_TRANSITION_FILTER`、`COMPETITION_ID_MISMATCH`、`DATE_TIMEZONE_FILTER_ERROR`、`DUPLICATE_REMOVAL_OVERFILTER`、`INVALID_SCORE_FILTER`、`SOURCE_HISTORY_GENUINELY_ABSENT`。不得把解析成功但过滤掉的历史统称为“没有数据”。

历史来源审计必须报告 raw -> alias -> league -> pre-cutoff -> valid -> dedup -> usable 的计数、地区别名匹配、联赛过滤移除、日期/时区拒绝、无效比分、重复删除，以及 ESPN/SofaScore 等来源的尝试/失败/fallback/early-return 轨迹。无法从运行时证据证明 fallback 是否调用时，必须写 `NOT_INSTRUMENTED` 或 `NOT_PROVEN`，不能声称已修复。工程修复、来源降级、真实数据缺失、模型要求四类只能用于诊断，不得自动放宽既有定价门槛。

v3.2 的诊断区域必须在 Dashboard 中可展开，并允许逐场查看双方球队历史。该区域只读，不修改 pricing、Evidence Gate、阈值、sigma、纸面决定、ledger 或真实执行状态。

## v3.0 全球赛事发现与生产覆盖

每日生产入口必须先运行 `scripts/global_discovery.py`，建立全球篮球赛事池，再由 `scripts/odds_discovery.py` 为每场赛事查询盘口。7M 是重要盘口源，不是赛事存在的唯一入口。赛事没有盘口时必须保留为 `DISCOVERED_ONLY / NO_MARKET`。

标准链路：`GLOBAL EVENT DISCOVERY -> CANONICAL EVENT REGISTRY -> ODDS DISCOVERY -> ENRICHMENT -> INDEPENDENT PRICING -> SHADOW ELIGIBILITY -> EXECUTION ELIGIBILITY`。

每场赛事必须保存五级状态：`DISCOVERED_ONLY`、`MARKET_FOUND`、`PRICEABLE`、`SHADOW_ELIGIBLE`、`EXECUTABLE`。状态只允许由实际字段和证据升级，不允许因盘口缺失删除赛事，也不允许因模型有 Edge 自动升级为可执行。

`config/league_registry.yaml` 是注册表，不是生产覆盖证明。每个联赛至少维护 canonical id/name、国家/地区、family、competition type、性别、年龄组、赛制分钟、发现源、盘口源、统计源、别名和 active status。未知赛事进入 `UNCLASSIFIED_DISCOVERED` 与 `PENDING_LEAGUE_CLASSIFICATION`，不得静默归入 `OTHER_DISCOVERED`。

生产状态必须区分：`REGISTERED`、`DISCOVERY_ACTIVE`、`MARKET_ACTIVE`、`PRICING_ACTIVE`、`PRODUCTION_VERIFIED`、`CONFIGURED_ONLY`、`TEST_ONLY`、`DISCOVERY_ONLY`、`FAILED`。只有 `PRODUCTION_VERIFIED` 才能称为真实生产覆盖。

中国联赛必须分别识别 `CHINA_CBA`、`CHINA_WCBA`、`CHINA_NBL`、`CHINA_CUBA`、`CHINA_UNIVERSITY_OTHER`、`CHINA_YOUTH`、`CHINA_CLUB_CUP`、`CHINA_FRIENDLY`。FIBA 每日必须主动尝试 `FIBA_MEN`、`FIBA_WOMEN`、`FIBA_QUALIFIER`、`FIBA_CONTINENTAL`、`FIBA_YOUTH`、`FIBA_FRIENDLY` 官方赛事日历；官方源只负责发现，盘口源单独负责市场。官方源不可访问时记录健康状态，不能解释成当天没有国家队比赛。

日本/韩国、大洋洲、欧洲、美洲、海湾及其他亚洲赛事进入对应 family；欧洲新赛事进入 pending onboarding。新联赛默认 `COLD_START`，样本数规则为 `<20 DISCOVERY_ONLY`、`20-49 WEAK_SIGNAL`、`50-99 PROVISIONAL`、`>=100 META_CALIBRATION_ELIGIBLE`，不因扩大研究池降低 spread/total Evidence Gate。

所有来源能力写入 `config/source_capabilities.yaml`。赛程、结果、统计、伤停、阵容和盘口是独立能力。盘口路由必须记录 source、时间、匹配方法、市场状态和失败原因；不得用历史均值、Fair Line 或模型值冒充真实盘口。多源盘口必须 reconciliation，7M 无盘口只记 `7M_MARKET_NOT_FOUND`。

每日输出并在 v2 页面显示：`TOTAL DISCOVERED -> MARKET FOUND -> DATA READY -> PRICEABLE -> SHADOW SIGNAL -> EXECUTABLE SIGNAL`，同时按中国、日本韩国、欧洲、北美、拉美、FIBA、大洋洲、海湾和其他亚洲拆分。页面还必须列出无盘口、数据不足、无法定价和未识别联赛的实际赛事与原因。

新增来源必须先验证可访问、赛事识别、队名映射、北京时间、盘口字段、让分方向和总分字段，并在 health 中标记 `PRODUCTION_READY` 或失败状态。历史回填与 `FORWARD_NATIVE` 严格分离并标注 `HISTORICAL/OOS/PROSPECTIVE`；不能用历史回填伪装为今日前向输入。

## v3.3 冷启动与 Bootstrap 定价治理

冷启动只解决“新联赛有真实历史但不足以走成熟通道”的研究定价问题，不是降低正式门槛的办法。实现配置唯一来源为 `config/cold_start_pricing.yaml`，其中的历史权重、竞争强度调整、ESS 门槛和残差放大系数均是可审计 prior，必须在独立前向样本上评估后才能申请调整，禁止用最近胜负自动调参。

每场必须分别保存以下三层状态：

- `RESEARCH_PRICE`：只表示独立模型可以在冻结输入上产生公平分差/总分；不需要市场，也不等于有交易方向。
- `SHADOW_BET`：必须同时具备本轮真实、同场、同规则盘口，独立定价，原有证据门禁和 Edge 门槛；真实执行永久关闭。
- `EXECUTABLE_BET`：当前系统保留的最高治理层。冷启动、国家队 Bootstrap、`PRIOR_ONLY_PRICE` 均不得进入该层，当前全局 `real_execution_allowed` 永远为 `false`。

成熟通道不得改写：同赛事身份、截止前、已确认终场、最小历史场次、对手覆盖、伤停/轮换/NetRtg、高不确定性阵容稳定性、总分回合/效率/规则和市场完整性门槛仍按原规则执行。只有成熟通道不足时，才可以在 `TEAM_HISTORY` 证据上进入 Bootstrap；`H2H`、搜索摘要、赛后资料、最终阵容倒推和没有时间证据的行不得借力。

Bootstrap 历史权重按 `season_bucket × competition_strength_adjustment` 计算：当前赛季为 `1.0`，前一有效赛季使用配置的 `0.50-0.70` 区间，较早历史使用 `0.20-0.40` 区间。竞争强度至少区分 Tier 1 continental、Tier 1 domestic、Tier 2 domestic、cup、friendly、national window 和 unknown。输出必须含原始场数、当前/前季/更早场数、每队及最小 `effective_sample_size`、关系类型、竞争调整和输入指纹；不能只报告 raw count。

冷启动状态定义：

- `NATIVE_PRICEABLE`：成熟通道按原有同赛事历史产生定价。
- `COLD_START_PRICEABLE`：Bootstrap 历史达到配置的研究 ESS，可产生扩大残差的不确定性研究价；默认不具备 Shadow 资格。
- `NATIONAL_TEAM_BOOTSTRAP`：使用 12-24 个月国家队历史、FIBA/Elo 先验（若已真实取得）、阵容强度、球员俱乐部强度、赛事类型、主客/中立场、休息和旅行证据；名单未知会扩大不确定性，不能凭空补全。
- `PRIOR_ONLY_PRICE`：只有先验、没有足够赛前球队比赛事实时，只能诊断观察，不得产生纸面方向。

冷启动允许的残差放大必须写入预测快照和输出；它不能永久硬编码为最终校准系数。`COLD_START_PRICEABLE` 若要进入 `COLD_START_SHADOW`，必须同时满足配置的 shadow ESS、当前赛季最低场数、近 30 日阵容连续性、市场质量和原有 Evidence/Edge/执行门槛。任何一项缺失都必须输出具体 blocker，不得用盘口或最终比分替代。

职业球队可以跨国内联赛、EuroLeague、EuroCup、杯赛和热身赛进入 Team State History，但每行必须携带竞争调整和证据关系；跨赛事只能提高研究覆盖，不能把不同赛事当作同源独立样本。WNBA、NBA、CBA、EuroLeague、NBL、国家队的训练、残差、CLV、滑点、结算和错误审计必须分联赛/模型通道隔离。

联赛生命周期固定为 `DISCOVERY -> BOOTSTRAP -> SHADOW -> PROVISIONAL -> QUALIFIED`。升级只能基于有效 ESS、独立前向样本量、校准、CLV、MAE/RMSE、Brier、数据质量和市场质量；最近几场赢球、纸面盈利或单次回测不得触发升级。每日 JSON、审计报告和页面必须展示各 family 的发现数、盘口数、本季/前季历史、ESS、研究定价、冷启动定价、Shadow 和 Executable 数；缺失数据保持 `null`，不填 0。

结算学习层必须把 `NATIVE_PRICEABLE`、`COLD_START_PRICEABLE`、`NATIONAL_TEAM_BOOTSTRAP` 和 `PRIOR_ONLY_PRICE` 分开统计 MAE、RMSE、CLV、cover calibration、ROI 与残差规模。历史重建只作 OOS/研究证据，不能回写冻结预测、首写盘口、决定、账本或当前模型参数。真实下注永远禁止。

## v3.4 总分盘口可见性与全链路审计

总分盘口不得因为总分证据不足、独立定价失败、Edge 不足或未触发纸面执行而从页面和数据中消失。总分必须沿用独立的生命周期：`TOTAL_MARKET_FOUND -> TOTAL_MARKET_FRESH -> TOTAL_PRICEABLE -> TOTAL_EVIDENCE_COMPLETE -> TOTAL_EDGE_FOUND -> TOTAL_SHADOW_ELIGIBLE -> TOTAL_EXECUTABLE`。每个阶段独立记录；`TOTAL_MARKET_FOUND` 不等于可投注，`TOTAL_PRICEABLE` 也不等于有优势。

生产运行必须同时保留 `RAW -> PARSED -> NORMALIZED -> CANONICAL -> FRESH` 的总分审计。每场保存原始总分、双方赔率、公司、源报价时间、抓取时间、报价年龄、标准化状态、事件绑定状态和所有阻塞原因；缺失数值使用 `null`，不得用 `0` 伪装。让分与总分分别计算，不能因为让分分支有盘口或有纸面结论而隐藏总分。

总分市场审计文件为 `outputs/basketball_odds_trader/diagnostics/total_market_pipeline_YYYYMMDD.csv` 及同日 JSON 摘要。页面必须显示总分已抓到、新鲜、可独立定价、证据完整、有 Edge、纸面触发的分层数量，并提供“有总分盘口”“总分可定价”“总分有优势”筛选。证据门槛仍严格执行：真实盘口先展示，再明确标记 `TOTAL_CONTEXT_INCOMPLETE`、`TOTAL_NOT_PRICEABLE`、`TOTAL_NO_EDGE` 或 `TOTAL_MARKET_NOT_FRESH`，不得为了填满页面降低回合、效率、三分、阵容、末节和加时证据要求。

7M 解析必须在同一 `bOdds` 事件下独立解析 `HB` 让分和 `TP` 总分。任一盘口数组格式错误时，错误记录必须携带 `market_type`、原始市场键和 `loss_stage`；一个盘口失败不得提前返回并丢弃另一市场。页面的市场比较区必须展示已抓到的原始总分，即使它没有被选为有效比较报价；盘口原文详情仍保留全部公司、双边赔率和时间。该版本只修复可见性和审计，不修改总分公式、概率、sigma、Evidence Gate、Edge、Kelly、纸面决定或真实执行状态。

## v3.5 总分近况与分节证据层

总分诊断必须在每场可用的截止时间前终场事实中，单独保存双方最近 `5` 场和 `10` 场：总分、球队得分、对手得分、分差、Q1-Q4/加时得分、总分波动、分差波动、14 日比赛密度和相邻比赛休息间隔。必须保留 `event_id`、`tip_at`、来源 URL/raw snapshot、抓取时间和输入截止时间，禁止使用截止时间后的赛果或修订。

末节结构必须分开统计：赛前三节分差 `<=8` 分定义为胶着局样本，`>=15` 分定义为大分差/垃圾时间代理样本；同时报告两类样本的 Q4 总分和样本量。该分类只描述可量化的历史场景，不把“领先/落后”或 Q4 得分直接当成回合数、三分率、犯规率、伤停、轮换或旅行数据。

总分方向分析必须同时考虑：近期 5/10 场总分趋势、分节得分变化、胶着局末节犯规/加时证据是否真实存在、领先与大分差场景、得分方差、赛程密度和休息间隔，以及当前真实总分盘口。盘口上升或下降本身不得直接解释为大分或小分；必须先对照上述证据。缺少具体变量时输出 `UNKNOWN`/`INSUFFICIENT_DATA`，不允许从盘口或最终比分补猜。

比分与分节数据属于 `FINAL_SCORE_AND_PERIODS_ONLY` 证据层：可以用于总分基线、状态和波动诊断，但不得冒充回合数、Pace、三分命中率、末节犯规或阵容变化。后四类变量只有在来源明确、时间有效且字段语义已验证时，才可升级对应 Evidence Gate。若总分已有真实盘口但回合/效率/规则等硬证据仍缺失，仍必须保留盘口并显示 `TOTAL_CONTEXT_INCOMPLETE`，不得为了产生推荐放松门槛。

Dashboard 必须展示“近况、分节与赛程波动（总分证据）”区域，并能逐队查看近 5/10 场均值、Q1-Q4 总分、波动和 14 日场次；同时显示“未从比分推断回合/三分/犯规/伤停/旅行”的审计提示。总分盘口没有消失，只是在 `TOTAL_MARKET_FOUND`、`TOTAL_MARKET_FRESH`、`TOTAL_PRICEABLE`、`TOTAL_EVIDENCE_COMPLETE`、`TOTAL_EDGE_FOUND` 和 `TOTAL_SHADOW_ELIGIBLE` 之间如实停留。

## v3.6 Edge Funnel 与零触发审计

本版本新增的是只读诊断层，不是新定价模型。不得修改 Fair Spread、Fair Total、Evidence Gate、Edge threshold、Residual Scale、Meta Calibration、Market Weight、Execution threshold、Paper trigger、Champion model、历史首写或账本。诊断运行在冻结预测与决定之后，不能把诊断字段反写为模型输入或纸面决定。

完整漏斗必须按 `market_type` 独立计算，且至少输出：

`DISCOVERED -> MARKET_FOUND -> FRESH_MARKET -> RESEARCH_PRICEABLE -> MARKET_COMPARABLE -> RAW_EDGE_FOUND -> CALIBRATED_EDGE_FOUND -> EVIDENCE_PASS -> EXECUTION_PASS -> SHADOW_TRIGGERED`

让分与总分不能合并成一个“独立定价”数字。`MARKET_COMPARABLE` 只统计同一赛事、同一市场、同一时段、同一加时结算规则、存在新鲜有效盘口并且已完成独立定价的记录；盘口存在、研究价存在或旧报价存在，都不能单独算作可比较样本。

`31 -> 16` 必须对每个 `game_id × market_type` 产生唯一 `primary_final_reason`，并区分：`NO_MATCHING_MARKET`、`MARKET_TYPE_MISMATCH`、`RULE_MISMATCH`、`STALE_MARKET`、`INVALID_MARKET`、`SOURCE_CONFLICT`、`CANONICALIZATION_MISMATCH`、`RESEARCH_ONLY_NO_MARKET`、`OTHER`。不能用“无法比较”吞掉真实原因。

Raw Edge 只表示独立模型公平线与同场真实市场线的差异，未经 Meta Calibration、Residual Scale、Market Prior 或 Probability Calibration：

- 让分：`raw_edge_points = raw_fair_spread - market_spread`。
- 总分：`raw_edge_points = raw_fair_total - market_total`。

诊断保存 `raw_fair_line`、`market_line`、`raw_edge_points`、`raw_cover_probability`。只有生产模型明确输出 `calibrated_fair_line` 或等价校准字段时，才保存 `calibrated_edge_points`、`adjusted_probability` 与 `adjusted_EV`；不得从市场融合线倒推出“校准后公平线”。缺失保持 `null`，不能填 0。

对可比较样本必须逐层输出 `Comparable`、`Raw Edge Found`、`Calibrated Edge Found`、`Evidence Pass`、`Execution Pass`、`Shadow Triggered`，并为每个样本只保留一个最终原因：`NO_RAW_EDGE`、`EDGE_REMOVED_BY_CALIBRATION`、`CALIBRATED_EDGE_BELOW_THRESHOLD`、`PROBABILITY_BELOW_THRESHOLD`、`NEGATIVE_EV`、`EVIDENCE_BLOCKED`、`EXECUTION_BLOCKED`、`PRICE_EXHAUSTED`、`MARKET_MOVED`、`LOW_DATA_QUALITY`、`SHADOW_TRIGGERED`。可以保留多个 `secondary_warnings`，但不能用多个 primary 原因替代终态。

过度收缩只做审计：当 `abs(raw_edge_points) >= MIN_DIAGNOSTIC_EDGE_POINTS` 且存在明确校准 Edge 时，计算 `edge_retention_ratio = abs(calibrated_edge_points) / abs(raw_edge_points)`，输出均值、中位数和 `possible_over_shrinkage`。至少按 `SPREAD/TOTAL`、联赛、Tier、`NATIVE/COLD_START`、`DEEP_SPREAD/NORMAL_SPREAD` 分组；该阈值是诊断阈值，不是下注门槛，不得自动调参。

每次生产运行输出 `diagnostics/comparable_edge_YYYYMMDD.csv`，字段至少为：`game_id`、`league`、`market_type`、`home_team`、`away_team`、`start_time`、`pricing_mode`、`market_line`、`raw_fair_line`、`raw_edge_points`、`raw_probability`、`calibrated_fair_line`、`calibrated_edge_points`、`adjusted_probability`、`adjusted_EV`、`residual_scale`、`league_residual_multiplier`、`meta_confidence`、`model_weight`、`market_weight`、`data_quality`、`evidence_status`、`execution_score`、`edge_retention_ratio`、`primary_final_reason`、`secondary_warnings`。

Dashboard 必须使用真实诊断 JSON 显示 Edge Funnel，分别展示让分/总分各阶段数量，并在 `SHADOW_TRIGGERED = 0` 时显示“今日为什么 0 场”及可比较样本的 primary reason 分布。页面中的该区域只读，明确说明不修改公平线、概率、证据门槛或执行决定。诊断文件缺失、校准字段未输出或盘口不可比较时，页面必须显示缺失/阻塞，不得把空值渲染为 0 后宣称没有 Edge。

## v3.7 P0 结构审计与方向偏置监控

P0 审计必须继续使用现有 `repair_v22`、Forward Native 首写账本和当前 Dashboard，不得另建篮球系统，不得删除历史账本、Learning Engine、Error Attribution、Meta Calibration、Champion/Challenger、Spread/Total、Cold-start、Pricing Funnel、League Decision Funnel 或 HTML 页面。

每笔新产生的 Spread 决定必须尽量永久保存完整 Fair Spread 分解：`raw_team_strength_home`、`raw_team_strength_away`、`raw_expected_home_score`、`raw_expected_away_score`、`raw_independent_margin`、`after_mean_calibration_margin`、`after_deep_spread_calibration_margin`、`market_spread`、`model_market_gap`、`betting_fair_spread`、`base_residual_scale`、`tier_residual_multiplier`、`league_residual_multiplier`、`deep_spread_residual_multiplier`、`raw_cover_probability`、`calibrated_cover_probability`、`final_cover_probability`、`expected_value`、`selected_side`。尚未实现的校准层必须保留 `null` 并标记缺失原因，不能用 Raw 值冒充已校准值。

每次生产运行必须生成只读 `diagnostics/p0_bias_audit_YYYY-MM-DD.json` 与 Markdown 摘要，并在 Dashboard 提供可展开区域，至少包括：Favorite/Underdog 方向统计（last 10/20/50、rolling 7d、all Forward Native）、WNBA 专项统计、概率双边一致性、`actual_margin = a + b * predicted_margin` 的 Forward Native 描述性回归、预测分差 bucket、Normal/Deep Spread 分桶、PnL 集中度、联赛 Market Freshness 和 Ridge/校准审计状态。

`UNDERDOG_DIRECTION_BIAS` 与 `SEVERE_UNDERDOG_DIRECTION_BIAS` 只能报警，不能自动平衡上下盘、强制 Favorite、修改具体 Fair Spread、改变 Edge 门槛、Residual Scale、市场权重或 Champion。若样本不足以分离 OOS、Walk-forward 与 Prospective，应明确输出 `NOT_ENOUGH_SEPARATE_OOS_WINDOWS`，不得把同一批前瞻样本拟合后的 slope 当成验证结果。

概率一致性必须逐场检查 `P(home cover) + P(away cover) + P(push) ≈ 1`，并保留 Counterfactual Favorite 的概率/EV；发现 sign、home/away 或方向转换异常时只记录审计，不回写历史决定。深盘 `15+` 的小样本收益必须标记 `SMALL_SAMPLE_OUTLIER`，总体收益集中在少数交易时标记 `PNL_CONCENTRATION_HIGH`。真实执行继续永久关闭，任何审计结果不得因单日 W/L 自动调参。
