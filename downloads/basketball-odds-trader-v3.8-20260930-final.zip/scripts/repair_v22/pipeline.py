from __future__ import annotations
import json, shutil, subprocess, sys, uuid
from collections import Counter, defaultdict
from datetime import date, timedelta
from pathlib import Path
from . import VERSION
from .common import *
from .source import collect_live, replay_bundle
from .model import price_event, decide, quote_state
from .report import write_dashboard, project_row, csvwrite, funnel, cold_start_summary, HTML, standalone_preview
from .pricing_funnel_diagnostic import build_pricing_funnel_diagnostic
from .total_market_pipeline_diagnostic import build_total_market_pipeline_diagnostic
from .history_readiness_diagnostic import build_history_readiness_diagnostic
from .analytics import append_lifecycle_revision, build_analytics, lifecycle_config, _phase
from .p0_bias_audit import build_p0_bias_audit
from coverage_funnel import build as build_coverage

DEFAULT_CONTRACTS={'schema_version':1,'companies':{},'note':'Company rules must be evidenced; empty config means observation-only, not false executable success.'}

def _movement_direction(delta, positive_is_favorable):
    """Classify a same-selection price move without guessing a side."""
    if delta is None:
        return 'UNKNOWN'
    if abs(delta) < 1e-9:
        return 'UNCHANGED'
    return 'FAVORABLE' if (delta > 0) == positive_is_favorable else 'ADVERSE'


def _line_move_direction(market_type, selection, delta):
    # Quotes are normalized to the selected side. More points are better for a
    # spread selection; for totals, Over benefits from a lower number and
    # Under benefits from a higher number.
    if market_type == 'SPREAD':
        return _movement_direction(delta, True)
    if market_type == 'TOTAL':
        if selection == 'OVER':
            return _movement_direction(delta, False)
        if selection == 'UNDER':
            return _movement_direction(delta, True)
    return 'UNKNOWN'


def paper_market_revalidation(event, decision, asof, original_selected=None):
    """State whether this run would still pass the unchanged paper gate.

    The result is an observation of the current feed, not a replacement for a
    first-write paper decision or its later settlement.
    """
    base = {'checked_at': asof, 'event_id': event['event_id'],
            'current_selected': decision.get('selected'),
            'original_selection': original_selected,
            'comparison_ready': bool(decision.get('comparison_ready')),
            'blockers': list(decision.get('blockers', [])),
            'real_execution_allowed': False}
    if iso(event['tip_at']) <= iso(asof):
        return dict(base, status='EVENT_STARTED', display='比赛已开始，首写纸面单进入结算跟踪')
    if original_selected:
        same_contract = [candidate for candidate in decision.get('comparison_rows', [])
                         if candidate.get('bookmaker') == original_selected.get('bookmaker')
                         and candidate.get('market_type') == original_selected.get('market_type')
                         and candidate.get('selection') == original_selected.get('selection')
                         and candidate.get('ot_rule') == original_selected.get('ot_rule')]
        if not same_contract:
            return dict(base, status='REVALIDATION_UNAVAILABLE',
                        display='本轮未取得原纸面方向的同公司、同规则新鲜报价')
        candidate = max(same_contract, key=lambda item: item['adverse_ev'])
        base['current_selected'] = candidate
        cfg=lifecycle_config().get('revalidation_drift_limits',{}).get(original_selected.get('market_type'),{})
        old_line, new_line=original_selected.get('line'),candidate.get('line')
        old_odds, new_odds=original_selected.get('decimal_odds'),candidate.get('decimal_odds')
        line_delta=(float(new_line)-float(old_line)) if old_line is not None and new_line is not None else None
        odds_delta=(float(new_odds)-float(old_odds)) if old_odds is not None and new_odds is not None else None
        line_limit=cfg.get('max_line_change_points');odds_limit=cfg.get('max_decimal_odds_deterioration')
        material=(line_delta is not None and line_limit is not None and abs(line_delta)>float(line_limit)) or (odds_delta is not None and odds_limit is not None and odds_delta < -float(odds_limit))
        line_direction = _line_move_direction(original_selected.get('market_type'), original_selected.get('selection'), line_delta)
        odds_direction = _movement_direction(odds_delta, True)
        adverse_material = ((line_direction == 'ADVERSE' and line_delta is not None and line_limit is not None and abs(line_delta) > float(line_limit))
                            or (odds_direction == 'ADVERSE' and odds_delta is not None and odds_limit is not None and abs(odds_delta) > float(odds_limit)))
        base['market_difference']={'original_line':old_line,'current_line':new_line,'line_delta':line_delta,
                                   'original_decimal_odds':old_odds,'current_decimal_odds':new_odds,'odds_delta':odds_delta,
                                   'line_limit':line_limit,'odds_deterioration_limit':odds_limit,'material':material,
                                   'line_direction':line_direction,'odds_direction':odds_direction,
                                   'adverse_material':adverse_material,'requires_explicit_recheck':material}
        if candidate.get('research_edge_pass') and not decision.get('blockers'):
            if line_direction == 'FAVORABLE' or odds_direction == 'FAVORABLE':
                display = '当前同规则盘口或赔率对原纸面方向更有利；已按本轮报价重新审核，仍符合纸面条件'
            elif adverse_material:
                display = '盘口或赔率对原纸面方向不利，但已按本轮同规则报价重新审核，仍符合纸面条件'
            else:
                display = '原纸面方向按本轮同公司、同规则报价仍符合纸面条件'
            return dict(base, status='STILL_QUALIFIES',
                        display=display)
        display = ('真实盘口差异过大，经重新审核后本轮不投注；仅保留首写记录与后续结算跟踪'
                   if adverse_material else '原纸面方向已按本轮同公司、同规则报价重新比较，但未通过纸面条件')
        return dict(base, status='NO_LONGER_QUALIFIES',
                    display=display)
    if decision.get('triggered'):
        return dict(base, status='STILL_QUALIFIES', display='按本轮新鲜同规则盘口，仍符合纸面条件')
    if decision.get('comparison_ready'):
        return dict(base, status='NO_LONGER_QUALIFIES', display='本轮已重新比较，但未通过纸面条件')
    return dict(base, status='REVALIDATION_UNAVAILABLE', display='缺少本轮新鲜、同规则的可比较盘口')


def paper_market_revalidation_tracking(root, document, asof):
    """Audit fresh rechecks for immutable paper entries shown in this document."""
    records = []
    for row in document.get('events', []):
        original = row.get('execution') or {}
        if not original.get('triggered'):
            continue
        current = (row.get('current_snapshot') or {}).get('execution') or original
        review = current.get('market_revalidation')
        if not review:
            event = row.get('event') or {}
            if event.get('tip_at') and iso(event['tip_at']) <= iso(asof):
                review = {'status': 'EVENT_STARTED', 'checked_at': asof,
                          'display': '比赛已开始，停止赛前盘口复核，进入赛果结算跟踪'}
            else:
                review = {'status': 'REVALIDATION_UNAVAILABLE', 'checked_at': asof,
                          'display': '本轮未观察到该未开赛赛事，无法取得同公司、同规则的新鲜报价复核'}
        records.append({'event_id': row.get('id'), 'teams': [row.get('event', {}).get('team1_name'),
                        row.get('event', {}).get('team2_name')], 'first_write_prediction_id': original.get('prediction_id'),
                        'first_write_selection': original.get('selected'), 'revalidation': review})
    result = {'checked_at': asof, 'archive_type': 'FORWARD_NATIVE', 'records': records,
              'counts': dict(Counter(x['revalidation']['status'] for x in records)),
              'first_write_preserved': True, 'real_execution_allowed': False}
    atomic(Path(root)/'audits'/'paper_market_revalidation.json', result)
    return result

def settle_existing(root,history,asof):
    root=Path(root);facts={g['event_id']:g for g in history if g.get('status')=='FINAL'};count=0
    for f in (root/'ledger'/'repair_v22').glob('*/decision_*.json'):
        d=load(f,{})
        if d.get('archive_type')!='FORWARD_NATIVE' or not d.get('triggered') or d.get('real_bet_flag'):continue
        g=facts.get(d.get('event_id'));s=d.get('selected')
        if not g or not s:continue
        if not g.get('known_final_at') or iso(g['known_final_at'])>iso(asof):continue
        suffix='regulation' if s['ot_rule']=='REGULATION_ONLY' else 'full'
        original=load(f.with_name('input_'+d['prediction_id']+'.json'),{}).get('event',{})
        ids=(original.get('team1_id'),original.get('team2_id'))
        gid=(g.get('team1_id'),g.get('team2_id'))
        if None in ids or set(ids)!=set(gid):continue
        a,b=g['score1_'+suffix],g['score2_'+suffix]
        if ids==gid[::-1]:a,b=b,a
        if s['market_type']=='SPREAD':delta=(a-b if s['selection']=='TEAM1' else b-a)+s['line']
        else:delta=(a+b-s['line'])*(1 if s['selection']=='OVER' else -1)
        result='WIN' if delta>0 else 'LOSS' if delta<0 else 'PUSH'
        out={'prediction_id':d['prediction_id'],'event_id':d['event_id'],'archive_type':'FORWARD_NATIVE',
             'settled_at':asof,'outcome':result,'score1':a,'score2':b,'score_rule':s['ot_rule'],
             'paper_units':1,'paper_pnl':s['decimal_odds']-1 if delta>0 else -1 if delta<0 else 0,
             'outcome_raw_sha256':g.get('raw_sha256'),'close':None,'clv':None,'close_reason':'NO_VERIFIED_CLOSE_SNAPSHOT',
             'real_stake':0,'real_execution_allowed':False}
        path=root/'ledger'/'repair_v22_settlements'/(d['prediction_id']+'.json')
        if not path.exists():exclusive(path,out);count+=1
    return count


def _final_fact_index(root, current_history):
    """Read immutable final-score facts without treating a later page as pregame input."""
    facts = {g.get('event_id'): g for g in current_history if g.get('status') == 'FINAL' and g.get('event_id')}
    for capture_path in (Path(root) / 'raw' / 'repair_v22').glob('*/capture.json'):
        capture = load(capture_path, {})
        for game in capture.get('history', []):
            if game.get('status') == 'FINAL' and game.get('event_id'):
                facts.setdefault(game['event_id'], game)
    return facts


def _aligned_periods(event, fact):
    """Return period scores in the frozen event's team order, or no result on identity conflict."""
    p1, p2 = fact.get('period_points_team1'), fact.get('period_points_team2')
    original_ids = (event.get('team1_id'), event.get('team2_id'))
    fact_ids = (fact.get('team1_id'), fact.get('team2_id'))
    if not (isinstance(p1, list) and isinstance(p2, list) and len(p1) >= 4 and len(p2) >= 4):
        return None
    if None in original_ids or set(original_ids) != set(fact_ids):
        return None
    return (p2, p1) if original_ids == fact_ids[::-1] else (p1, p2)


def failure_audit_settlements(root, current_history, asof):
    """Append deterministic post-mortems for LOSS settlements; never revise first writes."""
    root = Path(root)
    path = root / 'audits' / 'post_mortem.json'
    previous = load(path, {'schema_version': 1, 'records': []})
    records = list(previous.get('records', []))
    known = {row.get('prediction_id') for row in records}
    facts = _final_fact_index(root, current_history)
    created = []
    for settlement_path in sorted((root / 'ledger' / 'repair_v22_settlements').glob('*.json')):
        settlement = load(settlement_path, {})
        pid = settlement.get('prediction_id')
        if not pid or pid in known or settlement.get('outcome') != 'LOSS':
            continue
        matches = list((root / 'ledger' / 'repair_v22').glob('*/decision_' + pid + '.json'))
        if not matches:
            continue
        decision = load(matches[0], {})
        frozen = load(matches[0].with_name('input_' + pid + '.json'), {})
        forecast = load(matches[0].with_name('forecast_' + pid + '.json'), {})
        event, selected = frozen.get('event', {}), decision.get('selected') or {}
        fact = facts.get(settlement.get('event_id'))
        missing = ['VERIFIED_FINAL_FACT_MISSING'] if not fact else []
        label = 'CAUSE_UNKNOWN_INSUFFICIENT_DATA'
        passed = False
        evidence = {'metric_name': 'required_failure_evidence', 'metric_value': None,
                    'threshold_triggered': 'not evaluable', 'source_ref': None}
        reasoning = ''
        periods = _aligned_periods(event, fact) if fact else None
        if selected.get('market_type') == 'SPREAD':
            if periods is None:
                missing.append('QUARTER_SCORES_MISSING_OR_TEAM_ORDER_CONFLICT')
            else:
                selected_index = 0 if selected.get('selection') == 'TEAM1' else 1
                other_index = 1 - selected_index
                selected_q3 = sum(periods[selected_index][:3])
                other_q3 = sum(periods[other_index][:3])
                q4_margin = periods[selected_index][3] - periods[other_index][3]
                line = selected.get('line')
                covering_at_q3 = line is not None and selected_q3 - other_q3 + float(line) > 0
                if covering_at_q3 and q4_margin <= -8:
                    label = 'GARBAGE_TIME_COVER'; passed = True
                    evidence = {'metric_name': 'Q4_margin', 'metric_value': q4_margin,
                                'threshold_triggered': '<= -8', 'source_ref': fact.get('raw_path')}
                    reasoning = ('按冻结让分合同，所选方向在第三节结束时仍覆盖；第四节净负%s分，'
                                 '最终让分结算为LOSS，满足量化末节吞噬定义。' % abs(q4_margin))
                else:
                    missing.append('GARBAGE_TIME_COVER_THRESHOLD_NOT_MET')
        elif selected.get('market_type') == 'TOTAL':
            missing.append('REGULATION_FINAL_120_SECONDS_SCORING_MISSING')
        # The current production source does not supply a verified frozen 3P
        # distribution or player-minute feed. Explicitly surface that absence.
        missing.extend(['FROZEN_SAME_COMPETITION_3P_BASELINE_MISSING',
                        'FINAL_3P_MAKES_ATTEMPTS_MISSING',
                        'FROZEN_EXPECTED_MINUTES_MISSING', 'ACTUAL_PLAYER_MINUTES_MISSING'])
        if not passed:
            reasoning = '无法对特定错因作出审计结论；缺少或未满足的证据：' + '；'.join(dict.fromkeys(missing))
        record = {
            'schema_version': 1, 'audit_id': pid + ':v1', 'prediction_id': pid,
            'event_id': settlement.get('event_id'), 'settlement_id': settlement_path.stem,
            'audit_at': asof, 'market_type': selected.get('market_type'),
            'frozen_selection': selected, 'frozen_forecast_fingerprint': decision.get('forecast_fingerprint'),
            'failure_label': label, 'hard_evidence': evidence, 'audit_passed': passed,
            'reasoning_chain': reasoning, 'missing_evidence': list(dict.fromkeys(missing)),
            'result_source_ref': fact.get('raw_path') if fact else None,
            'result_raw_sha256': fact.get('raw_sha256') if fact else None,
            'real_execution_allowed': False,
        }
        records.append(record); created.append(record); known.add(pid)
    result = {'schema_version': 1, 'generated_at': asof, 'append_only': True,
              'records': records, 'counts': dict(Counter(x.get('failure_label') for x in records)),
              'new_records': len(created), 'real_execution_allowed': False}
    atomic(path, result)
    return result


def sync_paper_settlements(root, asof):
    """Join immutable settlements to every dated page and latest, by prediction ID."""
    root = Path(root)
    settlements = {p.stem: load(p, {}) for p in (root/'ledger'/'repair_v22_settlements').glob('*.json')}
    records = {}
    for path in sorted((root/'dashboard_v2'/'data').glob('*.json')):
        if path.name != 'latest.json' and not (len(path.stem) == 10 and path.stem[:4].isdigit()):
            continue
        doc = load(path, {})
        changed = False
        for row in doc.get('events', []):
            decision = row.get('execution') or {}
            pid = decision.get('prediction_id')
            if not pid or not decision.get('triggered') or decision.get('archive_type') != 'FORWARD_NATIVE':
                continue
            settlement = settlements.get(pid)
            if settlement and settlement.get('event_id') == row.get('id'):
                if row.get('settlement') != settlement:
                    row['settlement'] = settlement
                    changed = True
            else:
                settlement = None
            records[pid] = {'prediction_id': pid, 'event_id': row.get('id'),
                'date_bj': row.get('event', {}).get('bj_date'),
                'selection': decision.get('selected'), 'first_write_at': decision.get('asof'),
                'outcome': settlement.get('outcome') if settlement else 'PENDING',
                'settlement': settlement}
        if changed:
            atomic(path, doc)
    result = {'checked_at': asof, 'archive_type': 'FORWARD_NATIVE',
              'records': list(records.values()), 'counts': dict(Counter(x['outcome'] for x in records.values()))}
    atomic(root/'audits'/'paper_settlement_tracking.json', result)
    return result


def review_previous_day(root, day, asof):
    """Review the prior Beijing day without changing its first-write decision."""
    root=Path(root);previous=(date.fromisoformat(day)-timedelta(days=1)).isoformat()
    data_path=root/'dashboard_v2'/'data'/(previous+'.json');document=load(data_path,{})
    settlement_dir=root/'ledger'/'repair_v22_settlements';settlements={}
    for f in settlement_dir.glob('*.json'):
        item=load(f,{})
        if item.get('event_id') and item.get('prediction_id'):settlements[item['prediction_id']]=item
    reviewed=[];changed=False
    for row in document.get('events',[]):
        decision=row.get('execution') or {};pid=decision.get('prediction_id')
        if not (decision.get('triggered') is True):continue
        item=settlements.get(pid)
        if item:
            if row.get('settlement')!=item:
                row['settlement']=item;changed=True
        reviewed.append({'event_id':row.get('id'),'team1':row.get('event',{}).get('team1_name'),
                         'team2':row.get('event',{}).get('team2_name'),'prediction_id':pid,
                         'paper_selection':decision.get('selected'),'outcome':item.get('outcome') if item else 'PENDING',
                         'score1':item.get('score1') if item else None,'score2':item.get('score2') if item else None,
                         'settlement_available':bool(item)})
    if changed:atomic(data_path,document)
    report={'date_bj':previous,'reviewed_at':asof,'paper_event_count':len(reviewed),
            'settled_count':sum(x['settlement_available'] for x in reviewed),'events':reviewed,
            'first_write_preserved':True,'real_execution_allowed':False}
    atomic(root/'audits'/('paper_review_'+previous+'.json'),report)
    return report

def run_capture(cap,output_root,day,context_map=None):
    root=Path(output_root);mode=cap['mode'];asof=cap['capture_finished_at'];run_id=cap['run_id'];contexts=context_map or {}
    # All artifacts for an audit are intentionally separate from the operational ledger.
    ledger=root/'ledger'/'repair_v22'/run_id;ledger.mkdir(parents=True,exist_ok=True)
    groups=defaultdict(list)
    for q in cap['quotes']:groups[q['event_id']].append(q)
    rows=[];audit=[];calls=[]; prior_entries=defaultdict(set); prior_decisions={}; prior_events={}; current_decisions={}
    if mode=='FORWARD_NATIVE':
        for f in (root/'ledger'/'repair_v22').glob('*/decision_*.json'):
            d=load(f,{})
            if d.get('archive_type')=='FORWARD_NATIVE' and d.get('triggered'):
                prior_entries[d.get('event_id')].add(d.get('prediction_id'))
                prior_decisions.setdefault(d.get('event_id'), d)
                prior_events.setdefault(d.get('event_id'), load(f.with_name('input_'+d.get('prediction_id','')+'.json'), {}).get('event', {}))
    for e in sorted(cap['events'],key=lambda x:(x['tip_at'],x['event_id'])):
        try:
            calls.append({'stage':'price_event','event_id':e['event_id'],'history_candidates':len(cap['history'])})
            # A price-blind dictionary is saved before decision code sees any quote.
            total_context=dict(cap.get('total_context',{}).get(e['event_id'],{}))
            total_context.update(contexts.get(e['event_id']) or {})
            pricing=price_event(e,cap['history'],asof,mode,total_context)
            pid=fingerprint({'event_id':e['event_id'],'input':pricing.get('input_fingerprint'),'asof':asof,'mode':mode,'version':VERSION})[:28]
            evidence_ids=set(pricing.get('used_history_ids',[]))
            inp={'event':e,'asof':asof,'archive_type':mode,'history':[g for g in cap['history'] if g['event_id'] in evidence_ids],
                 'history_pool_fingerprint':fingerprint(cap['history']),'model_version':pricing['model_version']}
            exclusive(ledger/('input_'+pid+'.json'),inp)
            exclusive(ledger/('forecast_'+pid+'.json'),pricing)
            # Collection may already have observed markets; the raw model has no market feature access.
            qs=groups.get(e['event_id'],[]);states=[quote_state(q,e,asof) for q in qs]
            decision=decide(e,pricing,qs,asof,mode);decision['prediction_id']=pid
            # Capture the current gate result before duplicate protection turns a
            # second would-be entry into WATCH.
            original = prior_decisions.get(e['event_id'], {}).get('selected')
            decision['market_revalidation']=paper_market_revalidation(e,decision,asof,original)
            if decision.get('triggered') and prior_entries[e['event_id']]-{pid}:
                decision.update(triggered=False,shadow_action='WATCH',display_action='观察')
                decision['blockers'].append('EXISTING_PAPER_ENTRY_NO_DUPLICATE')
                decision['prior_entry_ids']=sorted(prior_entries[e['event_id']]-{pid})
            elif decision.get('triggered'):prior_entries[e['event_id']].add(pid)
            if decision.get('triggered'):
                phase, minutes = _phase(asof, e['tip_at'], lifecycle_config())
                decision['execution_lifecycle']={'entry_phase':phase,'minutes_before_tip_at_entry':minutes,
                    'threshold_source':lifecycle_config().get('early_entry',{}).get('threshold_source','INITIAL_PRIOR'),
                    'late_recheck_required_at_minutes':lifecycle_config().get('late_recheck_minutes_before_tip',[30,10,5]),
                    'real_execution_allowed':False}
            decision['signal_layer']={'first_write':True,'pre_tip':True,
                'market_type':(decision.get('selected') or {}).get('market_type'),
                'selection':(decision.get('selected') or {}).get('selection'),
                'classification':'VALID_PRETIP_DIRECTION' if decision.get('comparison_ready') else 'NO_VALID_DIRECTION',
                'markets':{k:{'market_type':k,'selection':(v.get('selected') or {}).get('selection'),
                    'triggered':bool(v.get('triggered')),'comparison_ready':bool(v.get('comparison_ready')),
                    'model_state':v.get('model_state'),'blockers':v.get('blockers',[])}
                    for k,v in (decision.get('market_decisions') or {}).items()}}
            decision['forecast_fingerprint']=fingerprint(pricing);decision['price_blind_input_fingerprint']=fingerprint(inp)
            decision['feature_isolation_verified']=True
            exclusive(ledger/('decision_'+pid+'.json'),decision)
            current_decisions[e['event_id']]=decision
            rows.append(project_row(e,pricing,qs,decision,states,mode))
            audit.append({'event_id':e['event_id'],'league':e['league'],'team1':e['team1_name'],'team2':e['team2_name'],'tip_bj':e['tip_time_bj'],
              'historical_candidates':len(cap['history']),'history_used':pricing.get('input_games',0),'history_team_counts':pricing.get('team_game_counts',{}),
              'history_opponent_counts':pricing.get('team_opponent_counts',{}),'history_exclusions':pricing.get('history_exclusions',{}),
              'competition_match_methods':pricing.get('competition_match_methods',{}),'paper_model_eligible':pricing.get('paper_model_eligible',False),
              'pricing_status':pricing['pricing_status'],'raw_margin':pricing.get('mu_raw'),'raw_total':pricing.get('total_raw'),
              'raw_quote_rows':len(qs),'raw_verified':sum(x['raw_observation'] for x in states),'fresh_quotes':sum(x['fresh_observation'] for x in states),
              'action':decision['shadow_action'],'blockers':decision.get('blockers'),
              'model_warnings':pricing.get('model_warnings',[]),'feature_fingerprint':pricing.get('input_fingerprint'),'pricing_called':True})
        except Exception as exc:
            p={'pricing_status':'UNPRICEABLE','mu_raw':None,'total_raw':None,'pricing_data_quality':0,'blockers':['PIPELINE_EXCEPTION'], 'error':str(exc)}
            d={'shadow_action':'BLOCKED','display_action':'不可投','blockers':['PIPELINE_EXCEPTION: '+str(exc)],'real_stake':0,'real_execution_allowed':False}
            rows.append(project_row(e,p,groups.get(e['event_id'],[]),d,[],mode));audit.append({'event_id':e['event_id'],'pricing_called':True,'blockers':d['blockers']})
    # Later observations are append-only revisions. They never replace the
    # original selection, line, price, probability, or settlement evidence.
    if mode == 'FORWARD_NATIVE':
        current_events={e['event_id']:e for e in cap['events']}
        for event_id, original in prior_decisions.items():
            event=current_events.get(event_id) or prior_events.get(event_id)
            if not event or not original.get('triggered'):
                continue
            if event_id in current_events:
                current=current_decisions.get(event_id)
            elif event.get('tip_at') and iso(event['tip_at']) <= iso(asof):
                current={'market_revalidation': paper_market_revalidation(event, {}, asof, original.get('selected'))}
            else:
                current=None
            append_lifecycle_revision(root,event,original,current,asof,run_id)
    current=[r for r in rows if r['event']['bj_date']==day]
    native=mode=='FORWARD_NATIVE';message=('实时运行；低置信度研究定价不等于可投。' if native else '包内离线核查；非当时实际发布的前向预测，不计入实盘或纸面业绩。')
    settled=settle_existing(root,cap['history'],asof) if native else 0
    failure_audit=failure_audit_settlements(root,cap['history'],asof) if native else None
    settlement_tracking=sync_paper_settlements(root,asof) if native else None
    analytics=build_analytics(root,asof) if native else None
    coverage=build_coverage(current,cap.get('source_health',[]))
    history_readiness_diagnostic=build_history_readiness_diagnostic(current,cap,root,asof,mode)
    pricing_funnel_diagnostic=build_pricing_funnel_diagnostic(current,root,day,asof,cap.get('source_health',[]),history_readiness_diagnostic)
    total_market_pipeline_diagnostic=build_total_market_pipeline_diagnostic(current,root,day,asof)
    p0_bias_audit=build_p0_bias_audit(root,asof,day,current)
    document=write_dashboard(root,rows,day,asof,mode,message,analytics=analytics,live_funnel=funnel(current),coverage=coverage,pricing_funnel_diagnostic=pricing_funnel_diagnostic,history_readiness_diagnostic=history_readiness_diagnostic,total_market_pipeline_diagnostic=total_market_pipeline_diagnostic,p0_bias_audit=p0_bias_audit)
    # First-write preservation can add an immutable paper row to the written
    # current-day view. Recompute read-only diagnostics on exactly that final
    # row set so the manifest, JSON, and page cannot drift apart.
    written_rows=document.get('events',[])
    history_readiness_diagnostic=build_history_readiness_diagnostic(written_rows,cap,root,asof,mode)
    pricing_funnel_diagnostic=build_pricing_funnel_diagnostic(written_rows,root,day,asof,cap.get('source_health',[]),history_readiness_diagnostic)
    total_market_pipeline_diagnostic=build_total_market_pipeline_diagnostic(written_rows,root,day,asof)
    scope=pricing_funnel_diagnostic.get('scope_invariant') or {}
    if (pricing_funnel_diagnostic.get('date_bj')!=day or
        pricing_funnel_diagnostic.get('events')!=len(written_rows) or
        not scope.get('date_scope_match') or not scope.get('event_count_match')):
        raise AssertionError('DASHBOARD_PRICING_FUNNEL_SCOPE_ERROR')
    document['history_readiness_diagnostic']=history_readiness_diagnostic
    document['pricing_funnel_diagnostic']=pricing_funnel_diagnostic
    document['total_market_pipeline_diagnostic']=total_market_pipeline_diagnostic
    document['p0_bias_audit']=p0_bias_audit
    atomic(root/'dashboard_v2'/'data'/(day+'.json'),document)
    atomic(root/'dashboard_v2'/'data'/'latest.json',document)
    revalidation_tracking=paper_market_revalidation_tracking(root,document,asof) if native else None
    prior_review=review_previous_day(root,day,asof) if native else None
    summary={'version':VERSION,'run_id':run_id,'archive_type':mode,'asof':asof,'day':day,'all_source_identities':len(rows),
      'source_history_facts':len(cap['history']),'source_quote_rows':len(cap['quotes']),'source_errors':cap.get('errors',[]),
      'titan007_audit':cap.get('titan007_audit'),
      'team_histories_attempted':cap.get('histories_attempted',0),'team_histories_parsed':cap.get('histories_parsed',0),
      'team_history_games_parsed':cap.get('team_history_games_parsed',0),'history_page_audit':cap.get('history_page_audit',[]),
      'scope_funnel':funnel(rows),'today_funnel':funnel(written_rows),'cold_start_summary':cold_start_summary(written_rows),'priced_scope_events':[r['id'] for r in rows if r['pricing'].get('mu_raw') is not None],
      'pricing_call_count':len(calls),'settlements_appended':settled,'previous_day_paper_review':prior_review,
      'paper_settlement_tracking':settlement_tracking,
      'failure_audit':failure_audit,
      'paper_market_revalidation':revalidation_tracking,'coverage':coverage,'coverage_all_events':build_coverage(rows,cap.get('source_health',[])),
      'spread_execution_total_analytics':analytics,
      'pricing_funnel_diagnostic':pricing_funnel_diagnostic,
      'total_market_pipeline_diagnostic':total_market_pipeline_diagnostic,
      'history_readiness_diagnostic':history_readiness_diagnostic,
      'p0_bias_audit':p0_bias_audit,
      'real_execution_allowed':False,
      'update_status':'PARTIAL' if cap.get('errors') or not any(r['execution'].get('comparison_ready') for r in rows) else 'COMPLETE',
      'source_http_attempts':len(cap.get('source_health',[])),'source_http_successes':sum(bool(x.get('ok')) for x in cap.get('source_health',[])),
      'missing_raw_files':cap.get('missing_raw_files',[]),'limitations':cap.get('limitations',[])}
    atomic(root/'manifests'/'repair_v22_latest.json',summary)
    atomic(root/'manifests'/(run_id+'_calls.json'),calls)
    atomic(root/'audits'/'current_event_pricing_audit.json',audit)
    fields=['event_id','league','team1','team2','tip_bj','historical_candidates','history_used','history_team_counts','history_opponent_counts','history_exclusions','competition_match_methods','paper_model_eligible','pricing_status','raw_margin','raw_total','raw_quote_rows','raw_verified','fresh_quotes','action','blockers','model_warnings','feature_fingerprint','pricing_called']
    csvwrite(root/'audits'/'current_event_pricing_audit.csv',audit,fields)
    atomic(root/'dashboard_v2'/'sources'/'health.json',cap.get('source_health',[]))
    # Counts explicitly distinguish samples from market-quote rows.
    analytics_summary = None
    if analytics:
        analytics_summary = {'spread_signal_layer': analytics.get('spread_signal_layer'),
                             'spread_execution_layer': analytics.get('spread_execution_layer'),
                             'price_exhaustion_layer': {k: analytics.get('price_exhaustion_layer', {}).get(k) for k in ('count', 'note')},
                             'total_diagnostic_layer': {k: analytics.get('total_diagnostic_layer', {}).get(k) for k in ('status', 'settled_total_observations', 'bias_conclusion')},
                             'migration': analytics.get('migration'),
                             'model_validation': analytics.get('model_validation')}
    atomic(root/'dashboard_v2'/'calibration'/'summary.json',{'archive_type':mode,'last_run_funnel':funnel(rows),'probability_calibration':'UNVALIDATED','ROI':None,'hit_rate':None,'spread_execution_total':analytics_summary,'real_execution_allowed':False})
    return {'summary':summary,'rows':rows,'document':document}

def reconstructed_score_backtest(cap,root,day,n):
    """Sequential score-only check. Never invent historical prices/entries or ROI.

    Historical final-score facts fetched later are reconstructed evidence. A
    conservative 24h availability lag is explicitly disclosed, not a claimed
    archive timestamp. This is distinct from strict original-snapshot replay.
    """
    dates=recent_complete_days(day,n);history=cap['history'];targets=[g for g in history if iso(g['tip_at']).astimezone(BJ).date().isoformat() in dates]
    rows=[];excluded=[];dest=Path(root)/'calibration'/'repair_v22_score_reconstruction';dest.mkdir(parents=True,exist_ok=True)
    for g in sorted(targets,key=lambda x:x['tip_at']):
        e={k:g[k] for k in ('event_id','team1_id','team2_id','team1_name','team2_name','competition_id','gender','format_id','tip_at','league')}
        e['competition_key']=g.get('competition_key') or competition_key(g.get('league'),g.get('gender'))
        from .source import family
        e.update(model_family=family(g['league']),identity_verified=True,source_event_id=g['source_event_id'],age_group='UNVERIFIED',home_sign=0,
                 tip_time_bj=iso(g['tip_at']).astimezone(BJ).isoformat(),bj_date=iso(g['tip_at']).astimezone(BJ).date().isoformat())
        cutoff=stamp(iso(g['tip_at'])-timedelta(hours=1));mode='RECONSTRUCTED_SCORE_ONLY'
        # Outcome scores are not in event and target row is absent from history passed to model.
        input_history=[h for h in history if h['event_id']!=g['event_id']]
        p=price_event(e,input_history,cutoff,mode);pid=fingerprint({'event':e,'forecast':p})[:28]
        exclusive(dest/('forecast_'+pid+'.json'),p)
        if p['pricing_status']=='UNPRICEABLE':excluded.append({'event_id':g['event_id'],'day':e['bj_date'],'reason':p.get('blockers')});continue
        # Only now read the held-out target outcome.
        margin=g['score1_full']-g['score2_full'];total=g['score1_full']+g['score2_full']
        rows.append({'event_id':g['event_id'],'day':e['bj_date'],'league':e['league'],'model_family':e['model_family'],
          'team1':e['team1_name'],'team2':e['team2_name'],'cutoff':cutoff,'history_used':p['input_games'],
          'mu_margin':p['mu_raw'],'mu_total':p['total_raw'],'actual_margin':margin,'actual_total':total,
          'abs_margin_error':abs(margin-p['mu_raw']),'abs_total_error':abs(total-p['total_raw']),
          'archive_type':mode,'forecast_id':pid,'quote':None,'paper_pnl':None})
    def mae(key,arr):return sum(r[key] for r in arr)/len(arr) if arr else None
    daily=[{'date':d,'candidate_games':sum(iso(g['tip_at']).astimezone(BJ).date().isoformat()==d for g in targets),
            'priced_games':sum(r['day']==d for r in rows),'margin_MAE':mae('abs_margin_error',[r for r in rows if r['day']==d]),
            'total_MAE':mae('abs_total_error',[r for r in rows if r['day']==d])} for d in dates]
    summary={'requested_dates':dates,'candidate_games':len(targets),'priced_games':len(rows),'excluded_games':len(excluded),
       'archive_type':'RECONSTRUCTED_SCORE_ONLY','margin_MAE':mae('abs_margin_error',rows),'total_MAE':mae('abs_total_error',rows),
       'ROI':None,'hit_rate':None,'CLV':None,'strict_original_snapshot_replay_count':0,
       'assumptions':['Final-score facts reaggregated from later source snapshots; not an exact historical page-state replay.',
                      'A prior game must have started at least 24 hours before cutoff, be marked FINAL in the captured source, and not be the target.',
                      'No archived pregame quote means no entry, no PnL, no ROI. No model tuning on these outcomes.'],
       'daily':daily,'exclusions':excluded}
    atomic(dest/'summary.json',summary);atomic(Path(root)/'audits'/'recent6_backtest_audit.json',summary)
    csvwrite(dest/'replay_games.csv',rows,['event_id','day','league','model_family','team1','team2','cutoff','history_used','mu_margin','mu_total','actual_margin','actual_total','abs_margin_error','abs_total_error','archive_type','forecast_id','quote','paper_pnl'])
    csvwrite(dest/'daily_summary.csv',daily,['date','candidate_games','priced_games','margin_MAE','total_MAE'])
    return summary

def publish(root,repo,push=False):
    root=Path(root);repo=Path(repo).resolve()
    if repo.name=='basketball-data':repo=repo.parent
    if not repo.is_dir():raise ValueError('publish directory does not exist')
    web=root/'dashboard_v2';target=repo/'basketball-data';target.mkdir(exist_ok=True)
    copied=[]
    for p in (web/'data').glob('*.json'):
        shutil.copy2(p,target/p.name);copied.append('basketball-data/'+p.name)
    (repo/'basketball-v2.html').write_text(HTML,encoding='utf-8');copied.append('basketball-v2.html')
    for folder,src in [('basketball-sources',web/'sources'/'health.json'),('basketball-calibration',web/'calibration'/'summary.json')]:
        (repo/folder).mkdir(exist_ok=True);shutil.copy2(src,repo/folder/src.name);copied.append(folder+'/'+src.name)
    result={'files_copied':copied,'old_basketball_html_modified':False,'git_push_requested':push,'public_verified':False}
    if push:
        def git(*args):return subprocess.run(['git','-C',str(repo),*args],capture_output=True,text=True,encoding='utf-8',errors='replace',check=True).stdout.strip()
        allowed=set(copied);staged=git('diff','--cached','--name-only').splitlines()
        if any(p not in allowed for p in staged):raise ValueError('other staged files exist; refusing mixed commit')
        git('add','--',*copied)
        if git('diff','--cached','--name-only'):git('commit','-m','fix basketball actual pricing pipeline and per-event data')
        result['commit']=git('rev-parse','HEAD');git('push');result['git_pushed']=True
        result['public_note']='Push success is not Pages-render validation; check the actual Pages deployment.'
    return result

def execute(root,day,live=False,bundle=None,session_id=None,backtest_n=0,publish_dir=None,push=False,timeout=12,workers=4):
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    if bundle:
        cap=replay_bundle(bundle,session_id)
        if not day or day=='auto':day=cap['requested_day']
    else:
        if not live:raise ValueError('Use --live for a new capture or --replay-bundle for explicitly separated offline audit')
        day=now().astimezone(BJ).date().isoformat() if not day or day=='auto' else day
        if day<now().astimezone(BJ).date().isoformat():raise ValueError('Past dates cannot become forward-native. Use --backtest-recent.')
        config=load(Path(__file__).resolve().parents[2]/'config'/'repair_market_contracts.json',DEFAULT_CONTRACTS)
        cap=collect_live(root,day,config,timeout,workers)
    if not cap['events']:
        failure={'version':VERSION,'run_id':cap['run_id'],'update_status':'FAILED','reason':'NO_CANONICAL_EVENTS_FROM_THIS_CAPTURE',
                 'source_health':cap.get('source_health',[]),'parse_errors':cap.get('errors',[]),'real_execution_allowed':False}
        atomic(root/'manifests'/'repair_v22_latest.json',failure)
        # Preserve last known data as stale, not as a fresh empty success.
        p=root/'dashboard_v2'/'data'/'latest.json';old=load(p)
        if old:
            old['update_status']='FAILED';old['last_failed_attempt_at']=stamp();old['message']='本轮采集失败；以下为历史最后记录，不是当前盘口。'
            old['current_quotes_usable']=False;atomic(p,old)
        atomic(root/'dashboard_v2'/'sources'/'health.json',cap.get('source_health',[]))
        if publish_dir and old:
            failure['publish']=publish(root,publish_dir,push)
        return failure
    result=run_capture(cap,root,day)
    if backtest_n:result['summary']['backtest']=reconstructed_score_backtest(cap,root,day,backtest_n)
    if bundle:
        preview=dict(result['document']);preview['events']=result['rows'];preview['funnel']=funnel(result['rows'])
        standalone_preview(root/'核查预览.html',preview)
    if publish_dir:
        if bundle:raise ValueError('Offline audit must not be published as current live data')
        try:
            result['summary']['publish']=publish(root,publish_dir,push)
        except Exception as exc:
            # Publication transport is external to a completed immutable data
            # run. Keep the run auditable and report the exact publish failure.
            result['summary']['publish']={'status':'PUBLISH_FAILED_AFTER_LOCAL_COMPLETION',
                                          'error_type':type(exc).__name__,'error':str(exc),
                                          'git_push_requested':push,'real_execution_allowed':False}
            result['summary']['update_status']='PARTIAL'
    atomic(root/'audits'/'repair_v22_run_report.json',result['summary'])
    return result['summary']
