import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]/'scripts'))
from pricing.national_team_model import structural_margin
class NationalModelTests(unittest.TestCase):
 def test_prior_not_rank_difference(self): self.assertEqual(structural_margin({'prior':5,'roster_value':2},{'prior':1,'roster_value':0}),6)
if __name__=='__main__':unittest.main()
