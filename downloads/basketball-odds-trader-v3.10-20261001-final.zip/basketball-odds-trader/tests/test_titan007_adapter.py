import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from providers.titan007_adapter import parse_odds_xml, parse_schedule_xml


class Titan007AdapterTest(unittest.TestCase):
    def test_schedule_filters_target_day_and_preserves_event(self):
        text = '<c><m><h><![CDATA[722225^NBL(A),NBL(A)^4^#DFCF20^09月30日<br>15:30^0^^937^新西兰破坏者[8],紐西蘭破壞者[8],New Zealand Breakers[8]^816^坎斯大班[7],開恩茲泰斑蛇[7],Cairns Taipans[7]^^^^^^^^^^^0^^^^^^^^^^^1^14^0^1.5,2.47^14^2026^^0^1^^0^0^1^0]]></h></m>' \
               '<m><h><![CDATA[999999^NBA^4^#000^10月01日<br>08:00^0^^1^A^2^B]]></h></m></c>'
        events, errors = parse_schedule_xml(text, '2026-09-30')
        self.assertEqual(errors, [])
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]['event_id'], '7m:722225')
        self.assertEqual(events[0]['team1_name'], '新西兰破坏者[8]')
        self.assertEqual(events[0]['bj_date'], '2026-09-30')

    def test_odds_parses_spread_and_total_without_fake_timestamp(self):
        text = "<c><match><m>722225,4.5,0.80,1.06,185.5,1.00,0.84,False</m></match></c>"
        quotes, errors = parse_odds_xml(text, '3', source_path=None, received_at='2026-09-30T07:00:00+00:00')
        self.assertEqual(errors, [])
        self.assertEqual({q['market_type'] for q in quotes}, {'SPREAD', 'TOTAL'})
        spread = next(q for q in quotes if q['market_type'] == 'SPREAD')
        self.assertEqual(spread['line_team1'], 4.5)
        self.assertEqual(spread['decimal_prices'], [1.8, 2.06])
        self.assertIsNone(spread['source_quote_at'])
        self.assertFalse(spread['execution_verified'])


if __name__ == '__main__':
    unittest.main()
