import unittest
from repair_v22 import VERSION
from global_discovery import canonical_id, classify, merge_with_primary, norm_team

class GlobalDiscoveryTests(unittest.TestCase):
    def test_registry_classifies_core_regions(self):
        self.assertEqual(classify('WCBA')[0], 'CHINA_WCBA')
        self.assertEqual(classify('FIBA Womens Qualifiers')[0], 'FIBA_QUALIFIER')
        self.assertEqual(classify('EuroCup')[0], 'EUROCUP')
        self.assertEqual(classify('KBL')[0], 'KOREA_KBL')
        self.assertEqual(classify('美国女子职业篮球联赛')[0], 'WNBA')
        self.assertEqual(classify('澳大利亚国家篮球联赛')[0], 'AUSTRALIA_NBL')
        self.assertEqual(classify('EURO')[0], 'EUROLEAGUE')
        self.assertEqual(classify('亚洲运动会女子篮球赛')[0], 'FIBA_CONTINENTAL')

    def test_alias_and_canonical_identity(self):
        self.assertEqual(norm_team('广东东阳光'), norm_team('Guangdong Southern Tigers'))
        self.assertEqual(canonical_id('NCAAB','A','B','2026-09-23T12:00:00+00:00'), canonical_id('NCAAB','A','B','2026-09-23T12:00:12+00:00'))

    def test_global_schedule_without_market_is_kept(self):
        primary=[{'event_id':'7m:1','tip_at':'2026-09-23T12:00:00+00:00','team1_name':'A','team2_name':'B','source':'7M'}]
        discovered=[{'event_id':'global:NCAAB:x','tip_at':'2026-09-23T13:00:00+00:00','team1_name':'C','team2_name':'D','team1_key':'c','team2_key':'d','discovery_sources':[{'source':'espn'}]}]
        out=merge_with_primary(primary,discovered,[])
        self.assertEqual(len(out),2)
        self.assertEqual(out[1]['discovery_status'],'DISCOVERED_ONLY')

    def test_global_schedule_reconciles_to_7m(self):
        primary=[{'event_id':'7m:1','tip_at':'2026-09-23T12:00:00+00:00','team1_name':'A','team2_name':'B','source':'7M'}]
        discovered=[{'event_id':'global:NCAAB:x','tip_at':'2026-09-23T12:05:00+00:00','team1_key':'a','team2_key':'b','team1_name':'A','team2_name':'B','discovery_sources':[{'source':'espn'}]}]
        out=merge_with_primary(primary,discovered,[])
        self.assertEqual(len(out),1)
        self.assertIn('global_source_ids',out[0])

if __name__=='__main__': unittest.main()
