import unittest

from repair_v22.league_funnel_diagnostic import (
    _window_stats,
    league_bucket,
    probability_waterfall,
)


class LeagueFunnelDiagnosticTests(unittest.TestCase):
    def test_wnba_and_non_wnba_buckets(self):
        self.assertEqual(league_bucket({'league': 'WNBA', 'league_family': 'WNBA'}), 'WNBA')
        self.assertNotEqual(league_bucket({'league': '德国篮球甲级联赛', 'league_family': 'EUROPE_DOMESTIC'}), 'WNBA')

    def test_probability_waterfall_does_not_infer_missing_stages(self):
        result = probability_waterfall({'raw_probability': 0.61, 'residual_scale_multiplier': 1.4}, {'p_win': 0.57})
        self.assertEqual(result['values']['raw_probability'], 0.61)
        self.assertIsNone(result['values']['after_mean_calibration'])
        self.assertEqual(result['values']['final_probability'], 0.57)
        self.assertEqual(result['status'], 'PARTIAL_FIELDS')

    def test_window_stats_has_main_state_and_insufficient_sample(self):
        record = {
            'market_found': True,
            'fresh_market_found': True,
            'priceable': True,
            'comparable': True,
            'status': 'PRICEABLE_NO_EDGE',
            'edge_metrics': {
                'raw_edge_found': True,
                'calibrated_edge_found': False,
                'evidence_pass': True,
                'execution_pass': False,
            },
        }
        result = _window_stats([record])
        self.assertEqual(result['counts']['raw_edge_found'], 1)
        self.assertEqual(result['main_state'], 'CALIBRATION_SUPPRESSED')
        self.assertEqual(result['sample_sufficiency'], 'INSUFFICIENT_SAMPLE')


if __name__ == '__main__':
    unittest.main()
