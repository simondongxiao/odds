import tempfile
import unittest
from pathlib import Path

from global_discovery import classify
from providers.titan007_adapter import parse_odds_xml
from repair_v22.evidence_context import evaluate_tier3_roster_stability
from repair_v22.history_readiness_diagnostic import build_history_readiness_diagnostic
from repair_v22.common import competition_key
from repair_v22.model import POLICY, _bootstrap_match, price_event, total_diagnostic
from repair_v22.pipeline import preserve_daily_event_inventory
from repair_v22.pricing_funnel_diagnostic import _rule_ready, build_pricing_funnel_diagnostic
from repair_v22.source import game_minutes_for, reconcile_titan_events


ASOF = '2026-09-30T07:00:00+00:00'
TIP = '2026-09-30T12:00:00+00:00'


def _event(event_id='7m:primary', league='欧洲篮球冠军联赛', family='EUROLEAGUE'):
    return {
        'event_id': event_id, 'canonical_event_id': event_id, 'source_event_id': event_id.split(':')[-1],
        'source': '7M', 'team1_id': '7m-team:A', 'team2_id': '7m-team:B',
        'team1_source_id': 'A', 'team2_source_id': 'B', 'team1_name': '悉尼国王', 'team2_name': '布里斯班子弹',
        'league': league, 'league_family': family, 'competition_id': '7m-comp:1',
        'competition_key': family, 'gender': 'MEN', 'model_family': 'CLUB_MATURE',
        'identity_verified': True, 'tip_at': TIP, 'tip_time_bj': '2026-09-30T20:00:00+08:00',
        'bj_date': '2026-09-30', 'game_minutes': 40, 'game_minutes_source': 'registry',
    }


def _history_game(index, team, opponent):
    day = 1 + index
    return {
        'event_id': f'7m:h:{team}:{index}', 'team1_id': team, 'team2_id': opponent,
        'team1_name': team, 'team2_name': opponent, 'competition_id': '7m-comp:1',
        'competition_key': 'EUROLEAGUE', 'league': '欧洲篮球冠军联赛', 'gender': 'MEN',
        'status': 'FINAL', 'tip_at': f'2026-09-{day:02d}T00:00:00+00:00',
        'known_final_at': f'2026-09-{day:02d}T03:00:00+00:00',
        'score1_full': 80 + index, 'score2_full': 70 + index,
        'score1_regulation': 80 + index, 'score2_regulation': 70 + index,
        'evidence_kind': 'TEAM_HISTORY', 'source_url': 'https://example.test/history',
    }


class V38P0P2RepairTests(unittest.TestCase):
    def test_titan_event_and_quotes_reconcile_to_7m_canonical_event(self):
        primary = _event()
        titan = dict(primary, event_id='7m:722226', canonical_event_id='7m:722226', source_event_id='722226',
                     source='TITAN007', team1_name='悉尼国王[2]', team2_name='布里斯班子弹[1]')
        events = {primary['event_id']: primary, titan['event_id']: titan}
        quotes = [{'event_id': titan['event_id'], 'source_event_id': '722226', 'feed_provider': 'TITAN007'}]
        audit = reconcile_titan_events(events, [titan], quotes)
        self.assertEqual(audit['matched_count'], 1)
        self.assertEqual(len(events), 1)
        self.assertEqual(quotes[0]['event_id'], primary['event_id'])
        self.assertEqual(quotes[0]['source_event_id_titan'], '722226')

    def test_formal_league_aliases_are_registered(self):
        self.assertEqual(classify('NBL(A)')[0], 'AUSTRALIA_NBL')
        self.assertEqual(classify('VTB联')[0], 'VTB_UNITED')
        self.assertEqual(classify('捷克篮球甲联联赛')[0], 'CZECH_NBL')
        self.assertEqual(classify('波多黎各联女篮')[0], 'PUERTO_RICO_WOMEN')
        self.assertEqual(classify('希女杯')[0], 'GREECE_WOMEN_CUP')
        self.assertEqual(classify('突尼联')[0], 'TUNISIA_LEAGUE')
        self.assertEqual(classify('阿联酋杯')[0], 'UAE_CUP')
        self.assertEqual(classify('加女篮ABL')[0], 'CANADA_WOMEN_ABL')
        self.assertEqual(classify('爱沙尼亚与拉脱维亚篮球联合联赛')[0], 'ESTONIA_LATVIA_LEAGUE')
        self.assertEqual(classify('乌干女联')[0], 'UGANDA_WOMEN_LEAGUE')
        self.assertEqual(classify('肯女篮联')[0], 'KENYA_WOMEN_LEAGUE')
        self.assertEqual(classify('韩国大学篮球联赛')[0], 'KOREA_UNIVERSITY')

    def test_european_history_labels_reconcile_without_lowering_thresholds(self):
        self.assertEqual(competition_key('欧洲篮球联盟杯', 'MEN'), 'EUROCUP')
        self.assertEqual(competition_key('欧洲北部篮球联赛', 'MEN'), 'ENBL')
        self.assertEqual(competition_key('欧北联', 'MEN'), 'ENBL')
        self.assertEqual(competition_key('欧洲篮球男子俱乐部杯预选赛', 'MEN'), 'FIBA_EUROPE_CUP')
        self.assertEqual(competition_key('欧洲女子篮球联赛', 'WOMEN'), 'EUROLEAGUE_WOMEN')
        event = _event(league='欧洲篮球联盟杯', family='EUROCUP')
        event['competition_key'] = competition_key(event['league'], event['gender'])
        game = _history_game(0, '7m-team:A', '7m-team:X')
        game['league'] = '立陶联'
        game['competition_id'] = '7m-comp:domestic'
        game['competition_key'] = competition_key(game['league'], game['gender'])
        self.assertEqual(_bootstrap_match(event, game), 'CROSS_COMPETITION_ADJUSTED')
        history = []
        for i in range(8):
            for team, opponent in (('7m-team:A', f'7m-team:X{i}'), ('7m-team:B', f'7m-team:Y{i}')):
                row = _history_game(i, team, opponent)
                row['league'] = '立陶联'
                row['competition_id'] = '7m-comp:domestic'
                row['competition_key'] = competition_key(row['league'], row['gender'])
                history.append(row)
        capture = {'history': history, 'history_page_audit': [
            {'team_source_id': 'A', 'http_success': True, 'parsed_games': 8, 'url': 'a'},
            {'team_source_id': 'B', 'http_success': True, 'parsed_games': 8, 'url': 'b'},
        ]}
        with tempfile.TemporaryDirectory() as tmp:
            diagnostic = build_history_readiness_diagnostic(
                [{'id': event['event_id'], 'event': event}], capture, tmp, ASOF)
        team = diagnostic['events'][0]['team1']
        self.assertEqual(team['games_after_league_filter'], 0)
        self.assertEqual(team['games_after_competition_resolution'], 8)
        self.assertEqual(team['cross_competition_bootstrap_games'], 8)
        self.assertTrue(team['research_history_ready'])
        self.assertTrue(team['paper_history_ready'])

    def test_registered_leagues_have_evidence_backed_regulation_minutes(self):
        for league in ('西亚篮球超级联赛', 'VTB联', '芬兰篮球甲级联赛', '捷克篮球甲联联赛',
                       '匈牙利篮球甲级联赛', '罗马尼亚篮球杯赛', '爱沙尼亚与拉脱维亚篮球联合联赛',
                       '韩国大学篮球联赛'):
            minutes, source = game_minutes_for(league)
            self.assertEqual(minutes, 40, league)
            self.assertNotEqual(source, 'UNKNOWN_NO_MINUTES_ASSUMED', league)
        self.assertTrue(_rule_ready({'league': '韩国大学篮球联赛', 'game_minutes': None,
                                     'game_minutes_source': 'UNKNOWN_NO_MINUTES_ASSUMED'}))

    def test_titan_total_direction_is_explicit_but_ot_and_time_remain_unknown(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'goal.raw'; path.write_text('<r><m>1,1.5,0.9,0.9,160.5,0.91,0.95</m></r>', encoding='utf-8')
            quotes, _ = parse_odds_xml(path.read_text(), '1', path, ASOF)
        total = next(x for x in quotes if x['market_type'] == 'TOTAL')
        self.assertTrue(total['direction_verified'])
        self.assertEqual(total['ot_rule'], 'UNKNOWN')
        self.assertIsNone(total['source_quote_at'])

    def test_titan_odds_parser_does_not_treat_match_container_as_market_row(self):
        text = '<match><m>742140,1.5,0.90,0.90,160.5,0.91,0.95</m></match>'
        quotes, errors = parse_odds_xml(text, '1', source_path=None, received_at=ASOF)
        self.assertFalse(errors)
        self.assertTrue(quotes)
        self.assertEqual({q['source_event_id'] for q in quotes}, {'742140'})
        self.assertFalse(any('<' in q['source_event_id'] for q in quotes))

    def test_history_waterfall_separates_research_and_paper_thresholds(self):
        event = _event()
        history = []
        for i in range(7):
            history.append(_history_game(i, '7m-team:A', f'7m-team:X{i % 3}'))
            history.append(_history_game(i + 10, '7m-team:B', f'7m-team:Y{i % 3}'))
        capture = {'history': history, 'history_page_audit': [
            {'team_source_id': 'A', 'http_success': True, 'parsed_games': 7, 'url': 'a'},
            {'team_source_id': 'B', 'http_success': True, 'parsed_games': 7, 'url': 'b'},
        ]}
        with tempfile.TemporaryDirectory() as tmp:
            result = build_history_readiness_diagnostic([{'id': event['event_id'], 'event': event}], capture, tmp, ASOF)
        team = result['events'][0]['team1']
        self.assertTrue(team['research_history_ready'])
        self.assertFalse(team['paper_history_ready'])
        self.assertEqual(team['minimum_required_games'], 8)
        self.assertEqual(team['primary_history_failure'], 'TOO_FEW_PRE_CUTOFF_GAMES')

    def test_price_event_emits_granular_history_blocker(self):
        event = _event()
        history = []
        for i in range(7):
            history.append(_history_game(i, '7m-team:A', f'7m-team:X{i % 3}'))
            history.append(_history_game(i + 10, '7m-team:B', f'7m-team:Y{i % 3}'))
        priced = price_event(event, history, ASOF, 'FORWARD_NATIVE', {'roster_verified': True})
        self.assertEqual(priced['pricing_status'], 'PRICED_LOW_CONFIDENCE')
        self.assertFalse(priced['paper_model_eligible'])
        self.assertIn('INSUFFICIENT_HISTORY', priced['paper_evidence_blockers'])
        self.assertNotIn('MODEL_EVIDENCE_NOT_PAPER_ELIGIBLE', priced['paper_evidence_blockers'])

    def test_tier3_roster_stability_accepts_cutoff_safe_box_score_minutes(self):
        event = _event()
        rows = []
        for team in ('7m-team:A', '7m-team:B'):
            for day in (20, 22, 24):
                rows.append({'team_id': team, 'game_at': f'2026-09-{day}T00:00:00+00:00',
                             'published_at': f'2026-09-{day}T03:00:00+00:00', 'source_url': 'https://example.test/box',
                             'players': [{'player_id': f'{team}-p{i}', 'minutes': 20} for i in range(6)]})
        result = evaluate_tier3_roster_stability(event, {'box_score_minutes': rows}, ASOF)
        self.assertTrue(result['verified'])

    def test_total_soft_missing_widens_uncertainty_without_hard_block(self):
        event = _event()
        context = {'possessions_level': 'LEVEL_C', 'basic_offense_verified': True, 'injury_verified': False,
                   'roster_verified': False, 'three_point_verified': False, 'late_foul_verified': False}
        result = total_diagnostic(event, [], context, POLICY['CLUB_MATURE'], predictive_spread=8.0, scale_multiplier=1.15)
        self.assertEqual(result['hard_blockers'], [])
        self.assertTrue(result['execution_eligible'])
        self.assertGreater(result['soft_missing_uncertainty_multiplier'], 1.0)

    def test_pricing_funnel_rejects_cross_date_embedding(self):
        event = _event(); event['bj_date'] = '2026-09-29'
        row = {'id': event['event_id'], 'event': event, 'pricing': {}, 'market': {'quotes': [], 'quote_states': []},
               'execution': {'market_decisions': {}}}
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaisesRegex(AssertionError, 'DATE_SCOPE_ERROR'):
                build_pricing_funnel_diagnostic([row], tmp, '2026-09-30', ASOF)

    def test_intraday_inventory_keeps_games_removed_from_current_board(self):
        first = _event('7m:first'); second = _event('7m:second')
        first['bj_date'] = second['bj_date'] = '2026-09-30'
        with tempfile.TemporaryDirectory() as tmp:
            cap1 = {'run_id': 'run1', 'capture_finished_at': ASOF, 'events': [first, second], 'quotes': []}
            preserve_daily_event_inventory(cap1, tmp, '2026-09-30')
            cap2 = {'run_id': 'run2', 'capture_finished_at': ASOF, 'events': [second], 'quotes': []}
            preserve_daily_event_inventory(cap2, tmp, '2026-09-30')
        self.assertEqual({e['event_id'] for e in cap2['events']}, {'7m:first', '7m:second'})
        restored = next(e for e in cap2['events'] if e['event_id'] == '7m:first')
        self.assertTrue(restored['inventory_preserved_from_prior_snapshot'])
        self.assertEqual(cap2['daily_event_inventory_audit']['quotes_fabricated'], 0)


if __name__ == '__main__':
    unittest.main()
