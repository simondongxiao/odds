import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]/'scripts'))
from providers.sevenm_adapter import parse
class SevenMEndpointTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.fixture=Path(__file__).resolve().parents[3]/'outputs/basketball_odds_trader/raw/source_scout/sevenm_basket/comlive_4.js'
  if not cls.fixture.exists(): raise unittest.SkipTest('Original raw comlive fixture is not in this diagnostic export; not a parser pass')
 def test_real_captured_fixture_parses(self):
  p=self.fixture;self.assertGreater(len(parse(p.read_text(encoding='utf8'))['markets']),0)
 def test_unknown_ot_not_executable(self):
  p=self.fixture;self.assertFalse(parse(p.read_text(encoding='utf8'))['markets'][0]['executable_verified'])
