import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from repair_v22.pipeline import paper_market_revalidation
from repair_v22.report import HTML


class PaperMarketRevalidationTests(unittest.TestCase):
    def event(self, tip='2026-09-17T12:00:00+00:00'):
        return {'event_id': '7m:100', 'tip_at': tip}

    def test_current_trigger_still_qualifies(self):
        decision = {'triggered': True, 'comparison_ready': True,
                    'selected': {'line': -3.5}, 'blockers': []}
        review = paper_market_revalidation(self.event(), decision, '2026-09-17T10:00:00+00:00')
        self.assertEqual(review['status'], 'STILL_QUALIFIES')
        self.assertEqual(review['current_selected']['line'], -3.5)

    def test_current_comparison_that_fails_is_not_still_qualifies(self):
        review = paper_market_revalidation(self.event(), {'triggered': False, 'comparison_ready': True,
            'selected': {'line': 2.5}, 'blockers': []}, '2026-09-17T10:00:00+00:00')
        self.assertEqual(review['status'], 'NO_LONGER_QUALIFIES')

    def test_revalidation_does_not_replace_original_direction_with_new_idea(self):
        original = {'bookmaker': 'A', 'market_type': 'SPREAD', 'selection': 'TEAM1', 'ot_rule': 'INCLUDING_OT'}
        decision = {'triggered': True, 'comparison_ready': True, 'blockers': [],
                    'selected': {'bookmaker': 'B', 'market_type': 'TOTAL', 'selection': 'OVER', 'ot_rule': 'INCLUDING_OT'},
                    'comparison_rows': [
                        {'bookmaker': 'A', 'market_type': 'SPREAD', 'selection': 'TEAM1',
                         'ot_rule': 'INCLUDING_OT', 'adverse_ev': .01, 'research_edge_pass': False},
                        {'bookmaker': 'B', 'market_type': 'TOTAL', 'selection': 'OVER',
                         'ot_rule': 'INCLUDING_OT', 'adverse_ev': .2, 'research_edge_pass': True}]}
        review = paper_market_revalidation(self.event(), decision, '2026-09-17T10:00:00+00:00', original)
        self.assertEqual(review['status'], 'NO_LONGER_QUALIFIES')
        self.assertEqual(review['current_selected']['bookmaker'], 'A')

    def test_missing_fresh_comparison_is_unavailable(self):
        review = paper_market_revalidation(self.event(), {'triggered': False, 'comparison_ready': False,
            'blockers': ['STALE_QUOTE']}, '2026-09-17T10:00:00+00:00')
        self.assertEqual(review['status'], 'REVALIDATION_UNAVAILABLE')
        self.assertIn('STALE_QUOTE', review['blockers'])

    def test_material_adverse_total_move_is_rechecked_not_automatically_blocked(self):
        original = {'bookmaker': 'A', 'market_type': 'TOTAL', 'selection': 'OVER', 'ot_rule': 'INCLUDING_OT',
                    'line': 150.5, 'decimal_odds': 1.91}
        decision = {'comparison_ready': True, 'blockers': [], 'comparison_rows': [
            {'bookmaker': 'A', 'market_type': 'TOTAL', 'selection': 'OVER', 'ot_rule': 'INCLUDING_OT',
             'line': 154.0, 'decimal_odds': 1.91, 'adverse_ev': .1, 'research_edge_pass': True}]}
        review = paper_market_revalidation(self.event(), decision, '2026-09-17T10:00:00+00:00', original)
        self.assertEqual(review['status'], 'STILL_QUALIFIES')
        self.assertTrue(review['market_difference']['material'])
        self.assertEqual(review['market_difference']['line_direction'], 'ADVERSE')
        self.assertNotIn('MARKET_MOVE_EXCEEDS_REVALIDATION_LIMIT', review['blockers'])

    def test_underdog_more_points_is_favorable_and_still_qualifies(self):
        original = {'bookmaker': 'A', 'market_type': 'SPREAD', 'selection': 'TEAM1', 'ot_rule': 'INCLUDING_OT',
                    'line': 6.5, 'decimal_odds': 1.94}
        decision = {'comparison_ready': True, 'blockers': [], 'comparison_rows': [
            {'bookmaker': 'A', 'market_type': 'SPREAD', 'selection': 'TEAM1', 'ot_rule': 'INCLUDING_OT',
             'line': 10.5, 'decimal_odds': 1.90, 'adverse_ev': .1, 'research_edge_pass': True}]}
        review = paper_market_revalidation(self.event(), decision, '2026-09-17T10:00:00+00:00', original)
        self.assertEqual(review['status'], 'STILL_QUALIFIES')
        self.assertTrue(review['market_difference']['material'])
        self.assertEqual(review['market_difference']['line_direction'], 'FAVORABLE')
        self.assertIn('更有利', review['display'])

    def test_favorite_deeper_line_fails_only_after_current_gate_fails(self):
        original = {'bookmaker': 'A', 'market_type': 'SPREAD', 'selection': 'TEAM1', 'ot_rule': 'INCLUDING_OT',
                    'line': -6.5, 'decimal_odds': 1.94}
        decision = {'comparison_ready': True, 'blockers': [], 'comparison_rows': [
            {'bookmaker': 'A', 'market_type': 'SPREAD', 'selection': 'TEAM1', 'ot_rule': 'INCLUDING_OT',
             'line': -10.5, 'decimal_odds': 1.90, 'adverse_ev': -.01, 'research_edge_pass': False}]}
        review = paper_market_revalidation(self.event(), decision, '2026-09-17T10:00:00+00:00', original)
        self.assertEqual(review['status'], 'NO_LONGER_QUALIFIES')
        self.assertEqual(review['market_difference']['line_direction'], 'ADVERSE')
        self.assertIn('经重新审核后本轮不投注', review['display'])

    def test_started_event_does_not_claim_current_entry(self):
        review = paper_market_revalidation(self.event('2026-09-17T09:00:00+00:00'),
            {'triggered': True, 'comparison_ready': True, 'blockers': []}, '2026-09-17T10:00:00+00:00')
        self.assertEqual(review['status'], 'EVENT_STARTED')

    def test_dashboard_has_current_revalidation_display(self):
        self.assertIn('本轮实际盘口与纸面复核', HTML)
        self.assertIn('STILL_QUALIFIES', HTML)
        self.assertIn('NO_LONGER_QUALIFIES', HTML)
        self.assertIn('真实盘口差异过大，经重新审核后本轮不投注', HTML)
        self.assertIn('当前盘口对原方向更有利', HTML)
        self.assertIn('material-drift', HTML)


if __name__ == '__main__':
    unittest.main()
