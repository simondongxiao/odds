import unittest
from coverage_funnel import build

class CoverageFunnelTests(unittest.TestCase):
    def test_funnel_separates_discovery_and_market(self):
        rows=[{'id':'e1','event':{'league':'WCBA','team1_name':'A','team2_name':'B'},'market':{'quotes':[]},'pricing':{'pricing_status':'UNPRICEABLE'},'execution':{'triggered':False}}]
        out=build(rows)
        self.assertEqual(out['overall']['discovered'],1)
        self.assertEqual(out['overall']['market_found'],0)
        self.assertEqual(out['uncovered_events'][0]['status'],'NO_MARKET')

if __name__=='__main__': unittest.main()
