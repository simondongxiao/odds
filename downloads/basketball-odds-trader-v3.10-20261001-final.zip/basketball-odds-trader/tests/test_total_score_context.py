import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[1] / 'scripts'))

from repair_v22.score_context import build_score_context


def game(n, day, a, b, qa, qb):
    return {'event_id': f'7m:{n}', 'status': 'FINAL', 'tip_at': f'2026-09-{day:02d}T12:00:00+00:00',
            'team1_id': 'A', 'team2_id': 'B', 'team1_name': 'A队', 'team2_name': 'B队',
            'score1_full': a, 'score2_full': b, 'period_points_team1': qa, 'period_points_team2': qb}


class TotalScoreContextTests(unittest.TestCase):
    def setUp(self):
        self.event = {'team1_id': 'A', 'team2_id': 'B'}
        self.games = [game(i, 19 - i, 80 + i, 75 - i, [20, 20, 20, 20 + i, 0], [18, 19, 19, 19 - i, 0]) for i in range(1, 11)]

    def test_last_5_and_10_are_separate(self):
        c = build_score_context(self.event, self.games, '2026-09-20T00:00:00+00:00')
        self.assertEqual(c['team_context']['A']['windows']['last_5']['games'], 5)
        self.assertEqual(c['team_context']['A']['windows']['last_10']['games'], 10)

    def test_periods_and_close_blowout_are_explicit(self):
        c = build_score_context(self.event, self.games, '2026-09-20T00:00:00+00:00')
        w = c['team_context']['A']['windows']['last_5']
        self.assertEqual(w['period_total_points']['Q4']['observations'], 5)
        self.assertEqual(w['close_before_q4']['games'], 5)
        self.assertEqual(w['blowout_before_q4']['games'], 0)

    def test_schedule_density_and_volatility_are_reported(self):
        c = build_score_context(self.event, self.games, '2026-09-20T00:00:00+00:00')
        w = c['team_context']['A']['windows']['last_10']
        self.assertGreater(w['games_in_14_days'], 1)
        self.assertIsNotNone(w['score_volatility']['total_stdev'])

    def test_missing_periods_are_not_inferred(self):
        no_periods = [dict(g, period_points_team1=None, period_points_team2=None) for g in self.games]
        c = build_score_context(self.event, no_periods, '2026-09-20T00:00:00+00:00')
        w = c['team_context']['A']['windows']['last_5']
        self.assertEqual(w['period_total_points']['Q4']['observations'], 0)
        self.assertEqual(c['period_evidence'], 'VERIFIED_WHEN_SOURCE_PERIOD_ARRAY_PRESENT')


if __name__ == '__main__':
    unittest.main()
