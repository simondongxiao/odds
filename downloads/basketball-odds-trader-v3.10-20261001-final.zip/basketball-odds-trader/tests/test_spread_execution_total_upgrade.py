import json
import tempfile
import unittest
from pathlib import Path

from repair_v22.analytics import (_phase, _selection_outcome, append_lifecycle_revision,
                                  build_analytics, lifecycle_revision)
from repair_v22.model import price_event
from repair_v22.pipeline import paper_market_revalidation_tracking


TIP = '2026-09-20T12:00:00+00:00'
ASOF = '2026-09-20T09:00:00+00:00'


def event(event_id='7m:100'):
    return {'event_id': event_id, 'team1_id': 'A', 'team2_id': 'B', 'team1_name': 'A队', 'team2_name': 'B队',
            'competition_id': 'C', 'competition_key': 'C', 'gender': 'MEN', 'model_family': 'CLUB_MATURE',
            'league': 'NBA', 'identity_verified': True, 'tip_at': TIP, 'bj_date': '2026-09-20',
            'game_minutes': 48, 'game_minutes_source': 'LEAGUE_RULE_PRIOR'}


def game(i, home, away, a, b):
    return {'event_id': '7m:h' + str(i), 'team1_id': home, 'team2_id': away, 'competition_id': 'C',
            'competition_key': 'C', 'gender': 'MEN', 'status': 'FINAL', 'tip_at': '2026-09-%02dT00:00:00+00:00' % (i + 1),
            'known_final_at': '2026-09-%02dT03:00:00+00:00' % (i + 1), 'score1_full': a, 'score2_full': b,
            'score1_regulation': a, 'score2_regulation': b, 'evidence_kind': 'TEAM_HISTORY'}


def history():
    return [game(1, 'A', 'C', 80, 70), game(2, 'B', 'D', 76, 75), game(3, 'A', 'D', 83, 72),
            game(4, 'B', 'C', 79, 74), game(5, 'A', 'E', 82, 77), game(6, 'B', 'E', 75, 78),
            game(7, 'C', 'D', 71, 68), game(8, 'D', 'E', 73, 70)]


def final_fact():
    return {'event_id': '7m:100', 'team1_id': 'A', 'team2_id': 'B', 'status': 'FINAL',
            'score1_full': 80, 'score2_full': 70, 'score1_regulation': 80, 'score2_regulation': 70}


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value), encoding='utf-8')


def decision(pid, eid, selected, triggered=False):
    return {'prediction_id': pid, 'event_id': eid, 'archive_type': 'FORWARD_NATIVE', 'asof': ASOF,
            'comparison_ready': True, 'selected': selected, 'triggered': triggered,
            'shadow_action': 'SHADOW_BET' if triggered else 'WATCH', 'model_state': 'EDGE'}


class SpreadExecutionTotalUpgradeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_spread_team1_outcome(self):
        s = {'market_type': 'SPREAD', 'selection': 'TEAM1', 'line': -2.5, 'ot_rule': 'INCLUDING_OT'}
        self.assertEqual(_selection_outcome(event(), s, final_fact())['outcome'], 'WIN')

    def test_spread_team2_outcome(self):
        s = {'market_type': 'SPREAD', 'selection': 'TEAM2', 'line': 2.5, 'ot_rule': 'INCLUDING_OT'}
        self.assertEqual(_selection_outcome(event(), s, final_fact())['outcome'], 'LOSS')

    def test_total_outcome(self):
        s = {'market_type': 'TOTAL', 'selection': 'OVER', 'line': 149.5, 'ot_rule': 'INCLUDING_OT'}
        self.assertEqual(_selection_outcome(event(), s, final_fact())['outcome'], 'WIN')

    def test_early_entry_phase(self):
        phase, minutes = _phase('2026-09-20T08:00:00+00:00', TIP, {'early_entry': {'opens_minutes_before_tip': 240, 'closes_minutes_before_tip': 90}})
        self.assertEqual(phase, 'EARLY_PAPER_ENTRY')
        self.assertEqual(minutes, 240)

    def test_pre_window_signal_phase(self):
        phase, _ = _phase('2026-09-20T06:00:00+00:00', TIP, {'early_entry': {'opens_minutes_before_tip': 240, 'closes_minutes_before_tip': 90}})
        self.assertEqual(phase, 'SIGNAL_BEFORE_EARLY_WINDOW')

    def test_late_entry_phase(self):
        phase, _ = _phase('2026-09-20T10:45:00+00:00', TIP, {'early_entry': {'opens_minutes_before_tip': 240, 'closes_minutes_before_tip': 90}})
        self.assertEqual(phase, 'LATE_PAPER_ENTRY')

    def test_lifecycle_recheck_does_not_replace_original_entry(self):
        original = decision('p1', '7m:100', {'market_type': 'SPREAD', 'selection': 'TEAM1', 'line': -2.5}, True)
        current = {'market_revalidation': {'status': 'NO_LONGER_QUALIFIES'}}
        r = lifecycle_revision(event(), original, current, ASOF, 'run1')
        self.assertEqual(r['original_selection']['line'], -2.5)
        self.assertEqual(r['late_state'], 'LATE_RECHECK_NO_LONGER_QUALIFIES')
        self.assertFalse(r['price_exhausted'])

    def test_lifecycle_revision_is_append_only(self):
        original = decision('p1', '7m:100', {'market_type': 'SPREAD', 'selection': 'TEAM1', 'line': -2.5}, True)
        append_lifecycle_revision(self.root, event(), original, {'market_revalidation': {'status': 'STILL_QUALIFIES'}}, ASOF, 'run1')
        self.assertTrue((self.root / 'revisions' / 'repair_v22' / 'p1' / 'run1.json').exists())
        self.assertEqual(original['selected']['line'], -2.5)

    def test_started_unobserved_paper_entry_is_not_marked_revalidation_unavailable(self):
        original = decision('p1', '7m:100', {'market_type': 'TOTAL', 'selection': 'OVER', 'line': 149.5}, True)
        started = event()
        started['tip_at'] = '2026-09-20T08:00:00+00:00'
        document = {'events': [{'id': '7m:100', 'event': started, 'execution': original,
                                'current_snapshot': {'execution': {}}}]}
        result = paper_market_revalidation_tracking(self.root, document, ASOF)
        self.assertEqual(result['records'][0]['revalidation']['status'], 'EVENT_STARTED')

    def test_unknown_injury_adds_diagnostic_uncertainty_not_lower_total(self):
        p_unknown = price_event(event(), history(), ASOF, 'FORWARD_NATIVE', {'roster_verified': True, 'injury_verified': False})
        p_known = price_event(event(), history(), ASOF, 'FORWARD_NATIVE', {'roster_verified': True, 'injury_verified': True})
        self.assertEqual(p_unknown['total_raw'], p_known['total_raw'])
        self.assertGreater(p_unknown['total_diagnostic']['diagnostic_sigma_total'], p_known['total_diagnostic']['diagnostic_sigma_total'])
        self.assertGreater(p_unknown['scenarios']['INCLUDING_OT']['sd_total'], p_known['scenarios']['INCLUDING_OT']['sd_total'])

    def test_game_minutes_are_explicit_and_not_mixed(self):
        e40, e48 = event('7m:40'), event('7m:48')
        e40['game_minutes'] = 40
        p40 = price_event(e40, history(), ASOF, 'FORWARD_NATIVE', {'roster_verified': True, 'injury_verified': True})
        p48 = price_event(e48, history(), ASOF, 'FORWARD_NATIVE', {'roster_verified': True, 'injury_verified': True})
        self.assertEqual(p40['total_diagnostic']['game_minutes'], 40)
        self.assertEqual(p48['total_diagnostic']['game_minutes'], 48)
        self.assertEqual(p40['total_raw'], p48['total_raw'])

    def test_analytics_separates_signal_from_execution(self):
        ledger = self.root / 'ledger' / 'repair_v22' / 'run'
        spread = {'market_type': 'SPREAD', 'selection': 'TEAM1', 'line': -2.5, 'decimal_odds': 1.91, 'bookmaker': 'A', 'ot_rule': 'INCLUDING_OT', 'ev': .1, 'adverse_ev': .05}
        total = {'market_type': 'TOTAL', 'selection': 'OVER', 'line': 149.5, 'decimal_odds': 1.91, 'bookmaker': 'A', 'ot_rule': 'INCLUDING_OT', 'ev': .1, 'adverse_ev': .05}
        for pid, sel, trigger in [('p1', spread, True), ('p2', total, False)]:
            write_json(ledger / ('decision_' + pid + '.json'), decision(pid, '7m:100', sel, trigger))
            write_json(ledger / ('input_' + pid + '.json'), {'event': event()})
            write_json(ledger / ('forecast_' + pid + '.json'), {'pricing_status': 'PRICED_LOW_CONFIDENCE', 'paper_model_eligible': True, 'mu_raw': 3, 'total_raw': 151})
        write_json(self.root / 'raw' / 'repair_v22' / 'cap' / 'capture.json', {'capture_finished_at': '2026-09-21T00:00:00+00:00', 'history': [final_fact()], 'quotes': []})
        write_json(self.root / 'ledger' / 'repair_v22_settlements' / 'p1.json', {'prediction_id': 'p1', 'event_id': '7m:100', 'outcome': 'WIN', 'score1': 80, 'score2': 70, 'score_rule': 'INCLUDING_OT', 'paper_pnl': .91})
        a = build_analytics(self.root, '2026-09-21T01:00:00+00:00')
        self.assertEqual(a['spread_signal_layer']['signals'], 1)
        self.assertEqual(a['spread_execution_layer']['executed'], 1)
        self.assertEqual(a['total_diagnostic_layer']['settled_total_observations'], 1)

    def test_missing_tape_is_not_price_exhaustion(self):
        ledger = self.root / 'ledger' / 'repair_v22' / 'run'
        sel = {'market_type': 'SPREAD', 'selection': 'TEAM1', 'line': -2.5, 'decimal_odds': 1.91, 'bookmaker': 'A', 'ot_rule': 'INCLUDING_OT'}
        write_json(ledger / 'decision_p1.json', decision('p1', '7m:100', sel, False))
        write_json(ledger / 'input_p1.json', {'event': event()})
        write_json(ledger / 'forecast_p1.json', {'pricing_status': 'PRICED_LOW_CONFIDENCE', 'mu_raw': 3})
        a = build_analytics(self.root, '2026-09-21T01:00:00+00:00')
        self.assertEqual(a['price_exhaustion_layer']['count'], 0)
        self.assertEqual(a['records'][0]['price_exhausted_evidence'], 'NOT_PROVEN_FROM_AVAILABLE_APPEND_ONLY_RECHECKS')

    def test_total_layer_is_explicitly_experimental(self):
        p = price_event(event(), history(), ASOF, 'FORWARD_NATIVE', {'roster_verified': True, 'injury_verified': True})
        self.assertEqual(p['total_model_status'], 'EVIDENCE_GATED_TOTAL_DIAGNOSTIC')
        self.assertFalse(p['total_diagnostic']['used_in_execution'])
        self.assertFalse(p['total_execution_eligible'])

    def test_total_candidate_requires_verified_context(self):
        from repair_v22.model import decide
        p = price_event(event(), history(), ASOF, 'FORWARD_NATIVE', {'roster_verified': True, 'injury_verified': True})
        quote = {'quote_id': 'q1', 'event_id': '7m:100', 'bookmaker_id': 'book', 'bookmaker': 'A',
                 'market_type': 'TOTAL', 'raw_line': 130.5, 'line_team1': None, 'decimal_prices': [1.91, 1.91],
                 'raw_verified': True, 'period': 'FULL_GAME', 'main_or_alt': 'MAIN', 'status': 'OPEN',
                 'current_board_contract_verified': True, 'source_quote_at': ASOF, 'received_at': ASOF,
                 'source_timestamp_semantics': 'LAST_CHANGE', 'price_format_verified': True,
                 'direction_verified': True, 'ot_rule': 'INCLUDING_OT', 'rule_evidence': 'test'}
        d = decide(event(), p, [quote], ASOF, 'FORWARD_NATIVE')
        self.assertFalse(d['triggered'])
        self.assertIn('TOTAL_CONTEXT_INCOMPLETE', d['blockers'])


if __name__ == '__main__':
    unittest.main()
