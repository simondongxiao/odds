import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]/'scripts'))
from market.score_site_discovery import asian_to_decimal,normalize_team,normalize_quote
class ScoreSiteTests(unittest.TestCase):
 def test_alias_event_mapping(self): self.assertEqual(normalize_team('广东南粤[主]'),'广东南粤')
 def test_hk_odds(self): self.assertAlmostEqual(asian_to_decimal(.86,'hong_kong'),1.86)
 def test_unknown_price_blocked(self): self.assertFalse(normalize_quote({'canonical_event_id':'e'},{'overtime_rule':'UNKNOWN'}).get('executable_verified',True))
 def test_comparison_not_book(self): self.assertEqual(normalize_quote({'canonical_event_id':'e'},{})['feed_provider'],'qiutan')
 def test_capture_only(self): self.assertEqual(normalize_quote({'canonical_event_id':'e'},{})['timestamp_type'],'CAPTURE_TIME_ONLY')
if __name__=='__main__': unittest.main()
