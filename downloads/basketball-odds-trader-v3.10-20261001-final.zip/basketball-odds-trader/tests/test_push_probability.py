import unittest
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).parents[1]/'scripts'))
from pricing.distributions import push_probs
class PushProbabilityTests(unittest.TestCase):
 def test_integer_and_half(self):
  self.assertGreater(push_probs(220,218,17)['p_push'],0);self.assertEqual(push_probs(220.5,218,17)['p_push'],0)
