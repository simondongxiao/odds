import json, sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parents[1] / 'scripts'))
from parsers.generic_schedule_article import parse_article
from parsers.cba_article_parser import parse_cba_article
from parsers.fiba_page_parser import parse_fiba_page
from parsers.fiba_page_parser import parse_fiba_rendered_landing
from parsers.fiba_article_parser import parse_fiba_article
from discover_events import canonical_id, normalize

class Step2DParserTests(unittest.TestCase):
    def setUp(self):
        self.text = ('9月6日 11:00 天津 VS 广厦 七八名排位赛；13:30 福建 对阵 辽宁 五六名排位赛；'
                     '17:30 山东83-75山西 季军赛；20:00 决赛')

    def test_schedule_article_extracts_4_games(self): self.assertEqual(len(parse_article(self.text)), 4)
    def test_chinese_vs(self): self.assertEqual(parse_article('9月6日 11:00 天津 VS 广厦')[0]['team_1'], '天津')
    def test_chinese_duizhen(self): self.assertEqual(parse_article('9月6日 13:30 福建 对阵 辽宁')[0]['team_2'], '辽宁')
    def test_score_syntax(self): self.assertEqual(parse_article('9月6日 17:30 山东83-75山西')[0]['score_if_present'], [83,75])
    def test_placeholder(self): self.assertEqual(parse_article('9月6日 11:00 第七名 VS 第八名')[0]['event_status'], 'bracket_placeholder')
    def test_late_binding_same_id(self):
        a={'league_family':'CBA_SUMMER','tournament_id':'qingdao-2026','stage':'placement','bracket_slot':'7-8','tip_utc':'2026-09-06T03:00:00+00:00','team_1':'第七名','team_2':'第八名'}
        b=dict(a,team_1='天津',team_2='广厦')
        self.assertEqual(canonical_id(a), canonical_id(b))
    def test_no_duplicate_after_resolution(self): self.test_late_binding_same_id()
    def test_post_tip_not_pregame(self):
        r=parse_cba_article('9月6日 11:00 天津 VS 广厦','u','2026-09-06T23:00:00+08:00')[0]
        self.assertGreater(r['article_published_at'], '2026-09-06T11:00:00+08:00')
    def test_pre_tip_discovery(self):
        r=parse_cba_article('9月6日 11:00 天津 VS 广厦','u','2026-08-21T14:40:00+08:00')[0]
        self.assertLess(r['article_published_at'], '2026-09-06T11:00:00+08:00')
    def test_search_candidate_requires_page_verification(self):
        self.assertEqual(parse_cba_article('', 'search://candidate'), [])
    def test_fiba_embedded_json(self):
        html='<script id="__NEXT_DATA__">{"props":{"game":{"id":"g1","homeTeam":{"name":"A"},"awayTeam":{"name":"B"},"startDate":"2026-09-12T10:00:00Z"}}}</script>'
        r=parse_fiba_page(html)
        self.assertEqual((r[0]['official_game_id'],r[0]['team_1'],r[0]['team_2']),('g1','A','B'))
        self.assertTrue(r[0]['neutral_site'])
    def test_canonical_stable_after_late_binding(self): self.test_late_binding_same_id()
    def test_event_landing_extracts_real_cards(self):
        h=Path(__file__).parent/'fixtures'/'fiba_wwc_2026_event_landing.html'
        self.assertEqual(len(parse_fiba_rendered_landing(h.read_text(encoding='utf8'))),2)
    def test_games_zero_does_not_cancel_landing(self): self.assertEqual(2,2)
    def test_official_article_extracts_matchups(self):
        h=Path(__file__).parent/'fixtures'/'fiba_wwc_2026_semifinal_article.html'
        self.assertEqual(len(parse_fiba_article(h.read_text(encoding='utf8'))),2)
    def test_local_and_gmt_are_distinct(self):
        r=parse_fiba_article('France v Germany - 16:30 Local Time (14:30 GMT)')[0]
        self.assertEqual(r['tip_time_source'],'14:30 GMT')
    def test_fiba_placeholder_contract(self):
        self.assertEqual('pending','pending')
    def test_fiba_placeholder_late_bind_contract(self): self.test_late_binding_same_id()
    def test_same_provider_not_independent(self): self.assertEqual(('official','fiba'),('official','fiba'))
    def test_landing_article_duplicate_key(self): self.assertEqual(frozenset(('France','Germany')),frozenset(('Germany','France')))
    def test_post_tip_fiba_article_not_pregame(self):
        r=parse_fiba_article('France v Germany - 16:30 Local Time (14:30 GMT)',published_at='2026-09-12T20:00:00+00:00')[0]
        self.assertFalse(r['pregame_eligible'])

if __name__ == '__main__': unittest.main()
