import sys
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / 'scripts'
sys.path.insert(0, str(SCRIPTS))

from repair_v22.model import competition_match, price_event


class ColdStartPricingTests(unittest.TestCase):
    def event(self, family='HIGH_UNCERTAINTY', key='AUSTRALIA_NBL'):
        return {
            'event_id': 'target', 'team1_id': 'A', 'team2_id': 'B',
            'team1_name': '甲', 'team2_name': '乙',
            'competition_id': '7m-comp:current', 'competition_key': key,
            'league': '澳大利亚国家篮球联赛', 'league_family': key,
            'gender': 'MEN', 'format_id': 'BASKETBALL',
            'model_family': family, 'identity_verified': True,
            'tip_at': '2026-09-25T12:00:00+00:00',
        }

    def game(self, eid, a, b, day, key='AUSTRALIA_NBL', comp='7m-comp:previous', kind='TEAM_HISTORY'):
        return {
            'event_id': eid, 'team1_id': a, 'team2_id': b,
            'team1_name': a, 'team2_name': b, 'competition_id': comp,
            'competition_key': key, 'league': '澳大利亚国家篮球联赛',
            'gender': 'MEN', 'format_id': 'BASKETBALL', 'status': 'FINAL',
            'tip_at': f'2026-06-{day:02d}T12:00:00+00:00',
            'known_final_at': '2026-09-01T00:00:00+00:00',
            'score1_regulation': 84, 'score2_regulation': 78,
            'score1_full': 84, 'score2_full': 78,
            'ot_points1': 0, 'ot_points2': 0,
            'evidence_kind': kind,
        }

    def test_cross_season_team_history_is_allowed_only_in_bootstrap_path(self):
        e = self.event()
        g = self.game('g1', 'A', 'X', 1)
        self.assertIsNone(competition_match(e, g))
        p = price_event(e, [g], '2026-09-20T00:00:00+00:00', 'FORWARD_NATIVE')
        self.assertEqual(p['pricing_status'], 'UNPRICEABLE')
        self.assertIn('INSUFFICIENT_PRE_CUTOFF_HISTORY', p['blockers'])

    def test_cross_season_bootstrap_emits_ess_and_wider_scale(self):
        e = self.event()
        history = []
        opponents = ['X', 'Y', 'Z', 'X', 'Y', 'Z']
        for i, o in enumerate(opponents, 1):
            history.append(self.game(f'a{i}', 'A', o, i))
            history.append(self.game(f'b{i}', 'B', o, i + 8))
        p = price_event(e, history, '2026-09-20T00:00:00+00:00', 'FORWARD_NATIVE')
        self.assertNotEqual(p['pricing_status'], 'UNPRICEABLE')
        self.assertEqual(p['pricing_state'], 'COLD_START_PRICEABLE')
        self.assertGreaterEqual(p['effective_sample_size'], 3.0)
        self.assertGreater(p['cold_start_residual_multiplier'], 1.0)
        self.assertFalse(p['shadow_eligible'])
        self.assertFalse(p['executable_eligible'])

    def test_h2h_cannot_be_used_as_cross_competition_bootstrap(self):
        e = self.event()
        history = [self.game(f'g{i}', 'A', f'X{i}', i, kind='H2H') for i in range(1, 7)]
        p = price_event(e, history, '2026-09-20T00:00:00+00:00', 'FORWARD_NATIVE')
        self.assertEqual(p['pricing_status'], 'UNPRICEABLE')

    def test_national_team_bootstrap_has_separate_state(self):
        e = self.event('NATIONAL_TEAM', 'FIBA_MEN')
        e['league'] = 'FIBA男子国家队'
        history = []
        for i, o in enumerate(['X', 'Y', 'Z', 'X', 'Y', 'Z'], 1):
            g = self.game(f'a{i}', 'A', o, i, key='FIBA_QUALIFIER', comp='fiba:old')
            g['league'] = 'FIBA男篮世界杯预选赛'
            history.append(g)
            g2 = dict(g, event_id=f'b{i}', team1_id='B', team2_id=o)
            history.append(g2)
        p = price_event(e, history, '2026-09-20T00:00:00+00:00', 'FORWARD_NATIVE')
        self.assertNotEqual(p['pricing_status'], 'UNPRICEABLE')
        self.assertEqual(p['pricing_state'], 'NATIONAL_TEAM_BOOTSTRAP')
        self.assertFalse(p['shadow_eligible'])


if __name__ == '__main__':
    unittest.main()
