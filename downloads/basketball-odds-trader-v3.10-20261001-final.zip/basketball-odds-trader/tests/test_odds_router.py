import unittest
from odds_discovery import route

class OddsRouterTests(unittest.TestCase):
    def test_no_market_does_not_delete_event(self):
        out=route([{'event_id':'e1'}],[])
        self.assertEqual(out[0]['market_status'],'NO_MARKET')
        self.assertTrue(out[0]['odds_attempted'])

    def test_direct_quote_is_market_found(self):
        out=route([{'event_id':'e1'}],[{'event_id':'e1','market_type':'SPREAD'}])
        self.assertEqual(out[0]['market_status'],'MARKET_FOUND')
        self.assertEqual(out[0]['market_match_method'],'DIRECT_ID')

if __name__=='__main__': unittest.main()
