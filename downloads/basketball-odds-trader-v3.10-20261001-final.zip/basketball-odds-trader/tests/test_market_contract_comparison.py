import json
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

from repair_v22.report import HTML
from repair_v22.source import parse_odds


class SevenMMarketContractTests(unittest.TestCase):
    def setUp(self):
        self.contracts = {
            "platform_semantics_evidence": {"source": "real archived 7M JS"},
            "companies": {
                "0": {
                    "price_format": "HK",
                    "spread_line_basis": "FLAG",
                    "spread_flag_map": {"0": -1, "1": 1},
                    "timestamp_semantics": "LAST_CHANGE",
                    "current_board_contract_verified": True,
                    "overtime_rule": "INCLUDING_OT",
                    "rule_evidence": "USER_POLICY",
                    "comparison_scope": "PAPER_RESEARCH_ONLY",
                }
            },
        }

    def parse(self):
        payload = (
            'var bOdds=[];bOdds[0]=[];bOdds[0][123]={'
            '"HB":{"0":[0.80,0.90,"2026-09-15 08:00:00",3.5,0,0,0,1],'
            '"1":[0.91,0.79,"2026-09-15 08:00:00",4.5,1,0,0,0]},'
            '"TP":{"0":[0.82,0.88,"2026-09-15 08:00:00",148.5,0,0,1]}};'
        )
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "comlive_0.js"
            path.write_text(payload, encoding="utf-8")
            return parse_odds(payload, path, "2026-09-15T00:01:00+00:00", "0", self.contracts)

    def test_handicap_flag_binds_line_to_team1(self):
        quotes, errors = self.parse()
        self.assertEqual(errors, [])
        spread = [q for q in quotes if q["market_type"] == "SPREAD"]
        self.assertEqual(spread[0]["line_team1"], -3.5)
        self.assertEqual(spread[1]["line_team1"], 4.5)
        self.assertTrue(all(q["direction_verified"] for q in spread))

    def test_source_main_flag_is_not_inferred_from_market_count(self):
        quotes, _ = self.parse()
        spread = [q for q in quotes if q["market_type"] == "SPREAD"]
        self.assertEqual([q["main_or_alt"] for q in spread], ["MAIN", "ALT"])
        total = next(q for q in quotes if q["market_type"] == "TOTAL")
        self.assertEqual(total["main_or_alt"], "MAIN")

    def test_hong_kong_prices_are_converted_to_decimal(self):
        quotes, _ = self.parse()
        self.assertEqual(quotes[0]["decimal_prices"], [1.8, 1.9])
        self.assertEqual(quotes[0]["comparison_scope"], "PAPER_RESEARCH_ONLY")

    def test_legacy_short_array_is_observation_only(self):
        payload = 'bOdds[0][123]={"HB":{"0":[0.80,0.90,"2026-09-15 08:00:00",3.5,0]}};'
        quotes, errors = parse_odds(
            payload, "missing", "2026-09-15T00:01:00+00:00", "0", self.contracts
        )
        self.assertEqual(errors, [])
        self.assertEqual(len(quotes), 1)
        self.assertEqual(quotes[0]["main_or_alt"], "UNVERIFIED")


class DashboardComparisonTests(unittest.TestCase):
    def test_paper_bet_filter_is_present_and_uses_frozen_action(self):
        self.assertIn('id="filter"', HTML)
        self.assertIn('PAPER_BETTABLE', HTML)
        self.assertIn("shadow_action==='SHADOW_BET'", HTML)

    def test_non_triggered_comparison_still_shows_direction(self):
        self.assertIn("a.comparison_ready?a.selected:null", HTML)
        self.assertIn("模型相对盘口方向", HTML)
        self.assertIn("独立模型 vs 实际盘口", HTML)

    def test_page_does_not_compute_a_second_decision(self):
        self.assertNotIn("research_edge_pass", HTML)
        self.assertNotIn("conditional_edge", HTML)


if __name__ == "__main__":
    unittest.main()
