import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]/'scripts'))
from pricing.price_game import price_game
from pricing.distributions import push_probs

class PricingTests(unittest.TestCase):
 def base(self): return {'pace':100,'ortg':115,'drtg':108,'team_strength_quality':90,'roster_quality':90,'minutes_quality':80,'injury_quality':80,'schedule_quality':80,'market_anchor_quality':90,'historical_sample_quality':90}
 def test_nba_priced(self):
  r=price_game({'league_family':'NBA'},self.base(),dict(self.base(),ortg=110),{'margin':5});self.assertEqual(r['pricing_status'],'PRICED');self.assertEqual(r['model_family'],'CLUB_MATURE')
 def test_national_sparse(self):
  r=price_game({'league_family':'FIBA_WOMEN'},dict(prior=8,roster_value=2),dict(prior=0,roster_value=0),{'margin':4});self.assertEqual(r['model_family'],'NATIONAL_TEAM');self.assertLess(r['model_weight'],.65)
 def test_summer_market_anchored(self):
  r=price_game({'league_family':'CBA_SUMMER'},dict(prior_margin=3),dict(prior_margin=0),{'margin':2});self.assertEqual(r['pricing_status'],'MARKET_ANCHORED')
 def test_unpriceable(self): self.assertEqual(price_game({'league_family':'NBA'},{}, {},{})['pricing_status'],'UNPRICEABLE')
 def test_push_integer(self):
  r=push_probs(-4,-5,12);self.assertAlmostEqual(r['p_win']+r['p_push']+r['p_loss'],1)
 def test_half_point(self): self.assertEqual(push_probs(-4.5,-5,12)['p_push'],0)
 def test_totals_from_possessions(self):
  r=price_game({'league_family':'NBA'},self.base(),self.base(),{'margin':0});self.assertAlmostEqual(r['projected_home_points'],115)
if __name__=='__main__':unittest.main()
