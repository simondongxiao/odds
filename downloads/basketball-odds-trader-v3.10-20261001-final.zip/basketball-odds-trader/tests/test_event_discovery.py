import sys, unittest
from datetime import datetime, timezone
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parents[1] / "scripts"))
from discover_events import discover_independently, normalize, canonical_id
from reconcile_events import reconcile, reconcile_status
from discover_events import normalize

def ev(family="CBA_SUMMER", a="广东宏远", b="辽宁本钢", tip="2026-09-12T10:00:00+00:00", **kw):
    return {"league_family":family,"team_1":a,"team_2":b,"tip_utc":tip,**kw}

class EventDiscoveryTests(unittest.TestCase):
    def test_cba_summer_only_special_source(self):
        adapters={"broad":lambda d:[],"cba_specific":lambda d:[ev() for _ in range(4)],"fiba":lambda d:[]}
        raw, union, _ = discover_independently(adapters,"2026-09-12")
        self.assertEqual(len(raw["cba_specific"]),4); self.assertEqual(len(union),1)
        # Four same-ID source rows represent one canonical event; distinct IDs are tested below.
        rows=[ev(tip=f"2026-09-12T{10+i:02d}:00:00+00:00") for i in range(4)]
        _, union, _=discover_independently({"broad":lambda d:[],"cba_specific":lambda d:rows},"2026-09-12")
        self.assertEqual(len(union),4)

    def test_odds_board_only_is_kept(self):
        _, union, _=discover_independently({"scoreboard":lambda d:[],"odds_board":lambda d:[ev(family="OTHER_DISCOVERED")]},"2026-09-12")
        rows,_=reconcile(union); self.assertEqual(rows[0]["reconciliation_status"],"reconciled"); self.assertIn("odds_board",rows[0]["sources"])

    def test_cross_midnight_us_game(self):
        row=normalize(ev("NBA",tip="2026-09-12T02:00:00+00:00"),"espn")
        self.assertEqual(row["bj_date"],"2026-09-12")

    def test_team_aliases(self):
        aliases={"Guangdong Southern Tigers":"广东宏远","广东宏远":"广东宏远","广东东阳光":"广东宏远"}
        self.assertEqual(canonical_id(ev(a="Guangdong Southern Tigers"),aliases),canonical_id(ev(a="广东东阳光"),aliases))

    def test_fiba_neutral_order(self):
        row=normalize(ev("FIBA_WOMEN",a="Spain",b="USA",neutral_site=True),"fiba")
        self.assertIsNone(row["home"]); self.assertIsNone(row["away"]); self.assertEqual(row["score_order"],"official_source_order")

    def test_source_zero_is_not_no_games(self):
        raw, union, status=discover_independently({"a":lambda d:[],"b":lambda d:[ev()]},"2026-09-12")
        self.assertNotEqual(reconcile_status(status,len(union),True),"verified_no_games")

    def test_union_does_not_short_circuit(self):
        called=[]
        def adapter(name, rows):
            def f(d): called.append(name); return rows
            return f
        discover_independently({"a":adapter("a",[ev()]),"b":adapter("b",[]),"c":adapter("c",[])},"2026-09-12")
        self.assertEqual(called,["a","b","c"])

    def test_live_adapter_failure_does_not_terminate_union(self):
        seen=[]
        def bad(d): seen.append("bad"); raise TimeoutError("x")
        def good(d): seen.append("good"); return [ev()]
        raw, union, status=discover_independently({"bad":bad,"good":good},"2026-09-12")
        self.assertEqual(seen,["bad","good"]); self.assertEqual(len(union),1); self.assertTrue(isinstance(status["bad"],dict))

    def test_source_group_deduplication(self):
        rows=[normalize(ev(),"a"),normalize(ev(),"b")]
        rows[0]["source_group"]="broad"; rows[1]["source_group"]="broad"
        _, conflicts=reconcile({rows[0]["canonical_event_id"]:rows})
        self.assertEqual(conflicts,[])

    def test_same_upstream_not_counted_twice(self):
        rows=[normalize(ev(),"dash"),normalize(ev(),"betnova")]
        for row in rows: row["upstream_provider"]="generationweb"
        providers={r["upstream_provider"] for r in rows}; self.assertEqual(len(providers),1)

    def test_malformed_response_classification(self):
        def malformed(d): raise ValueError("schema")
        _,_,status=discover_independently({"x":malformed},"2026-09-12")
        self.assertEqual(status["x"]["status"],"error")

    def test_odds_only_later_reconciles(self):
        a=normalize(ev(),"score"); b=normalize(ev(),"odds"); b["source_group"]="odds_board"; b["discovered_from_odds_board"]=True; b["scoreboard_verified"]=False
        rows,conflicts=reconcile({a["canonical_event_id"]:[a,b]}); self.assertEqual(len(rows),1); self.assertEqual(rows[0]["source_count"],2)

    def test_tip_time_change_does_not_duplicate(self):
        a=normalize(ev(tip="2026-09-12T10:00:00+00:00"),"a"); b=normalize(ev(tip="2026-09-12T10:01:00+00:00"),"b")
        # Official ID, when available later, is the stable merge key.
        a["official_game_id"]=b["official_game_id"]="G1"; a["canonical_event_id"]=b["canonical_event_id"]="CBA_SUMMER:G1"
        rows,_=reconcile({"CBA_SUMMER:G1":[a,b]}); self.assertEqual(len(rows),1)

    def test_official_id_replaces_hash_with_alias(self):
        aliases={"Guangdong Southern Tigers":"广东宏远","广东东阳光":"广东宏远"}
        hashed=normalize(ev(a="Guangdong Southern Tigers"),"a",aliases); official=normalize(ev(a="广东东阳光",official_game_id="G1"),"b",aliases)
        self.assertEqual(hashed["team_1_normalized"],official["team_1_normalized"]); self.assertNotEqual(hashed["canonical_event_id"],official["canonical_event_id"])

if __name__ == "__main__": unittest.main()
