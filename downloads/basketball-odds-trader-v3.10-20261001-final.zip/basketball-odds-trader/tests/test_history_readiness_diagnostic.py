import sys
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / 'scripts'
sys.path.insert(0, str(SCRIPTS))

from repair_v22.history_readiness_diagnostic import build_history_readiness_diagnostic


class HistoryReadinessDiagnosticTests(unittest.TestCase):
    def test_waterfall_reports_ready_and_alias_failure_without_changing_model(self):
        event = {
            'event_id': '7m:e1', 'canonical_event_id': '7m:e1',
            'team1_id': '7m-team:1', 'team1_name': 'A',
            'team2_id': '7m-team:2', 'team2_name': 'B',
            'league': 'WNBA', 'gender': 'WOMEN', 'model_family': 'CLUB_MATURE',
            'competition_id': '7m-comp:1', 'tip_at': '2026-09-24T20:00:00+08:00',
        }
        history = []
        for i in range(3):
            history.append({
                'event_id': f'7m:h{i}', 'team1_id': '7m-team:1', 'team2_id': f'7m-team:{10+i}',
                'team1_name': 'A', 'team2_name': 'X', 'gender': 'WOMEN',
                'competition_id': '7m-comp:1', 'status': 'FINAL',
                'score1_full': 80, 'score2_full': 70,
                'tip_at': f'2026-09-{20-i:02d}T12:00:00+00:00',
                'known_final_at': '2026-09-23T12:00:00+00:00',
            })
        row = {'id': '7m:e1', 'event': event}
        capture = {'history': history, 'history_page_audit': [
            {'team_source_id': '1', 'http_success': True, 'parsed_games': 3, 'url': 'x'},
            {'team_source_id': '2', 'http_success': True, 'parsed_games': 0, 'url': 'y'},
        ], 'team_history_games_parsed': 3}
        result = build_history_readiness_diagnostic([row], capture, Path('D:/codex/outputs/basketball_odds_trader/test-diagnostic'), '2026-09-24T12:00:00+00:00')
        self.assertEqual(result['team_count'], 2)
        self.assertTrue(result['events'][0]['team1']['history_ready'])
        self.assertEqual(result['events'][0]['team2']['primary_history_failure'], 'SOURCE_HISTORY_GENUINELY_ABSENT')


if __name__ == '__main__':
    unittest.main()
