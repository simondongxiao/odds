import sys,unittest,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]/'scripts'))
from execution.gate import evaluate
from execution.paper_ledger import append,append_settlement
class ExecutionTests(unittest.TestCase):
 def p(self): return {'calibrated_win_probability':.62,'p_conservative':.62,'p_push':0}
 def m(self,**x):
  r=dict(market_status='OPEN',line=-4.5,price=1.95,decimal_odds=1.95);r.update(x);return r
 def q(self,n=90): return {'pricing_data_quality':n}
 def test_edge(self): self.assertEqual(evaluate(self.p(),self.m(),self.q(),'CLUB_MATURE')['model_state'],'EDGE')
 def test_stale_block(self): self.assertEqual(evaluate(self.p(),self.m(market_status='STALE'),self.q(),'CLUB_MATURE')['shadow_action'],'BLOCKED')
 def test_reprice(self): self.assertIn('BLOCKED_PENDING_REPRICE',evaluate(self.p(),self.m(),self.q(),'CLUB_MATURE',reprice=True)['blockers'])
 def test_intent_isolation(self): self.assertEqual(evaluate(self.p(),self.m(),self.q(),'CLUB_MATURE',intent='诱上')['EV'],evaluate(self.p(),self.m(),self.q(),'CLUB_MATURE',intent='真实示强')['EV'])
 def test_integer_push(self): r=evaluate(dict(self.p(),p_push=.08),self.m(line=-4),self.q(),'CLUB_MATURE');self.assertAlmostEqual(r['EV'],.62*.95-(1-.62-.08))
 def test_price_exhausted(self): self.assertEqual(evaluate(self.p(),self.m(price=1.8,decimal_odds=1.8,min_acceptable_decimal_odds=1.91),self.q(),'CLUB_MATURE')['shadow_action'],'PASS_PRICE_EXHAUSTED')
 def test_no_market(self): self.assertEqual(evaluate(self.p(),{},self.q(),'CLUB_MATURE')['shadow_action'],'BLOCKED')
 def test_real_stake_zero(self): self.assertEqual(evaluate(self.p(),self.m(),self.q(),'CLUB_MATURE')['real_stake'],0)
 def test_ledger_immutable_settlement_append(self):
  with tempfile.TemporaryDirectory() as d:
   r=evaluate(self.p(),self.m(),self.q(),'CLUB_MATURE');append(d,r)
   with self.assertRaises(FileExistsError):append(d,r)
   append_settlement(d,r['prediction_id'],{'settlement_event_id':'s1','win_push_loss':'push'})
if __name__=='__main__':unittest.main()
