import tempfile
import unittest
from pathlib import Path

from providers.titan007_history_adapter import (
    TitanHistoryStore,
    _search_name,
    merge_reference_history,
    parse_box_score_blob,
    parse_period_scores,
    parse_search_response,
    parse_team_schedule,
)


class Titan007HistoryAdapterTests(unittest.TestCase):
    def test_search_name_strips_only_trailing_7m_display_suffixes(self):
        self.assertEqual(_search_name("海法夏普尔[以篮甲5]"), "海法夏普尔")
        self.assertEqual(_search_name("BC梅塔潘[1]"), "BC梅塔潘")
        self.assertEqual(_search_name("球队[正式名]附加"), "球队[正式名]附加")

    def test_exact_search_mapping_does_not_fuzzy_force(self):
        exact = parse_search_response("145^费内巴切,1145^费内巴切青年", "费内巴切")
        self.assertEqual(exact["exact"]["team_id"], "145")
        missing = parse_search_response("1145^费内巴切青年", "费内巴切")
        self.assertEqual(missing["status"], "NOT_FOUND")

    def test_search_page_maps_all_language_aliases_and_rejects_ambiguity(self):
        page = '''<table><tr><td><a href="/League/Index_cn.aspx?SclassID=25">土篮超</a></td>
        <td><a href="/cn/Team/Summary.aspx?TeamID=145">费内巴切</a></td>
        <td><a href="/cn/Team/Summary.aspx?TeamID=145">费内巴切</a></td>
        <td><a href="/big/Team/Summary.aspx?TeamID=145">費倫巴治</a></td>
        <td><a href="../Team/Summary.aspx?TeamID=145">Fenerbahce Ulker</a></td></tr>
        <tr><td><a href="/League/Index_cn.aspx?SclassID=237">土女篮</a></td>
        <td><a href="/cn/Team/Summary.aspx?TeamID=2598">费内巴切女篮</a></td></tr></table>'''
        result = parse_search_response(page, "Fenerbahce Ulker")
        self.assertEqual(result["exact"]["team_id"], "145")
        self.assertEqual(result["exact"]["league_id"], "25")
        ambiguous = parse_search_response(page.replace("费内巴切女篮", "费内巴切"), "费内巴切")
        self.assertEqual(ambiguous["status"], "AMBIGUOUS")
        self.assertIsNone(ambiguous["exact"])

    def test_schedule_and_period_parser(self):
        js = "var teamPageData=[[722921,7,'#E87100','2026/09/30 01:45',145,3891,\"<font>100</font>-<font>76</font>\",'50-31','Euro','Euro','EURO','费内巴切','費倫巴治','Fenerbahce','拜仁','拜仁','Bayern',-1,true,-1]];"
        row = parse_team_schedule(js)[0]
        self.assertEqual((row["home_score"], row["away_score"]), (100, 76))
        page = '<span id="scoreData"><table><tr><th>完</th><th>1节</th><th>2节</th><th>3节</th><th>4节</th><th>半场</th><th>全场</th></tr><tr><td>31</td><td>19</td><td>25</td><td>25</td><td>50</td><td>100</td></tr><tr><td>15</td><td>16</td><td>20</td><td>25</td><td>31</td><td>76</td></tr></table></span>'
        period = parse_period_scores(page)
        self.assertEqual(period["home_periods"], [31, 19, 25, 25])
        self.assertEqual(period["away_score"], 76)

    def test_box_score_level_b_and_safe_level_d(self):
        total_home = "200^38^67^15^30^9^11^9^9^18^25^19^7^11^3^100"
        total_away = "201^28^57^7^27^13^17^7^7^14^15^16^3^14^3^76"
        result = parse_box_score_blob("head$player!" + total_home + "!pct$player!" + total_away + "!pct$145^0!3891^0")
        self.assertEqual(result["pace_level"], "LEVEL_B")
        self.assertAlmostEqual(result["home"]["possessions_estimate"], 73.84)
        broken = parse_box_score_blob("head$player!1^2!pct$player!1^2!pct$145^0!3891^0")
        self.assertEqual(broken["pace_level"], "LEVEL_D")

    def test_raw_snapshot_is_immutable_and_db_has_no_ledger_tables(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = TitanHistoryStore(tmp)
            first = store.snapshot("https://example.test", b"abc", "text/plain", "test", "1", "2026-09-30T00:00:00+00:00")
            second = store.snapshot("https://example.test", b"abc", "text/plain", "test", "1", "2026-09-30T00:00:00+00:00")
            self.assertEqual(first, second)
            tables = {row[0] for row in store.db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            self.assertFalse(any("ledger" in name or "pnl" in name for name in tables))
            store.close()

    def test_reference_merge_deduplicates_mirror_and_rejects_other_competition(self):
        event = {"team1_id": "7m:1", "team2_id": "7m:2", "competition_key": "EUROLEAGUE"}
        base = {"event_id": "7m:old", "team1_id": "7m:1", "team2_id": "7m:9",
                "competition_key": "EUROLEAGUE", "tip_at": "2026-09-20T18:00:00+00:00",
                "score1_full": 90, "score2_full": 80}
        mirror = dict(base, event_id="titan:mirror", team2_id="titan-team:9",
                      tip_at="2026-09-20T18:05:00+00:00")
        fresh = dict(base, event_id="titan:fresh", team2_id="titan-team:8",
                     tip_at="2026-09-22T18:00:00+00:00", score1_full=88, score2_full=77)
        wrong = dict(fresh, event_id="titan:wrong", competition_key="EUROCUP")
        merged, audit = merge_reference_history([base], [mirror, fresh, wrong], [event])
        self.assertEqual([row["event_id"] for row in merged], ["7m:old", "titan:fresh"])
        self.assertEqual(audit["mirrored_duplicate"], 1)
        self.assertEqual(audit["added"], 1)


if __name__ == "__main__":
    unittest.main()
