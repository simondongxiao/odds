import sys
import unittest
from pathlib import Path

SCRIPTS=Path(__file__).resolve().parents[1]/'scripts'
sys.path.insert(0,str(SCRIPTS))

from repair_v22.common import competition_key
from repair_v22.model import eligible_history, price_event
from repair_v22.source import parse_history


class TeamHistorySchemaTests(unittest.TestCase):
    def test_real_n_history_24_field_schema(self):
        row=[1001,9,'2026,09,01,12,00,00','WNBA','FF00EE',10,'球队甲',20,'球队乙',20,21,22,23,0,18,19,20,21,0,0,1,4,'常规赛',9]
        rows,errors=parse_history('var t_history='+repr([row])+';','missing','2026-09-15T00:00:00+00:00','https://bdata.7m.com.cn/Basketball_Team_Data/10/gb/n_history.js','TEAM_HISTORY')
        self.assertEqual(errors,[]);self.assertEqual(len(rows),1)
        g=rows[0]
        self.assertEqual((g['team1_id'],g['team2_id']),('7m-team:10','7m-team:20'))
        self.assertEqual((g['score1_full'],g['score2_full']),(86,78))
        self.assertEqual(g['competition_key'],'WNBA');self.assertIsNone(g['competition_id'])
        self.assertEqual(g['source_schema'],'N_HISTORY_24')

    def test_a_wf_25_field_schema_unchanged(self):
        row=[1002,9,'2026,09,01,12,00,00',99,'WNBA',4,'FF00EE',10,20,'球队甲','球队乙',20,21,22,23,0,18,19,20,21,0,'41/45','37/41',0,'常规赛']
        rows,errors=parse_history('var a_wf='+repr([row])+';','missing','2026-09-15T00:00:00+00:00','https://bdata.7m.com.cn/js/1/2.js','H2H')
        self.assertEqual(errors,[]);self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]['competition_id'],'7m-comp:99')
        self.assertEqual(rows[0]['source_schema'],'A_WF_25')

    def test_documented_competition_aliases(self):
        self.assertEqual(competition_key('美国女子职业篮球联赛','WOMEN'),'WNBA')
        self.assertEqual(competition_key('WNBA','WOMEN'),'WNBA')
        self.assertEqual(competition_key('澳大利亚国家篮球联赛','MEN'),'AUSTRALIA_NBL')
        self.assertEqual(competition_key('EURO','MEN'),'EUROLEAGUE')
        self.assertEqual(competition_key('法国篮球杯赛','MEN'),competition_key('法国杯','MEN'))


class TeamHistoryPricingTests(unittest.TestCase):
    def event(self):
        return {'event_id':'target','team1_id':'A','team2_id':'B','team1_name':'甲','team2_name':'乙',
                'competition_id':'7m-comp:10','competition_key':'WNBA','league':'美国女子职业篮球联赛',
                'gender':'WOMEN','format_id':'BASKETBALL','model_family':'CLUB_MATURE','identity_verified':True,
                'tip_at':'2026-09-16T00:00:00+00:00'}

    def game(self,eid,a,b,n,kind='TEAM_HISTORY',comp_id=None,key='WNBA'):
        return {'event_id':eid,'team1_id':a,'team2_id':b,'team1_name':a,'team2_name':b,
                'competition_id':comp_id,'competition_key':key,'league':'WNBA','gender':'WOMEN','format_id':'BASKETBALL',
                'status':'FINAL','tip_at':f'2026-08-{n:02d}T00:00:00+00:00','known_final_at':'2026-09-01T00:00:00+00:00',
                'score1_regulation':80+n,'score2_regulation':70,'score1_full':80+n,'score2_full':70,
                'ot_points1':0,'ot_points2':0,'evidence_kind':kind}

    def test_team_history_label_identity_is_eligible(self):
        e=self.event();h=[self.game('g1','A','X',1)]
        good,reject=eligible_history(e,h,'2026-09-15T00:00:00+00:00','FORWARD_NATIVE')
        self.assertEqual(len(good),1);self.assertNotIn('COMPETITION_MISMATCH',reject)

    def test_h2h_different_source_id_cannot_borrow_label(self):
        e=self.event();h=[self.game('g1','A','X',1,kind='H2H',comp_id='7m-comp:999')]
        good,reject=eligible_history(e,h,'2026-09-15T00:00:00+00:00','FORWARD_NATIVE')
        self.assertEqual(good,[]);self.assertEqual(reject['COMPETITION_MISMATCH'],1)

    def test_independent_pricing_runs_with_real_team_history_contract(self):
        e=self.event();h=[]
        opponents_a=['X','Y','Z','X','Y','Z','X','Y']
        opponents_b=['X','Y','Z','X','Y','Z','X','Y']
        for i,o in enumerate(opponents_a,1):h.append(self.game('a'+str(i),'A',o,i))
        for i,o in enumerate(opponents_b,10):h.append(self.game('b'+str(i),'B',o,i))
        p=price_event(e,h,'2026-09-15T00:00:00+00:00','FORWARD_NATIVE')
        self.assertEqual(p['pricing_status'],'PRICED_LOW_CONFIDENCE')
        self.assertTrue(p['paper_model_eligible'])
        self.assertEqual(p['competition_match_methods'],{'CANONICAL_SOURCE_LABEL':16})
        self.assertIsNotNone(p['mu_raw']);self.assertIsNotNone(p['total_raw'])


if __name__=='__main__':
    unittest.main()
