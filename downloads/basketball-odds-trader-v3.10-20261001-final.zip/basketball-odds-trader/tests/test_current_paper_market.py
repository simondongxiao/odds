import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from repair_v22.report import _preserve_first_write_paper_rows, funnel, HTML


def row(line, fresh=True, triggered=False):
    return {'id': '7m:123', 'event': {'event_id': '7m:123'},
            'pricing': {'pricing_status': 'PRICED'},
            'market': {'quotes': [{'line_team1': line}], 'quote_states': [
                {'raw_observation': True, 'fresh_observation': fresh}]},
            'execution': {'triggered': triggered, 'shadow_action': 'SHADOW_BET' if triggered else 'WATCH',
                          'comparison_ready': True, 'prediction_id': 'original' if triggered else 'new'}}


class CurrentPaperMarketTests(unittest.TestCase):
    def merge(self, prior, refreshed):
        with tempfile.TemporaryDirectory(dir='D:/codex') as tmp:
            p = Path(tmp) / 'daily.json'
            p.write_text(json.dumps({'events': [prior]}), encoding='utf-8')
            return _preserve_first_write_paper_rows(p, refreshed, 'new-time')[0]

    def test_current_quote_updates_without_changing_first_write(self):
        original = row(-3.5, triggered=True)
        result = self.merge(original, [row(-5.5)])
        self.assertEqual(result['execution'], original['execution'])
        self.assertEqual(result['market'], original['market'])
        self.assertEqual(result['current_snapshot']['market']['quotes'][0]['line_team1'], -5.5)
        self.assertEqual(result['current_snapshot']['asof'], 'new-time')

    def test_missing_quote_does_not_reuse_original_freshness(self):
        result = self.merge(row(-3.5, triggered=True), [])
        self.assertEqual(result['current_snapshot']['market']['quotes'], [])
        self.assertEqual(result['current_snapshot']['execution']['market_revalidation']['status'],
                         'REVALIDATION_UNAVAILABLE')
        self.assertEqual(funnel([result])['fresh_market_events'], 0)
        self.assertEqual(funnel([result])['paper_triggered_events'], 1)

    def test_repeat_refresh_keeps_original_and_updates_current(self):
        result = self.merge(row(-3.5, triggered=True), [row(-5.5)])
        result = self.merge(result, [row(-7.5, fresh=False)])
        self.assertEqual(result['market']['quotes'][0]['line_team1'], -3.5)
        self.assertEqual(result['current_snapshot']['market']['quotes'][0]['line_team1'], -7.5)
        self.assertEqual(funnel([result])['fresh_market_events'], 0)

    def test_page_labels_current_and_frozen_separately(self):
        self.assertIn('本轮实际盘口', HTML)
        self.assertIn('首写盘口证据（回测依据，不代表当前盘口）', HTML)
        self.assertIn('quoteLabel(c.event,q)', HTML)


if __name__ == '__main__':
    unittest.main()
