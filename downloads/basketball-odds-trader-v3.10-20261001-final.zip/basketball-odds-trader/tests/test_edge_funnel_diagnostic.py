import sys
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

from repair_v22.pricing_funnel_diagnostic import (  # noqa: E402
    _edge_funnel,
    _edge_metrics,
)


def row_with_market(calibrated=None):
    pricing = {
        "mu_raw": -4.5,
        "total_raw": 164.0,
        "pricing_status": "PRICED",
        "pricing_mode": "NATIVE",
        "league_tier": "TIER_1",
        "residual_scale_multiplier": 1.0,
        "pricing_data_quality": 88,
    }
    if calibrated is not None:
        pricing["calibrated_fair_spread"] = calibrated
    return {
        "event": {
            "event_id": "7m:edge-test",
            "canonical_event_id": "7m:edge-test",
            "league": "WNBA",
            "league_family": "WNBA",
            "league_tier": "TIER_1",
            "team1_name": "Alpha",
            "team2_name": "Beta",
        },
        "pricing": pricing,
        "execution": {
            "market_decisions": {
                "SPREAD": {
                    "comparison_ready": True,
                    "selected": {"line": -9.5, "p_win": 0.61},
                }
            }
        },
    }


class EdgeFunnelDiagnosticTests(unittest.TestCase):
    def test_raw_edge_is_kept_separate_from_unemitted_calibration(self):
        row = row_with_market()
        result = _edge_metrics(row, "SPREAD", {
            "market_found": True,
            "fresh_market_found": True,
            "priceable": True,
            "evidence_gate_pass": True,
            "comparison_ready": True,
            "execution_gate_pass": False,
            "decision_blockers": [],
        })
        self.assertEqual(result["raw_edge_points"], 5.0)
        self.assertEqual(result["calibration_source"], "NOT_EMITTED")
        self.assertIsNone(result["calibrated_edge_points"])
        self.assertEqual(result["primary_final_reason"], "EXECUTION_BLOCKED")

    def test_explicit_calibration_can_be_flagged_for_shrinkage(self):
        row = row_with_market(calibrated=-8.0)
        result = _edge_metrics(row, "SPREAD", {
            "market_found": True,
            "fresh_market_found": True,
            "priceable": True,
            "evidence_gate_pass": True,
            "comparison_ready": True,
            "execution_gate_pass": False,
            "decision_blockers": [],
        })
        self.assertEqual(result["raw_edge_points"], 5.0)
        self.assertEqual(result["calibrated_edge_points"], 1.5)
        self.assertEqual(result["edge_retention_ratio"], 0.3)
        self.assertEqual(result["primary_final_reason"], "EDGE_REMOVED_BY_CALIBRATION")

    def test_funnel_is_split_by_market_and_preserves_stage_counts(self):
        spread = {
            "market_type": "SPREAD", "market_found": True, "fresh_market_found": True,
            "priceable": True, "comparison_ready": True, "status": "PRICEABLE_NO_EDGE",
            "league": "WNBA", "league_tier": "TIER_1", "edge_metrics": {
                "raw_edge_found": True, "calibrated_edge_found": False,
                "evidence_pass": True, "execution_pass": False,
                "pricing_mode": "NATIVE", "edge_retention_ratio": None,
                "primary_final_reason": "NO_RAW_EDGE",
            },
        }
        total = {
            "market_type": "TOTAL", "market_found": True, "fresh_market_found": True,
            "priceable": True, "comparison_ready": False, "status": "NOT_PRICEABLE",
            "league": "WNBA", "league_tier": "TIER_1", "edge_metrics": {
                "raw_edge_found": False, "calibrated_edge_found": False,
                "evidence_pass": False, "execution_pass": False,
                "pricing_mode": "NATIVE", "edge_retention_ratio": None,
                "primary_final_reason": "NO_MATCHING_MARKET",
            },
        }
        result = _edge_funnel([spread, total])
        self.assertEqual(result["markets"]["SPREAD"]["market_comparable"], 1)
        self.assertEqual(result["markets"]["SPREAD"]["raw_edge_found"], 1)
        self.assertEqual(result["markets"]["TOTAL"]["market_comparable"], 0)
        self.assertEqual(result["comparable_total"], 1)
        self.assertEqual(result["primary_final_reasons"]["NO_RAW_EDGE"], 1)


if __name__ == "__main__":
    unittest.main()
