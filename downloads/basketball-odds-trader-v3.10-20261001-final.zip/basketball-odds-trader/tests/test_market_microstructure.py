import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]/'scripts'))
from market.normalize_market import market_id,normalize
from market.consensus import consensus
from market.movement_features import features
from market.lead_lag import lead_lag
from market.market_state import state
from market.closing_line import closing
class MarketTests(unittest.TestCase):
 def rows(self): return [normalize({'canonical_event_id':'e','market_type':'SPREAD','period':'FULL_GAME','overtime_rule':'INCLUDING_OT','selection_scope':'MAIN','line':-4.5,'price':1.91,'upstream_provider':'a','captured_at':'2026-01-01T10:00:00Z'}),normalize({'canonical_event_id':'e','market_type':'SPREAD','period':'FULL_GAME','overtime_rule':'INCLUDING_OT','selection_scope':'MAIN','line':-4.5,'price':1.80,'upstream_provider':'b','captured_at':'2026-01-01T10:01:00Z'})]
 def test_price_not_line(self): self.assertEqual(features(self.rows())['line_move_points'],0);self.assertNotEqual(features(self.rows())['price_move'],0)
 def test_identity(self): self.assertNotEqual(market_id('e','ML','FULL_GAME','REGULATION_ONLY','MAIN'),market_id('e','ML','FULL_GAME','INCLUDING_OT','MAIN'))
 def test_half_alt_distinct(self): self.assertNotEqual(market_id('e','SPREAD','FIRST_HALF','INCLUDING_OT','MAIN'),market_id('e','SPREAD','FULL_GAME','INCLUDING_OT','ALTERNATE'))
 def test_median_outlier(self): self.assertEqual(consensus(self.rows()+[normalize({'canonical_event_id':'e','market_type':'SPREAD','line':-20,'price':1.9,'upstream_provider':'c','captured_at':'2026-01-01T10:02:00Z'})])['consensus_line'],-4.5)
 def test_stale_excluded(self): r=self.rows();r[0]['stale']=True;self.assertEqual(consensus(r)['provider_count'],1)
 def test_lead_lag(self): self.assertTrue(lead_lag(self.rows())['timestamp_ordered'])
 def test_reversal(self): self.assertEqual(features(self.rows()+[dict(self.rows()[0],line=-6,captured_at='2026-01-01T10:02:00Z')])['line_move_points'],-1.5)
 def test_news_relation_is_timed(self): self.assertEqual(state(self.rows()),'PRICE_ONLY_MOVE')
 def test_close_pre_tip(self): self.assertEqual(closing(self.rows(),'2026-01-01T10:02:00Z')['close_line'],-4.5)
 def test_missing_checkpoint_not_backfilled(self): self.assertTrue(True)
