import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from repair_v22.pipeline import sync_paper_settlements


class SettlementSyncTests(unittest.TestCase):
    def test_all_dates_latest_identity_and_first_write(self):
        with tempfile.TemporaryDirectory(dir='D:/codex') as tmp:
            root = Path(tmp)
            data = root/'dashboard_v2/data'
            ledger = root/'ledger/repair_v22_settlements'
            data.mkdir(parents=True)
            ledger.mkdir(parents=True)
            decision = {'prediction_id': 'p1', 'triggered': True, 'archive_type': 'FORWARD_NATIVE',
                        'selected': {'line': -3.5}, 'asof': '2026-09-01T00:00:00Z'}
            row = {'id': 'e1', 'execution': decision, 'event': {'bj_date': '2026-09-01'}, 'pricing': {'mu_raw': 7}}
            doc = {'events': [row]}
            for name in ['2026-09-01.json', 'latest.json']:
                (data/name).write_text(json.dumps(doc), encoding='utf-8')
            settlement = {'event_id': 'wrong', 'prediction_id': 'p1', 'outcome': 'WIN'}
            (ledger/'p1.json').write_text(json.dumps(settlement), encoding='utf-8')
            self.assertEqual(sync_paper_settlements(root, 'now')['counts'], {'PENDING': 1})
            settlement['event_id'] = 'e1'
            (ledger/'p1.json').write_text(json.dumps(settlement), encoding='utf-8')
            self.assertEqual(sync_paper_settlements(root, 'now')['counts'], {'WIN': 1})
            for name in ['2026-09-01.json', 'latest.json']:
                saved = json.loads((data/name).read_text(encoding='utf-8'))['events'][0]
                self.assertEqual(saved['execution'], decision)
                self.assertEqual(saved['pricing'], row['pricing'])
                self.assertEqual(saved['settlement'], settlement)
            before = (data/'latest.json').read_bytes()
            sync_paper_settlements(root, 'later')
            self.assertEqual(before, (data/'latest.json').read_bytes())
