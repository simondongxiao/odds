import sys
import tempfile
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

from repair_v22.report import HTML
from repair_v22.source import parse_odds
from repair_v22.total_market_pipeline_diagnostic import (
    build_total_market_pipeline_diagnostic,
    diagnose_total,
)


def total_row(total_quote=True, incomplete=True):
    event = {
        "event_id": "7m:total-audit", "canonical_event_id": "7m:total-audit",
        "team1_name": "甲队", "team2_name": "乙队", "league": "测试联赛",
        "league_family": "TEST", "tip_time_bj": "2026-09-25T20:00:00+08:00",
    }
    quotes = []
    states = []
    if total_quote:
        quotes.append({
            "quote_id": "total-1", "event_id": "7m:total-audit",
            "market_type": "TOTAL", "raw_line": 158.5,
            "raw_verified": True, "decimal_prices": [1.91, 1.91],
            "raw_prices": [0.91, 0.91], "bookmaker": "测试公司",
            "source_quote_at": "2026-09-25T11:59:00+00:00",
            "received_at": "2026-09-25T12:00:00+00:00",
        })
        states.append({"raw_observation": True, "fresh_observation": True,
                       "age_seconds": 60})
    blockers = ["TOTAL_CONTEXT_INCOMPLETE"] if incomplete else []
    return {
        "id": event["event_id"], "event": event, "archive_type": "FORWARD_NATIVE",
        "pricing": {"total_raw": 160.0, "blockers": [],
                    "total_diagnostic": {"hard_blockers": blockers,
                                         "soft_missing": []}},
        "market": {"quotes": quotes, "quote_states": states},
        "execution": {"market_decisions": {"TOTAL": {
            "blockers": blockers, "comparison_ready": False,
            "model_state": "UNASSESSED", "triggered": False,
        }}, "shadow_action": "WATCH", "display_action": "观察"},
    }


class TotalMarketPipelineTests(unittest.TestCase):
    def contracts(self):
        return {"platform_semantics_evidence": {"source": "test"}, "companies": {
            "0": {"price_format": "HK", "spread_line_basis": "FLAG",
                  "spread_flag_map": {"0": -1, "1": 1},
                  "timestamp_semantics": "LAST_CHANGE",
                  "current_board_contract_verified": True,
                  "overtime_rule": "INCLUDING_OT", "rule_evidence": "TEST"}
        }}

    def test_parser_preserves_handicap_and_total_in_same_event(self):
        payload = ('bOdds[0][123]={"HB":{"0":[0.80,0.90,"2026-09-25 08:00:00",3.5,0,0,0,1]},'
                   '"TP":{"0":[0.82,0.88,"2026-09-25 08:00:00",158.5,0,0,1]}};')
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "comlive_0.js"
            path.write_text(payload, encoding="utf-8")
            quotes, errors = parse_odds(payload, path, "2026-09-25T08:01:00+00:00", "0", self.contracts())
        self.assertEqual(errors, [])
        self.assertEqual({q["market_type"] for q in quotes}, {"SPREAD", "TOTAL"})
        self.assertTrue(any(q.get("raw_market_key") == "TP" for q in quotes))

    def test_real_total_quote_is_not_hidden_by_evidence_block(self):
        record = diagnose_total(total_row())
        self.assertTrue(record["raw_total_market_found"])
        self.assertTrue(record["fresh_total_market_found"])
        self.assertEqual(record["market_total"], 158.5)
        self.assertEqual(record["primary_failure"], "TOTAL_CONTEXT_INCOMPLETE")
        self.assertFalse(record["shadow_eligible"])

    def test_missing_total_is_distinct_from_unpriceable_total(self):
        with_quote = diagnose_total(total_row())
        without_quote = diagnose_total(total_row(total_quote=False))
        self.assertNotEqual(with_quote["primary_failure"], without_quote["primary_failure"])
        self.assertEqual(without_quote["primary_failure"], "RAW_MARKET_MISSING")

    def test_summary_persists_event_level_csv_and_json(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = build_total_market_pipeline_diagnostic(
                [total_row(), total_row(total_quote=False)], Path(tmp),
                "2026-09-25", "2026-09-25T12:00:00+00:00")
            out = Path(tmp) / "diagnostics"
            self.assertTrue((out / "total_market_pipeline_20260925.csv").exists())
            self.assertTrue((out / "total_market_pipeline_summary_20260925.json").exists())
            self.assertEqual(result["counts"]["raw_total_market_found"], 1)
            self.assertEqual(result["counts"]["events_discovered"], 2)

    def test_dashboard_has_total_views_and_pipeline_labels(self):
        self.assertIn("TOTAL_MARKET_FOUND", HTML)
        self.assertIn("TOTAL_PRICEABLE", HTML)
        self.assertIn("TOTAL_EDGE", HTML)
        self.assertIn("总分盘口全链路审计", HTML)
        self.assertIn("盘口链路", HTML)


if __name__ == "__main__":
    unittest.main()
