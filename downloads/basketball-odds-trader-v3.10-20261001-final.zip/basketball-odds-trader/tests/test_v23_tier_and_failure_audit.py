import json
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / 'scripts'
sys.path.insert(0, str(SCRIPTS))

from repair_v22.model import price_event, decide
from repair_v22.pipeline import failure_audit_settlements


TIP = '2026-09-20T12:00:00+00:00'
ASOF = '2026-09-20T09:00:00+00:00'


def event(league='NBA'):
    return {'event_id': '7m:target', 'team1_id': 'A', 'team2_id': 'B', 'team1_name': 'A', 'team2_name': 'B',
            'competition_id': 'C', 'competition_key': league, 'gender': 'WOMEN' if league == 'WNBA' else 'MEN',
            'model_family': 'CLUB_MATURE', 'league': league, 'identity_verified': True,
            'tip_at': TIP, 'bj_date': '2026-09-20', 'game_minutes': 48}


def game(number, team1, team2):
    return {'event_id': 'g' + str(number), 'team1_id': team1, 'team2_id': team2, 'competition_id': 'C',
            'competition_key': 'NBA', 'gender': 'MEN', 'status': 'FINAL',
            'tip_at': '2026-09-%02dT00:00:00+00:00' % number,
            'known_final_at': '2026-09-%02dT03:00:00+00:00' % number,
            'score1_full': 80 + number, 'score2_full': 70, 'score1_regulation': 80 + number,
            'score2_regulation': 70, 'evidence_kind': 'TEAM_HISTORY'}


def history():
    return [game(1, 'A', 'C'), game(2, 'B', 'D'), game(3, 'A', 'D'), game(4, 'B', 'C'),
            game(5, 'A', 'E'), game(6, 'B', 'E'), game(7, 'C', 'D'), game(8, 'D', 'E')]


class TierPolicyTests(unittest.TestCase):
    def test_unknown_league_is_tier3_and_cannot_be_paper_eligible_without_roster_stability(self):
        p = price_event(event('丹甲'), history(), ASOF, 'FORWARD_NATIVE', {})
        self.assertEqual(p['league_tier'], 'TIER_3')
        self.assertAlmostEqual(p['scenarios']['INCLUDING_OT']['residual_scale_multiplier'], 1.45)
        self.assertFalse(p['paper_model_eligible'])
        self.assertIn('ROSTER_STABILITY_MISSING', p['blockers'])

    def test_wnba_remains_tier1(self):
        e = event('WNBA'); e['competition_key'] = 'C'
        h = [dict(row, gender='WOMEN', competition_key='C') for row in history()]
        p = price_event(e, h, ASOF, 'FORWARD_NATIVE', {'roster_verified': True})
        self.assertEqual(p['league_tier'], 'TIER_1')
        self.assertEqual(p['evaluation_channel'], 'WNBA_ONLY')
        self.assertAlmostEqual(p['scenarios']['INCLUDING_OT']['residual_scale_multiplier'], 1.0)

    def test_nba_spread_requires_advanced_context(self):
        p = price_event(event('NBA'), history(), ASOF, 'FORWARD_NATIVE', {'roster_verified': True})
        self.assertFalse(p['spread_execution_eligible'])
        self.assertIn('SPREAD_CONTEXT_INCOMPLETE', p['blockers'])


class FailureAuditTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def write(self, path, value):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value), encoding='utf-8')

    def test_q4_cover_failure_requires_quantified_period_evidence(self):
        event_data = event('NBA')
        selected = {'market_type': 'SPREAD', 'selection': 'TEAM1', 'line': -9.5, 'ot_rule': 'INCLUDING_OT'}
        folder = self.root / 'ledger' / 'repair_v22' / 'run'
        self.write(folder / 'decision_p1.json', {'prediction_id': 'p1', 'event_id': '7m:target', 'selected': selected,
                                                  'forecast_fingerprint': 'frozen', 'triggered': True})
        self.write(folder / 'input_p1.json', {'event': event_data})
        self.write(folder / 'forecast_p1.json', {})
        self.write(self.root / 'ledger' / 'repair_v22_settlements' / 'p1.json',
                   {'prediction_id': 'p1', 'event_id': '7m:target', 'outcome': 'LOSS'})
        fact = {'event_id': '7m:target', 'team1_id': 'A', 'team2_id': 'B', 'status': 'FINAL',
                'period_points_team1': [25, 25, 25, 15], 'period_points_team2': [20, 20, 20, 32],
                'raw_path': 'raw/final.json', 'raw_sha256': 'x'}
        result = failure_audit_settlements(self.root, [fact], ASOF)
        row = result['records'][0]
        self.assertEqual(row['failure_label'], 'GARBAGE_TIME_COVER')
        self.assertTrue(row['audit_passed'])
        self.assertEqual(row['hard_evidence']['metric_value'], -17)

    def test_missing_total_detail_is_explicitly_unknown(self):
        event_data = event('NBA')
        selected = {'market_type': 'TOTAL', 'selection': 'OVER', 'line': 150.5, 'ot_rule': 'INCLUDING_OT'}
        folder = self.root / 'ledger' / 'repair_v22' / 'run'
        self.write(folder / 'decision_p2.json', {'prediction_id': 'p2', 'event_id': '7m:target', 'selected': selected,
                                                  'forecast_fingerprint': 'frozen', 'triggered': True})
        self.write(folder / 'input_p2.json', {'event': event_data})
        self.write(self.root / 'ledger' / 'repair_v22_settlements' / 'p2.json',
                   {'prediction_id': 'p2', 'event_id': '7m:target', 'outcome': 'LOSS'})
        fact = {'event_id': '7m:target', 'team1_id': 'A', 'team2_id': 'B', 'status': 'FINAL',
                'raw_path': 'raw/final.json', 'raw_sha256': 'x'}
        result = failure_audit_settlements(self.root, [fact], ASOF)
        row = result['records'][0]
        self.assertEqual(row['failure_label'], 'CAUSE_UNKNOWN_INSUFFICIENT_DATA')
        self.assertFalse(row['audit_passed'])
        self.assertIn('REGULATION_FINAL_120_SECONDS_SCORING_MISSING', row['missing_evidence'])


class MarketIntegrityTests(unittest.TestCase):
    def test_divergent_fresh_main_quote_cannot_create_paper_entry(self):
        target = event('WNBA')
        target['competition_key'] = 'C'
        target['tip_at'] = '2026-09-20T12:00:00+00:00'
        forecast = {
            'pricing_status': 'PRICED_LOW_CONFIDENCE', 'paper_model_eligible': True,
            'spread_execution_eligible': True, 'total_execution_eligible': False, 'blockers': [],
            'scenarios': {'INCLUDING_OT': {'mu_margin': 8.0, 'mu_total': 160.0, 'sd_margin': 13.0, 'sd_total': 18.0, 'df': 7}},
        }
        def quote(identifier, bookmaker, line):
            return {
                'quote_id': identifier, 'bookmaker': bookmaker, 'bookmaker_id': bookmaker,
                'event_id': target['event_id'], 'market_type': 'SPREAD', 'line_team1': line,
                'raw_line': abs(line), 'decimal_prices': [1.91, 1.91], 'period': 'FULL_GAME',
                'ot_rule': 'INCLUDING_OT', 'rule_evidence': 'fixture', 'raw_verified': True,
                'received_at': ASOF, 'source_quote_at': ASOF, 'source_timestamp_semantics': 'LAST_CHANGE',
                'price_format_verified': True, 'direction_verified': True, 'main_or_alt': 'MAIN', 'status': 'OPEN',
            }
        result = decide(target, forecast, [quote('a', 'A', -4.5), quote('b', 'B', -4.5), quote('c', 'C', -20.0)], ASOF, 'FORWARD_NATIVE')
        self.assertIn('PROVIDER_DISAGREEMENT', result['blockers'])
        self.assertFalse(result['triggered'])
        self.assertTrue(result['market_integrity']['c']['outlier'])


if __name__ == '__main__':
    unittest.main()
