import sys
import tempfile
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / 'scripts'
sys.path.insert(0, str(SCRIPTS))

from repair_v22.pricing_funnel_diagnostic import diagnose_market, build_pricing_funnel_diagnostic


def base_row():
    event = {
        'event_id': '7m:diag', 'canonical_event_id': '7m:diag',
        'identity_verified': True, 'team1_id': 'A', 'team2_id': 'B',
        'team1_name': 'A', 'team2_name': 'B', 'league': 'WNBA',
        'league_family': 'WNBA', 'region': '北美', 'game_minutes': 40,
        'game_minutes_source': 'LEAGUE_RULE_PRIOR',
        'tip_time_bj': '2026-09-24T20:00:00+08:00',
    }
    pricing = {
        'pricing_status': 'PRICED_LOW_CONFIDENCE', 'model_family': 'CLUB_MATURE',
        'league_tier': 'TIER_1', 'input_games': 8,
        'team_game_counts': {'A': 8, 'B': 8}, 'mu_raw': 4.5, 'total_raw': 159.0,
        'pricing_data_quality': 72, 'blockers': [], 'total_diagnostic': {
            'hard_blockers': [], 'soft_missing': ['THREE_POINT_PROFILE_UNKNOWN'],
        },
    }
    q = {
        'quote_id': 'q1', 'market_type': 'SPREAD', 'raw_line': 4.5,
    }
    decision = {
        'blockers': [], 'comparison_ready': True, 'model_state': 'EDGE',
        'ev': 0.04, 'triggered': True,
        'market_decisions': {
            'SPREAD': {'blockers': [], 'comparison_ready': True, 'model_state': 'EDGE',
                       'ev': 0.04, 'triggered': True, 'selected': {'line': -4.5, 'ev': 0.04}},
            'TOTAL': {'blockers': [], 'comparison_ready': False, 'model_state': 'UNASSESSED',
                      'ev': None, 'triggered': False},
        },
    }
    return {'id': '7m:diag', 'archive_type': 'FORWARD_NATIVE', 'event': event,
            'pricing': pricing, 'market': {'quotes': [q], 'quote_states': [{'raw_observation': True, 'fresh_observation': True}]},
            'execution': decision}


class PricingFunnelDiagnosticTests(unittest.TestCase):
    def test_one_primary_blocker_and_secondary_warnings(self):
        row = base_row()
        row['market']['quotes'] = []
        row['pricing']['blockers'] = ['INSUFFICIENT_PRE_CUTOFF_HISTORY', 'INJURY_UNKNOWN']
        result = diagnose_market(row, 'SPREAD')
        self.assertEqual(result['primary_block_reason'], 'NO_MARKET')
        self.assertEqual(result['status'], 'NOT_PRICEABLE')
        self.assertIsInstance(result['secondary_warnings'], list)

    def test_spread_priceable_total_blocked_are_separate(self):
        row = base_row()
        row['market']['quotes'].append({'quote_id': 'q2', 'market_type': 'TOTAL', 'raw_line': 158.5})
        row['market']['quote_states'].append({'raw_observation': True, 'fresh_observation': True})
        row['pricing']['total_diagnostic']['hard_blockers'] = ['POSSESSIONS_EVIDENCE_MISSING']
        row['execution']['market_decisions']['TOTAL']['blockers'] = ['TOTAL_CONTEXT_INCOMPLETE']
        spread = diagnose_market(row, 'SPREAD')
        total = diagnose_market(row, 'TOTAL')
        self.assertTrue(spread['priceable'])
        self.assertFalse(total['priceable'])
        self.assertEqual(total['primary_block_reason'], 'PACE_MODEL_UNAVAILABLE')

    def test_missing_values_are_not_converted_to_zero(self):
        row = base_row()
        row['pricing']['mu_raw'] = None
        row['pricing']['total_raw'] = None
        row['pricing']['input_games'] = 0
        result = diagnose_market(row, 'SPREAD')
        self.assertIsNone(result['fair_value'])
        self.assertEqual(result['market_value'], -4.5)
        self.assertNotEqual(result['fair_value'], 0)

    def test_hard_and_soft_total_missing_are_distinct(self):
        row = base_row()
        row['market']['quotes'].append({'quote_id': 'q2', 'market_type': 'TOTAL', 'raw_line': 158.5})
        row['market']['quote_states'].append({'raw_observation': True, 'fresh_observation': True})
        row['pricing']['total_diagnostic'] = {
            'hard_blockers': ['POSSESSIONS_EVIDENCE_MISSING'],
            'soft_missing': ['ROTATION_UNKNOWN'],
        }
        result = diagnose_market(row, 'TOTAL')
        self.assertEqual(result['primary_block_reason'], 'PACE_MODEL_UNAVAILABLE')
        self.assertIn('ROTATION_UNKNOWN', result['secondary_warnings'])

    def test_summary_persists_json_csv_and_markdown(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = build_pricing_funnel_diagnostic([base_row()], Path(tmp), '2026-09-24', '2026-09-24T12:00:00+08:00')
            out = Path(tmp) / 'diagnostics'
            self.assertTrue((out / 'pricing_funnel_20260924.csv').exists())
            self.assertTrue((out / 'pricing_funnel_summary_20260924.json').exists())
            self.assertTrue((out / 'pricing_funnel_summary_20260924.md').exists())
            self.assertEqual(result['markets']['SPREAD']['shadow_triggered'], 1)

    def test_terminal_accounting_and_stale_market_are_separate(self):
        row = base_row()
        row['market']['quote_states'] = [{'raw_observation': True, 'fresh_observation': False}]
        result = build_pricing_funnel_diagnostic([row], Path(tempfile.mkdtemp()), '2026-09-24', '2026-09-24T12:00:00+08:00')
        spread = result['markets']['SPREAD']
        self.assertEqual(spread['stale_market'], 1)
        self.assertEqual(spread['no_market'], 0)
        self.assertEqual(spread['terminal_accounting_expected'], 1)
        self.assertEqual(spread['terminal_accounting_actual'], 1)
        self.assertEqual(result['terminal_accounting_status'], 'OK')

    def test_no_market_is_not_not_priceable(self):
        row = base_row()
        row['market'] = {'quotes': [], 'quote_states': []}
        result = build_pricing_funnel_diagnostic([row], Path(tempfile.mkdtemp()), '2026-09-24', '2026-09-24T12:00:00+08:00')
        self.assertEqual(result['markets']['SPREAD']['no_market'], 1)
        self.assertEqual(result['markets']['SPREAD']['market_found_but_not_priceable'], 0)


if __name__ == '__main__':
    unittest.main()
