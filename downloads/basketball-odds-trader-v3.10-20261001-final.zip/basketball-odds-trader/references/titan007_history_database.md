# Titan007 历史基础库

需要补充球队历史、阵容或 Box Score 时使用本参考。

## 数据链

1. 球队搜索：`/cn/aspx/Search_Team.aspx?str1=<球队名>`，解析联赛、简体/繁体/英文别名与 TeamID；只接受规范化后唯一精确别名匹配。站内联想接口返回空响应时不得据此判定球队不存在。
2. 球队身份与当前阵容：`/jsData/teamInfo/teamDetail/td<TeamID>.js`。
3. 按年赛程：`/cn/Team/TeamScheAjax.aspx?TeamID=<TeamID>&y=<YYYY>`。
4. 分节比分：`/cn/Tech/TechTxtLive.aspx?matchid=<MatchID>`。
5. Box Score：`/jsData/tech/<首位>/<第2-3位>/<MatchID>.js`。

正常 HTTP 使用 `curl_cffi` 的 Chrome 兼容握手，因为该站点会中断普通客户端连接；这不是验证码、登录、付费墙或访问控制绕过。最多 6 线程、有限超时、最多一次重试。

## 存储与隔离

- 数据库：`D:\codex\outputs\basketball_odds_trader\reference_data\titan007_history\titan007_history.sqlite`
- 原文：同目录 `raw\YYYYMMDD\`，以响应哈希命名且不可变。
- 最新审计：`latest_audit.json`。
- 球队身份、阵容、赛程、分节比分和 Box Score 属于事实库。
- `letGoal`、`bigSmall`、HandicapDetail、OuHandicapDetail 属于市场历史，只能进入独立市场审计；禁止作为独立公平价模型输入。
- 本库没有 PnL、ROI、CLV 或正式/Provisional 账本表，不能写入或重算既有首写记录。

## 更新策略

首次对当前比赛池运行两年回填；以后只对当天赛事球队增量刷新，并对每队最近 10 场已完赛比赛抓取分节与 Box Score。所有事实仍必须通过 `alias -> competition -> cutoff -> valid -> usable`；数据库存在不等于可用。

Level B Pace 只在同场双方都有数值型 `FGA/FTA/ORB/TOV` 时计算：`FGA + 0.44 × FTA - ORB + TOV`。任何字段缺失时降级，不抛异常。
