"""Immutable pregame evidence archive utilities."""
