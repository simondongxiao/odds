"""A due checkpoint really runs capture/pricing; writing checkpoint names is not execution."""
from repair_v22.cli import checkpoint_main
if __name__=='__main__':raise SystemExit(checkpoint_main())
