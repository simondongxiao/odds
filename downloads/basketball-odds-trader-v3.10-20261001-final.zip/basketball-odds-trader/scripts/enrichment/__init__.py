"""Explicit, timestamped pricing input enrichment. No discovery or HTML parsing."""
