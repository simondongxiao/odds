"""Step 3 pricing components. No discovery, execution, or staking lives here."""
