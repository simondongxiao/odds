"""Shadow-only market microstructure components."""
