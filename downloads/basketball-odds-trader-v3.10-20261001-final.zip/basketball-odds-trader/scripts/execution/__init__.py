"""Shadow execution gate only; real execution is permanently disabled."""
