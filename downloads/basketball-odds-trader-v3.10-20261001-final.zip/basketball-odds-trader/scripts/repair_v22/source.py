from __future__ import annotations
import json, re, urllib.request, urllib.error, uuid, math
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta, date
from pathlib import Path
from urllib.parse import urljoin, urlparse
from .common import *
from global_discovery import discover as discover_global, merge_with_primary, classify as classify_global
from odds_discovery import route as route_odds
from providers.titan007_adapter import parse_schedule_xml as parse_titan_schedule_xml, parse_odds_xml as parse_titan_odds_xml
from providers.titan007_history_adapter import update_history_database, merge_reference_history

# These five selector mappings are evidenced in the supplied source audit.
COMPANIES={'0':('澳','0'),'1':('S2','4'),'2':('易','2'),'3':('12','3'),'4':('威','1')}
ALLOWED_HOSTS={'basket.7m.com.cn','js-basket.7m.com.cn','bdata.7m.com.cn','bdata-js.7m.com.cn','bodds.7m.com.cn','lq.7m.com.cn','lq3.titan007.com'}

def _canonical_team_token(value):
    # Titan's board appends live ranking markers such as ``[8]`` while the
    # 7M identity endpoint does not.  Only remove display-only markers; never
    # use fuzzy edit distance to force two different teams together.
    text=re.sub(r'\[[^\]]*\]|【[^】]*】', '', str(value or ''))
    text=text.replace('(中)','').replace('（中）','')
    return re.sub(r'[^\w\u4e00-\u9fff]+','',text.casefold())

def reconcile_titan_events(events, titan_events, quotes, tolerance_minutes=45):
    """Canonicalize Titan schedule/quotes onto an unambiguous 7M event.

    Titan and 7M expose different source event IDs for the same fixture.  The
    merge is allowed only when the unordered normalized team pair and start
    time agree and the candidate is unique.  Ambiguous/unmatched rows remain
    separate and are reported; no quote is silently discarded.
    """
    primary=[e for e in events.values() if str(e.get('source')).upper()!='TITAN007']
    mapping={};matched=[];ambiguous=[];unmatched=[]
    for te in titan_events:
        original_id=te.get('event_id')
        if original_id in events and str(events[original_id].get('source')).upper()!='TITAN007':
            candidates=[events[original_id]];method='SHARED_SOURCE_EVENT_ID'
        else:
            tt=source_time(te.get('tip_at'))
            names={_canonical_team_token(te.get('team1_name')),_canonical_team_token(te.get('team2_name'))}
            candidates=[]
            for pe in primary:
                pt=source_time(pe.get('tip_at'))
                pnames={_canonical_team_token(pe.get('team1_name')),_canonical_team_token(pe.get('team2_name'))}
                if tt and pt and names and names==pnames and abs((tt-pt).total_seconds())<=tolerance_minutes*60:
                    candidates.append(pe)
            method='TEAM_PAIR_AND_TIP_TIME'
        if len(candidates)==1:
            canonical=candidates[0];canonical_id=canonical['event_id'];mapping[original_id]=canonical_id
            canonical.setdefault('discovery_sources',[]).append({
                'source':'TITAN007','source_url':te.get('source_url'),
                'source_event_url':te.get('source_event_url'),'source_event_id':te.get('source_event_id'),
                'match_method':method})
            canonical.setdefault('titan007_source_event_ids',[]).append(te.get('source_event_id'))
            canonical['titan007_event']=te
            if original_id!=canonical_id and events.get(original_id) is te:
                events.pop(original_id,None)
            matched.append({'titan_event_id':original_id,'canonical_event_id':canonical_id,'method':method})
        elif len(candidates)>1:
            ambiguous.append({'titan_event_id':original_id,'candidate_event_ids':[x.get('event_id') for x in candidates]})
        else:
            unmatched.append(original_id)
    for q in quotes:
        old=q.get('event_id')
        if old in mapping:
            q['source_event_id_titan']=q.get('source_event_id')
            q['source_event_id_original']=q.get('source_event_id')
            q['source_event_id_canonical']=events[mapping[old]].get('source_event_id')
            q['original_event_id']=old
            q['event_id']=mapping[old]
            q['canonical_event_id']=mapping[old]
            q['event_match_method']='TITAN_TEAM_PAIR_AND_TIP_TIME'
    return {'matched':matched,'ambiguous':ambiguous,'unmatched_event_ids':unmatched,
            'matched_count':len(matched),'ambiguous_count':len(ambiguous),'unmatched_count':len(unmatched)}

def game_minutes_for(league):
    """A diagnostic league-rule label, deliberately not a pricing feature."""
    text=str(league or '')
    rules=load(Path(__file__).resolve().parents[2]/'config'/'game_rule_registry.json',{}).get('rules',[])
    for rule in rules:
        if str(rule.get('match','')).casefold() in text.casefold():
            return rule.get('minutes'),rule.get('source','LEAGUE_RULE_PRIOR')
    fallback=load(Path(__file__).resolve().parents[2]/'config'/'game_rule_registry.json',{}).get('fallback',{})
    return fallback.get('minutes'),fallback.get('source','UNKNOWN_NO_MINUTES_ASSUMED')

class Fetcher:
    """Bounded, independent public requests; no stale-cache success or challenge bypass."""
    def __init__(self,directory,timeout=12,workers=4):
        self.directory=Path(directory);self.directory.mkdir(parents=True,exist_ok=True)
        self.timeout=timeout;self.workers=workers;self.rows=[]
    def one(self,kv):
        key,url=kv; started=stamp(); meta={'key':key,'url':url,'started_at':started,'ok':False}
        try:
            if urlparse(url).hostname not in ALLOWED_HOSTS:raise ValueError('host not permitted')
            host=urlparse(url).hostname
            referer='https://lq3.titan007.com/nba.htm' if host=='lq3.titan007.com' else 'https://basket.7m.com.cn/free_gb.aspx'
            request=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0','Referer':referer,'Accept':'application/xml,text/xml,*/*'})
            with urllib.request.urlopen(request,timeout=self.timeout) as response:
                if urlparse(response.geturl()).hostname not in ALLOWED_HOSTS:raise ValueError('unexpected redirect host')
                blob=response.read(8_000_001)
                if len(blob)>8_000_000:raise ValueError('response too large')
                if response.status!=200:raise ValueError('HTTP '+str(response.status))
                meta.update(http_status=response.status,response_date=response.headers.get('Date'),last_modified=response.headers.get('Last-Modified'),age_header=response.headers.get('Age'))
            p=self.directory/(safe_id(key)+'.raw');p.write_bytes(blob)
            meta.update(ok=True,path=str(p),sha256=sha(blob),bytes=len(blob),received_at=stamp())
        except Exception as e:meta.update(error_type=type(e).__name__,error=str(e),received_at=stamp())
        return meta
    def batch(self,urls):
        with ThreadPoolExecutor(max_workers=self.workers) as pool:rows=list(pool.map(self.one,urls.items()))
        self.rows.extend(rows);atomic(self.directory/'http_manifest.json',self.rows)
        return {r['key']:r for r in rows}

def text_of(row): return decode(Path(row['path']).read_bytes()) if row and row.get('ok') else ''

def family(league):
    if any(x in league for x in ('友谊','夏季','热身','青年','U18','U16','U19','U20','杯赛','德国杯','季前')):return 'HIGH_UNCERTAINTY'
    if any(x in league for x in ('世界女子','世界男子','世界杯','世锦赛','亚运','亚洲运动','欧洲国家','亚洲杯','非洲杯','国家队','欧国杯','美洲杯','奥运')):return 'NATIONAL_TEAM'
    return 'CLUB_MATURE'

def gender(name):return 'WOMEN' if any(t in name for t in ('女','Women','women','WNBA')) else 'MEN'

def parse_identity(text,source_id,source_path=None,observed_at=None,timezone_verified=True):
    a=assignments(text)
    required=('a_tm','a_mn','a_hn','a_an','a_hid','a_aid','a_mid')
    if not all(a.get(k) is not None for k in required):raise ValueError('identity fields missing')
    tip=source_time(a['a_tm']) if timezone_verified else None
    if tip is None:raise ValueError('SOURCE_TIME_UNVERIFIED')
    eid='7m:'+str(source_id)
    event_gender=gender(a['a_mn']+a['a_hn']+a['a_an'])
    minutes,minutes_source=game_minutes_for(a['a_mn'])
    return {'event_id':eid,'canonical_event_id':eid,'source_event_id':str(source_id),'source':'7M',
      'team1_id':'7m-team:'+str(a['a_hid']),'team2_id':'7m-team:'+str(a['a_aid']),
      'team1_name':a['a_hn'].replace('中国台湾','中国台北'),'team2_name':a['a_an'].replace('中国台湾','中国台北'),
      'team1_source_id':str(a['a_hid']),'team2_source_id':str(a['a_aid']),
      'competition_id':'7m-comp:'+str(a['a_mid']),'competition_key':competition_key(a['a_mn'],event_gender),
      'league':a['a_mn'],'model_family':family(a['a_mn']),
      'gender':event_gender,'age_group':'SENIOR' if family(a['a_mn'])!='HIGH_UNCERTAINTY' else 'UNVERIFIED',
      'format_id':'BASKETBALL','tip_at':stamp(tip),'tip_time_utc':stamp(tip),'tip_time_bj':tip.astimezone(BJ).isoformat(),
      'bj_date':tip.astimezone(BJ).date().isoformat(),'source_time_raw':a['a_tm'],'source_timezone':'Asia/Shanghai',
      'time_basis':'7M page declares GMT+0800 unless otherwise labelled',
      'identity_verified':True,'source_url':f'https://bdata.7m.com.cn/analyse/gb/{source_id}.shtml',
      'identity_raw_path':str(source_path) if source_path else None,'observed_at':observed_at,'venue_status':'UNKNOWN',
      'home_sign':0,'home_adjustment_assumption':'NEUTRAL_UNLESS_VERIFIED',
      'game_minutes':minutes,'game_minutes_source':minutes_source,'game_minutes_used_in_pricing':False}

def parse_schedule(text,path,observed_at):
    out=[];fail=[]
    for key,r in assignments(text).items():
        m=re.fullmatch(r'bDt\[(\d+)\]',key)
        if not m or not isinstance(r,list) or len(r)<9:continue
        try:
            # 7M live bDt row: state, time, league id/name/color, team1 id/name, team2 id/name.
            tip=source_time(r[1]);sid=m.group(1)
            if tip is None or not isinstance(r[6],str) or not isinstance(r[8],str):raise ValueError('schedule schema')
            league=r[3]
            event_gender=gender(league+r[6]+r[8])
            minutes,minutes_source=game_minutes_for(league)
            out.append({'event_id':'7m:'+sid,'canonical_event_id':'7m:'+sid,'source_event_id':sid,'source':'7M',
              'team1_id':'7m-team:'+str(r[5]),'team2_id':'7m-team:'+str(r[7]),'team1_source_id':str(r[5]),'team2_source_id':str(r[7]),
              'team1_name':r[6].replace('中国台湾','中国台北'),'team2_name':r[8].replace('中国台湾','中国台北'),
              'competition_id':'7m-comp:'+str(r[2]),'competition_key':competition_key(league,event_gender),
              'league':league,'model_family':family(league),'gender':event_gender,
              'age_group':'UNVERIFIED' if family(league)=='HIGH_UNCERTAINTY' else 'SENIOR','format_id':'BASKETBALL',
              'tip_at':stamp(tip),'tip_time_utc':stamp(tip),'tip_time_bj':tip.astimezone(BJ).isoformat(),'bj_date':tip.astimezone(BJ).date().isoformat(),
              'source_time_raw':r[1],'source_timezone':'Asia/Shanghai','identity_verified':True,'source_status':r[0],
              'source_url':'https://basket.7m.com.cn/free_gb.aspx','identity_raw_path':str(path),'observed_at':observed_at,
              'home_sign':0,'home_adjustment_assumption':'NEUTRAL_UNLESS_VERIFIED','venue_status':'UNKNOWN',
              'game_minutes':minutes,'game_minutes_source':minutes_source,'game_minutes_used_in_pricing':False})
        except (TypeError,ValueError,IndexError) as e:fail.append({'id':m.group(1),'error':str(e)})
    return out,fail

def rows_in(value):
    if isinstance(value,list):
        # a_wf detail rows have 25 fields; n_history.js t_history rows have 24.
        if len(value)>=24 and isinstance(value[2],str) and re.fullmatch(r'\d{4}(?:,\d{1,2}){5}',value[2]):yield value
        else:
            for v in value:yield from rows_in(v)
    elif isinstance(value,dict):
        for v in value.values():yield from rows_in(v)

def parse_history(text,path,observed_at,source_url,kind='TEAM_HISTORY'):
    result={};errors=[];hash_=sha(Path(path).read_bytes()) if Path(path).exists() else sha(text.encode())
    data=assignments(text)
    for name,v in data.items():
        # Whitelist data arrays, not handicap histories / predictions / tips.
        if re.search(r'(odds|handicap|ats|pred)',name,re.I):continue
        trusted_history_endpoint=(kind=='TEAM_HISTORY' and urlparse(source_url).path.endswith('/gb/n_history.js'))
        if name!='a_wf' and not trusted_history_endpoint and not re.search(r'(history|match|game)',name,re.I):continue
        for r in rows_in(v):
            try:
                if r[1] not in (9,11):continue # source final / final after overtime codes
                tip=source_time(r[2])
                if not tip:continue
                # Detail a_wf and team n_history.js are different public schemas.
                # a_wf: comp id/name at 3/4, teams at 7..10, periods at 11..20.
                # t_history: comp label at 3, teams at 5..8, periods at 9..18.
                is_team_row=(len(r)>=24 and isinstance(r[3],str) and isinstance(r[5],(int,float)) and isinstance(r[6],str))
                if is_team_row:
                    league=r[3];comp_id=None;team1_id=r[5];team1_name=r[6];team2_id=r[7];team2_name=r[8]
                    scores=r[9:19];period_count=r[21] if len(r)>21 else None
                    half_summaries=()
                    schema='N_HISTORY_24'
                else:
                    if len(r)<25:raise ValueError('unsupported history row schema')
                    comp_id='7m-comp:'+str(r[3]);league=r[4];team1_id=r[7];team2_id=r[8];team1_name=r[9];team2_name=r[10]
                    scores=r[11:21];period_count=r[5];half_summaries=((r[21],None),(r[22],None));schema='A_WF_25'
                if len(scores)!=10 or any(isinstance(x,bool) or not isinstance(x,(int,float)) or x<0 or int(x)!=x for x in scores):raise ValueError('invalid period scores')
                hq=list(map(int,scores[:5]));aq=list(map(int,scores[5:]));s1=sum(hq);s2=sum(aq)
                if s1+s2==0:raise ValueError('empty final score')
                # Final score sums must agree with the source half-score summaries when present.
                for chunks,expected in ((x,s1 if i==0 else s2) for i,(x,_) in enumerate(half_summaries)):
                    if isinstance(chunks,str) and re.fullmatch(r'\d+/\d+',chunks) and sum(map(int,chunks.split('/')))!=expected:
                        raise ValueError('quarter/half score mismatch')
                row_gender=gender(league+team1_name+team2_name)
                ev='7m:'+str(r[0]); result[ev]={'event_id':ev,'source_event_id':str(r[0]),'tip_at':stamp(tip),'status':'FINAL',
                   'competition_id':comp_id,'competition_key':competition_key(league,row_gender),'competition_identity_level':'SOURCE_ID' if comp_id else 'CANONICAL_SOURCE_LABEL',
                   'league':league,'team1_id':'7m-team:'+str(team1_id),'team2_id':'7m-team:'+str(team2_id),
                   'team1_name':team1_name.replace('(中)','').replace('中国台湾','中国台北'),'team2_name':team2_name.replace('(中)','').replace('中国台湾','中国台北'),
                   'gender':row_gender,'format_id':'BASKETBALL','period_count':period_count,
                   # Preserve source quarter scoring so late-game diagnostics never
                   # have to reconstruct it from final scores.
                   'period_points_team1':hq,'period_points_team2':aq,
                   'score1_regulation':sum(hq[:4]),'score2_regulation':sum(aq[:4]),'score1_full':s1,'score2_full':s2,
                   'ot_points1':hq[4],'ot_points2':aq[4],'score_basis':'PERIOD_SUM','known_final_at':observed_at,
                   'evidence_kind':kind,'source_url':source_url,'raw_path':str(path),'raw_sha256':hash_,
                    'source_variable':name,'source_schema':schema,'source_status':r[1],'home_sign':0,'home_adjustment_assumption':'UNVERIFIED_NO_HOME_ADJUSTMENT'}
            except (ValueError,TypeError,IndexError) as e:errors.append({'row_id':str(r[0]) if r else None,'error':str(e)})
    return list(result.values()),errors

def discover_links(html,event):
    """Only follow the team-history template actually present in the downloaded page."""
    if '/Basketball_Team_Data/' not in html or '/gb/n_history.js' not in html:return {}
    return {str(t):f'https://bdata.7m.com.cn/Basketball_Team_Data/{t}/gb/n_history.js' for t in (event['team1_source_id'],event['team2_source_id'])}

def parse_total_context(text, path, received_at, source_url):
    """Retain 7M pregame aggregates without guessing undocumented meanings."""
    data=assignments(text)
    known={k:data[k] for k in ('avgWLPoint','teamStanding','pointStat','totalStat','bqcStat','teamStats') if k in data}
    stats=data.get('teamStats') if isinstance(data.get('teamStats'),dict) else None
    stats_profile={}
    if stats:
        fields=('fg_pct','three_pct','ft_pct','rebounds','assists','fouls','steals','turnovers','blocks','points')
        for side in ('A','B'):
            payload=stats.get(side) if isinstance(stats.get(side),dict) else {}
            stats_profile[side]={}
            for window in ('last5','last10','season'):
                values=payload.get(window)
                if not isinstance(values,list) or len(values)!=len(fields):continue
                try:stats_profile[side][window]={k:float(v) for k,v in zip(fields,values)}
                except (TypeError,ValueError):continue
    basic_offense_verified=bool(all((stats_profile.get(side) or {}).get('last5') or (stats_profile.get(side) or {}).get('last10') for side in ('A','B')))
    three_point_verified=bool(basic_offense_verified and all(any('three_pct' in row for row in (stats_profile.get(side) or {}).values()) for side in ('A','B')))
    return {'source_url':source_url,'raw_path':str(path),'raw_sha256':sha(Path(path).read_bytes()) if Path(path).exists() else sha(text.encode()),
            'captured_at':received_at,'available_variables':sorted(known),'source_aggregates':known,
            'possessions_per_game':None,'possessions_verified':False,
            'basic_offense_profile':stats_profile or None,'basic_offense_verified':basic_offense_verified,
            'three_point_profile':stats_profile or None,'three_point_verified':three_point_verified,
            'late_foul_profile':None,'late_foul_verified':False,
            'rotation_change':None,'rotation_verified':False,
            'schema_note':'7M aggregate arrays retained as raw evidence; unavailable fields are not inferred from score totals.'}

def parse_odds(text,path,received_at,company_selector,contracts):
    out=[];errors=[];selector_name,expected_namespace=COMPANIES[str(company_selector)]
    raw_sha=sha(Path(path).read_bytes()) if Path(path).exists() else sha(text.encode())
    contract=contracts.get('companies',{}).get(expected_namespace,{})
    for k,v in assignments(text).items():
        m=re.fullmatch(r'bOdds\[(\d+)\]\[(\d+)\]',k)
        if not m or not isinstance(v,dict):continue
        ns,sid=m.groups()
        if ns!=expected_namespace:errors.append({'id':sid,'error':'COMPANY_NAMESPACE_MISMATCH'});continue
        for raw_market,market in [('HB','SPREAD'),('TP','TOTAL')]:
            markets=v.get(raw_market)
            if not isinstance(markets,dict):continue
            for raw_key,a in markets.items():
                if not isinstance(a,list) or len(a)<4:
                    errors.append({'id':sid,'market_type':market,'raw_market':raw_market,'error':'ODDS_ARRAY_SCHEMA','loss_stage':market+'_PARSER_LOSS'});continue
                try:
                    p1,p2=float(a[0]),float(a[1]);line=float(a[3]);qt=source_time(a[2])
                    if not all(math.isfinite(x) for x in (p1,p2,line)):raise ValueError('nonfinite odds')
                except (ValueError,TypeError):
                    errors.append({'id':sid,'market_type':market,'raw_market':raw_market,'error':'INVALID_ODDS_VALUE','loss_stage':market+'_PARSER_LOSS'});continue
                # The platform contract is evidenced once for all legal 7M namespaces.
                platform_evidence=contracts.get('platform_semantics_evidence') or contract.get('semantics_evidence')
                verified=bool(platform_evidence and contract.get('price_format')=='HK')
                direction_mode=contract.get('spread_line_basis')
                sh=None
                if verified and market=='SPREAD':
                    if direction_mode=='SIGNED_TEAM1_HANDICAP':sh=line
                    elif direction_mode=='POSITIVE_TEAM1_GIVES':sh=-line
                    elif direction_mode=='FLAG':
                        sh=contract.get('spread_flag_map',{}).get(str(a[4] if len(a)>4 else None))
                        sh=None if sh is None else float(sh)*abs(line)
                main_index=7 if market=='SPREAD' else 6
                is_main=a[main_index] if len(a)>main_index else None
                main_or_alt='MAIN' if str(is_main)=='1' else 'ALT' if str(is_main)=='0' else 'UNVERIFIED'
                raw={'quote_id':sha((ns+sid+raw_market+str(raw_key)+str(a)+received_at).encode())[:24],
                   'event_id':'7m:'+sid,'source_event_id':sid,'feed_provider':'7M','bookmaker_id':'7m-company:'+ns,
                   'bookmaker':selector_name,'selector_id':str(company_selector),'company_namespace':ns,'market_type':market,
                   'raw_market_key':raw_market,'parse_status':'PARSED_AND_NORMALIZED',
                   'period':'FULL_GAME','main_or_alt':main_or_alt,'source_market_key':str(raw_key),'source_main_flag':is_main,
                   'source_array':a,'raw_line':line,'line_team1':sh,'direction_verified':sh is not None if market=='SPREAD' else verified,
                   'raw_prices':[p1,p2],'decimal_prices':[p1+1,p2+1] if verified and min(p1,p2)>0 else None,
                   'price_format':contract.get('price_format','UNVERIFIED'),'price_format_verified':verified,
                   'source_quote_at':stamp(qt) if qt else None,'source_timestamp_raw':a[2],
                   'source_timestamp_semantics':contract.get('timestamp_semantics','UNKNOWN'),
                   'received_at':received_at,'observed_at':received_at,'raw_path':str(path),'raw_sha256':raw_sha,
                   'ot_rule':contract.get('overtime_rule','UNKNOWN'),'rule_evidence':contract.get('rule_evidence'),
                   'comparison_scope':contract.get('comparison_scope','OBSERVATION_ONLY'),
                   'current_board_contract_verified':bool(contract.get('current_board_contract_verified') and platform_evidence),
                   'status':'OBSERVED','raw_verified':Path(path).is_file(),'execution_verified':False}
                out.append(raw)
    return out,errors

def collect_live(output_root,day,contracts,timeout=12,workers=4):
    root=Path(output_root); sid=now().strftime('%Y%m%dT%H%M%S')+'_'+uuid.uuid4().hex[:10]
    session=root/'raw'/'repair_v22'/sid;fetch=Fetcher(session,timeout,workers)
    first=fetch.batch({'page':'https://basket.7m.com.cn/free_gb.aspx','today':'https://js-basket.7m.com.cn/datafile/today.js'})
    # Titan007's visible NBA board is a separate production-readable source.
    # Its XML endpoints require the same numeric cache-buster used by the page.
    titan_tick=str(int(now().timestamp()*1000))
    titan_urls={'titan_schedule':f'https://lq3.titan007.com/NBA/today2.xml?t={titan_tick}'}
    for company_id in ('1','2','3','8','9'):
        titan_urls[f'titan_odds_{company_id}']=f'https://lq3.titan007.com/NBA/nbaGoal{company_id}.xml?t={titan_tick}'
    titan_res=fetch.batch(titan_urls)
    d=date.fromisoformat(day);urls={}
    for n in (-1,0,1):
        bucket=(d+timedelta(days=n)).strftime('%Y%m%d')
        for variant in ('S2_fgb1','fgb1'):urls[f'event_{bucket}_{variant}']=f'https://bdata.7m.com.cn/datafile/{bucket}/{variant}.js'
    for sel,(name,ns) in COMPANIES.items():urls['odds_company_'+sel]=f'https://js-basket.7m.com.cn/odds/comlive_{ns}.js'
    responses=fetch.batch(urls);events={};quotes=[];errors=[]
    titan_events=[]
    for key,r in titan_res.items():
        if not r.get('ok'):
            continue
        try:
            if key=='titan_schedule':
                parsed,err=parse_titan_schedule_xml(text_of(r),day,r.get('path'),r.get('received_at'))
                titan_events.extend(parsed);errors+=err
            elif key.startswith('titan_odds_'):
                parsed,err=parse_titan_odds_xml(text_of(r),key.rsplit('_',1)[1],r.get('path'),r.get('received_at'))
                quotes.extend(parsed);errors+=err
        except Exception as exc:
            errors.append({'source':'titan007_nba','key':key,'path':r.get('path'),'error':type(exc).__name__+': '+str(exc)})
    # Keep the 7M identity when both sources expose the same source event, but
    # retain Titan's row and URL as an additional audited discovery source.
    for event in titan_events:
        old=events.get(event['event_id'])
        if old:
            old.setdefault('discovery_sources',[]).append({'source':'TITAN007','source_url':event.get('source_url'),'source_event_id':event.get('source_event_id')})
            old['titan007_event']=event
        else:
            events[event['event_id']]=event
    for meta in fetch.rows:
        if str(meta.get('key','')).startswith('titan_'):
            meta['source']='titan007_nba';meta['source_group']='odds_board_and_schedule'
    for key,r in responses.items():
        if not r['ok']:continue
        try:
            if key.startswith('event_'):
                evs,err=parse_schedule(text_of(r),r['path'],r['received_at']);events.update({e['event_id']:e for e in evs});errors+=err
            elif key.startswith('odds_company_'):
                qs,err=parse_odds(text_of(r),r['path'],r['received_at'],key.rsplit('_',1)[1],contracts);quotes+=qs;errors+=err
        except Exception as e:errors.append({'path':r['path'],'error':type(e).__name__+': '+str(e)})
    # Fetch detail/history for every discovered target-day event, including
    # Titan schedule rows that currently have no quote from a selected company.
    ids=sorted({e['source_event_id'] for e in events.values() if str(e.get('source')).upper()!='TITAN007'} |
               {q['source_event_id'] for q in quotes if q.get('feed_provider')!='TITAN007'})
    detail=fetch.batch({f'detail_{i}':f'https://bdata.7m.com.cn/analyse/gb/{i}.shtml' for i in ids})
    id_urls={};htmls={}
    for k,r in detail.items():
        if not r['ok']:continue
        i=k.split('_')[1];html=text_of(r);htmls[i]=html
        # Identity script must be linked in the page itself.
        match=re.search(r'''<script[^>]+src=["'](js/\d+/'''+re.escape(i)+r'''\.js)["']''',html,re.I)
        if match:id_urls['identity_'+i]=urljoin(r['url'],match.group(1))
    identities=fetch.batch(id_urls);history={};team_urls={};identity_rows=[];total_urls={};total_context={}
    for k,r in identities.items():
        if not r['ok']:continue
        i=k.split('_')[1]
        try:
            html=htmls[i];tv='GMT+0800' in html or 'GMT+08:00' in html
            e=parse_identity(text_of(r),i,r['path'],r['received_at'],tv)
            old=events.get(e['event_id'])
            if old and (old['team1_id'],old['team2_id'],old['tip_at'])!=(e['team1_id'],e['team2_id'],e['tip_at']):
                e['identity_verified']=False;e['identity_conflict']={'schedule':old,'detail':e.copy()}
            events[e['event_id']]=e;identity_rows.append(e)
            hs,err=parse_history(text_of(r),r['path'],r['received_at'],r['url'],'H2H');history.update({g['event_id']:g for g in hs});errors+=err
            if source_time(e['tip_at'])>now():
                team_urls.update(discover_links(html,e))
                for name in ('avgpoint','pointstat','totalstat','bqcstat','standings','stats'):
                    total_urls['total_'+i+'_'+name]=f'https://bdata-js.7m.com.cn/analyse/{i}/{name}.js'
        except Exception as exc:errors.append({'id':i,'error':str(exc)})
    hist_res=fetch.batch({'history_'+tid:u for tid,u in team_urls.items()}); history_page_audit=[]
    for k,r in hist_res.items():
        tid=k.split('_',1)[1]
        if not r['ok']:
            history_page_audit.append({'team_source_id':tid,'url':r['url'],'http_success':False,'parsed_games':0,'errors':[r.get('error_type') or 'FETCH_FAILED']})
            continue
        try:
            hs,err=parse_history(text_of(r),r['path'],r['received_at'],r['url'],'TEAM_HISTORY');history.update({g['event_id']:g for g in hs});errors+=err
            history_page_audit.append({'team_source_id':tid,'url':r['url'],'path':r['path'],'http_success':True,'parsed_games':len(hs),'errors':err})
        except Exception as e:
            errors.append({'path':r['path'],'error':str(e)});history_page_audit.append({'team_source_id':tid,'url':r['url'],'path':r['path'],'http_success':True,'parsed_games':0,'errors':[str(e)]})
    total_res=fetch.batch(total_urls)
    for key,r in total_res.items():
        if not r.get('ok'):continue
        event_id='7m:'+key.split('_')[1]
        context=total_context.setdefault(event_id, {'source_urls':[],'raw_paths':[],'variables':{},
                                                    'possessions_verified':False,'basic_offense_verified':False,'three_point_verified':False,
                                                    'late_foul_verified':False,'rotation_verified':False})
        parsed=parse_total_context(text_of(r),r['path'],r['received_at'],r['url'])
        context['source_urls'].append(parsed['source_url']);context['raw_paths'].append(parsed['raw_path'])
        context['variables'].update(parsed['source_aggregates'])
        context['available_variables']=sorted(set(context.get('available_variables',[]))|set(parsed['available_variables']))
        for flag in ('possessions_verified','basic_offense_verified','three_point_verified','late_foul_verified','rotation_verified'):
            context[flag]=bool(context.get(flag) or parsed.get(flag))
        if parsed.get('basic_offense_profile'):context['basic_offense_profile']=parsed['basic_offense_profile']
        if parsed.get('three_point_profile'):context['three_point_profile']=parsed['three_point_profile']
        context['schema_note']=parsed['schema_note']
    global_result=discover_global(day,root,timeout,workers)
    # Histories and per-event context can take materially longer than the
    # current-board freshness window.  Refresh only the current odds boards at
    # the end of collection, preserving both raw captures in the source-health
    # ledger.  A successful provider refresh replaces its normalized opening
    # snapshot; a failed refresh leaves the earlier snapshot intact and is
    # visible in source health.  No timestamp is invented.
    refresh_tick=str(int(now().timestamp()*1000))
    refresh_urls={f'closing_titan_odds_{company_id}':f'https://lq3.titan007.com/NBA/nbaGoal{company_id}.xml?t={refresh_tick}'
                  for company_id in ('1','2','3','8','9')}
    for sel,(name,ns) in COMPANIES.items():
        refresh_urls[f'closing_7m_odds_{sel}']=f'https://js-basket.7m.com.cn/odds/comlive_{ns}.js?t={refresh_tick}'
    refresh_res=fetch.batch(refresh_urls);titan_refresh=[];sevenm_refresh=[];refresh_errors=[]
    for key,r in refresh_res.items():
        if not r.get('ok'):continue
        try:
            if key.startswith('closing_titan_odds_'):
                parsed,err=parse_titan_odds_xml(text_of(r),key.rsplit('_',1)[1],r.get('path'),r.get('received_at'))
                titan_refresh+=parsed;refresh_errors+=err
            elif key.startswith('closing_7m_odds_'):
                parsed,err=parse_odds(text_of(r),r.get('path'),r.get('received_at'),key.rsplit('_',1)[1],contracts)
                sevenm_refresh+=parsed;refresh_errors+=err
        except Exception as exc:
            refresh_errors.append({'key':key,'path':r.get('path'),'error':type(exc).__name__+': '+str(exc)})
    if titan_refresh:
        quotes=[q for q in quotes if q.get('feed_provider')!='TITAN007']+titan_refresh
    if sevenm_refresh:
        quotes=[q for q in quotes if q.get('feed_provider')!='7M']+sevenm_refresh
    errors+=refresh_errors
    market_refresh_audit={
        'attempted_at':stamp(now()),'end_of_collection_refresh':True,
        'titan_quotes_parsed':len(titan_refresh),'sevenm_quotes_parsed':len(sevenm_refresh),
        'titan_replaced_opening_snapshot':bool(titan_refresh),
        'sevenm_replaced_opening_snapshot':bool(sevenm_refresh),
        'errors':refresh_errors,
    }
    merged_events=merge_with_primary(list(events.values()),global_result.get('events',[]),quotes)
    # Reconcile only after detail identities and global discovery have both
    # landed.  Some 7M fixtures (notably NBL/EuroLeague) are absent from the
    # compact schedule JS and become identifiable only through the quote/detail
    # or global-discovery paths.  Reconciling earlier left valid Titan rows as
    # duplicate events even though team pair and tip time agreed exactly.
    merged_event_map={event['event_id']:event for event in merged_events}
    titan_reconciliation=reconcile_titan_events(merged_event_map,titan_events,quotes)
    merged_events=list(merged_event_map.values())
    # Apply the shared league-family classifier to legacy 7M events as well as
    # newly discovered events, so coverage is comparable across all sources.
    for event in merged_events:
        family, region = classify_global(
            event.get('league') or event.get('competition') or '',
            event.get('competition_key') or event.get('raw_event_name') or '',
        )
        event['league_family'] = event.get('league_family') or family
        event['region'] = event.get('region') or region
    # Maintain the local Titan reference database on every live run.  Facts
    # enter model history only after source validation, cutoff checks and
    # cross-provider mirror de-duplication; failures are audited and do not
    # erase the already captured 7M history.
    titan_history_audit={"status":"NOT_ATTEMPTED"};titan_history_health=[]
    history_rows=list(history.values())
    try:
        ref_root=root/'reference_data'/'titan007_history'
        year=now().astimezone(BJ).year
        reference=update_history_database(merged_events,ref_root,cutoff=now(),years=[year,year-1],
                                          boxscore_limit=10,workers=workers)
        titan_history_health=reference.get('source_health',[])
        for row in titan_history_health:
            row['source']='titan007_history';row['source_group']='team_history_and_box_score'
        history_rows,merge_audit=merge_reference_history(history_rows,reference.get('history_rows',[]),merged_events)
        titan_history_audit=dict(reference.get('audit') or {},status='OK',merge=merge_audit,
                                 database=reference.get('database'),audit_path=reference.get('audit_path'))
        for item in reference.get('audit',{}).get('errors',[]):
            errors.append({'source':'titan007_history',**item})
    except Exception as exc:
        titan_history_audit={'status':'FAILED','error_type':type(exc).__name__,'error':str(exc),
                             'reference_history_added':0,'real_execution_allowed':False}
        errors.append({'source':'titan007_history','error':type(exc).__name__+': '+str(exc)})
    market_routes={x['event_id']:x for x in route_odds(merged_events,quotes)}
    for event in merged_events:
        routing=market_routes.get(event.get('event_id'),{})
        event['market_status']=routing.get('market_status','NO_MARKET')
        event['market_match_method']=routing.get('market_match_method','NO_MATCH')
        event['discovery_status']='MARKET_FOUND' if routing.get('market_status')=='MARKET_FOUND' else event.get('discovery_status','DISCOVERED_ONLY')
    errors+=global_result.get('errors',[])
    end=stamp(now());result={'run_id':sid,'mode':'FORWARD_NATIVE','capture_finished_at':end,'requested_day':day,
       'events':merged_events,'quotes':quotes,'history':history_rows,'total_context':total_context,
       'source_health':fetch.rows+global_result.get('source_health',[])+titan_history_health,'errors':errors,
       'global_discovery':{'run_id':global_result.get('run_id'),'event_count':len(global_result.get('events',[])),'raw_directory':global_result.get('raw_directory'),'source_health':global_result.get('source_health',[])},
       'raw_directory':str(session),'histories_attempted':len(hist_res),'histories_parsed':sum(1 for r in history_page_audit if r['parsed_games']>0),
       'team_history_games_parsed':sum(r['parsed_games'] for r in history_page_audit),'history_page_audit':history_page_audit,
       'source_timezone':'Asia/Shanghai','source_timezone_assumption_for_schedule':'7M and Titan007 schedule pages declare local GMT+0800; detail page verification required for conflicting events',
       'market_refresh_audit':market_refresh_audit,
       'titan007_history_audit':titan_history_audit,
       'titan007_audit':{'schedule_endpoint':'https://lq3.titan007.com/NBA/today2.xml','schedule_rows_target_day':len(titan_events),
                         'odds_endpoints_attempted':len([k for k in titan_res if k.startswith('titan_odds_')]),
                         'odds_quotes_parsed':sum(1 for q in quotes if q.get('feed_provider')=='TITAN007'),
                         'today_event_ids':sorted(e.get('source_event_id') for e in titan_events),
                         'missing_current_board_event_ids':sorted(set(e.get('source_event_id') for e in titan_events)-set(q.get('source_event_id') for q in quotes if q.get('feed_provider')=='TITAN007')),
                         'canonical_reconciliation':titan_reconciliation,
                         'market_found_canonical_event_ids':sorted({q.get('event_id') for q in quotes if q.get('feed_provider')=='TITAN007'}),
                         'note':'Titan current-board XML has no per-quote last-change timestamp; raw markets are retained, but freshness and paper-entry eligibility remain governed by the existing contract gate.'}}
    exclusive(session/'capture.json',result);return result

def replay_bundle(bundle_root,session_id=None):
    root=Path(bundle_root);out=root/'outputs'/'basketball_odds_trader' if (root/'outputs').exists() else root
    base=out/'raw/source_scout/sevenm_basket/sessions'
    dirs=[p for p in base.iterdir() if p.is_dir() and (p/'session.json').exists()]
    if not dirs:raise ValueError('no captured sessions in supplied bundle')
    session=next((p for p in dirs if p.name==session_id),None) if session_id else max(dirs,key=lambda p:load(p/'session.json')['captured_at'])
    if session is None:raise ValueError('session not found')
    meta=load(session/'session.json');observed=meta['captured_at'];events={};history={};errors=[]
    for p in sorted((session/'reverse').glob('*.js')):
        try:
            htmlp=p.with_suffix('.html');html=decode(htmlp.read_bytes()) if htmlp.exists() else ''
            e=parse_identity(decode(p.read_bytes()),p.stem,p,observed,'GMT+0800' in html)
            events[e['event_id']]=e
            hs,err=parse_history(decode(p.read_bytes()),p,observed,e['source_url'],'H2H');history.update({g['event_id']:g for g in hs});errors+=err
        except Exception as e:errors.append({'path':str(p),'error':str(e)})
    # Exporter omitted .raw files; do not invent either raw side from lossy normalized observations.
    quotes=[]
    for p in sorted((out/'markets'/'normalized').glob('*.json')):
        d=load(p,{})
        if d.get('capture_session_id')!=session.name:continue
        for idx,q in enumerate(d.get('quotes',[])):
            sid=str(d.get('event',{}).get('source_event_id',''))
            if '7m:'+sid not in events:continue
            ns=COMPANIES.get(str(q.get('company_id')),('?','UNKNOWN'))[1]
            quotes.append({'quote_id':sha((str(p)+str(idx)).encode())[:24],'event_id':'7m:'+sid,'source_event_id':sid,
              'feed_provider':'7M','bookmaker_id':'7m-company:'+ns,'bookmaker':q.get('company_name'),'market_type':q.get('market_type'),
              'raw_line':q.get('raw_line',q.get('line')),'line_team1':None,'direction_verified':False,'raw_prices':[q.get('raw_price'),None],
              'decimal_prices':None,'price_format_verified':False,'source_quote_at':stamp(source_time(q['source_quote_at'])) if source_time(q.get('source_quote_at')) else None,
              'source_timestamp_semantics':'UNKNOWN','received_at':q.get('captured_at',observed),'raw_verified':False,
              'ot_rule':'UNKNOWN','rule_evidence':None,'status':'LEGACY_NORMALIZED_UNVERIFIED','period':q.get('period','FULL_GAME'),'main_or_alt':'MAIN',
              'raw_path':None,'legacy_path':str(p),'legacy_record':q,'execution_verified':False,
              'migration_blockers':['RAW_ODDS_NOT_INCLUDED_IN_DEBUG_BUNDLE','LEGACY_LOST_SECOND_SIDE_AND_DIRECTION']})
    return {'run_id':'audit_'+session.name,'mode':'BUNDLE_AUDIT','capture_finished_at':observed,'requested_day':meta['target_bj_date'],
       'events':list(events.values()),'quotes':quotes,'history':list(history.values()),'errors':errors,'source_health':[],
       'raw_directory':str(session),'reported_legacy_event_count':meta.get('event_id_count'),'reported_legacy_odds_ids':meta.get('odds_id_count'),
       'missing_raw_files':[k for k in meta.get('raw_paths',{}) if not (session/(k+'.raw')).exists()],
       'limitations':['Supplied detail HTML/JS preserved; raw quote/event files omitted by exporter.',
                     'Audit-time reconstruction is not a prediction originally issued before the game.']}
