"""Basketball v2.2: actual collector -> evidence -> forecast -> decisions -> renderer."""
VERSION = 'basketball-repair-2.2.2'
