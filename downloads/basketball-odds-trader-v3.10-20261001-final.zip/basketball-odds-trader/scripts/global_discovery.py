"""Global basketball event discovery, independent from odds collection.

The module only creates event identities. It never invents a quote and never
changes pricing or execution gates. Every adapter is attempted independently;
an unavailable adapter is recorded rather than converted into "no games".
"""
from __future__ import annotations

import json, re, ssl, uuid
from functools import lru_cache
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote
from urllib.request import HTTPSHandler, ProxyHandler, Request, build_opener, urlopen
from zoneinfo import ZoneInfo

BJ = ZoneInfo("Asia/Shanghai")
UTC = timezone.utc

@lru_cache(maxsize=1)
def _registered_league_aliases():
    """Load formal aliases from the Skill registry.

    Exact normalized aliases are resolved before broad keyword rules.  This
    keeps similarly named leagues such as Australia NBL, China NBL and
    Singapore NBL from being collapsed into one family.
    """
    try:
        import yaml
        path = Path(__file__).resolve().parents[1] / "config" / "league_registry.yaml"
        payload = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        aliases = ((payload.get("aliases") or {}).get("leagues") or {})
        families = payload.get("league_families") or {}
        return {
            re.sub(r"[^\w\u4e00-\u9fff]+", "", str(alias).casefold()): (str(family), families.get(str(family), {}))
            for alias, family in aliases.items()
        }
    except (OSError, ValueError, TypeError):
        return {}

def _region_for_registered(family, spec):
    explicit = spec.get("region") if isinstance(spec, dict) else None
    if explicit:
        return str(explicit)
    countries = " ".join(str(x) for x in ((spec or {}).get("countries") or [])).casefold()
    if family.startswith("FIBA_"): return "FIBA"
    if any(x in countries for x in ("europe", "czech", "sweden", "finland", "romania", "switzerland", "hungary", "belarus", "slovakia", "norway")): return "欧洲"
    if any(x in countries for x in ("australia", "new zealand", "oceania")): return "大洋洲"
    if any(x in countries for x in ("korea", "japan")): return "日本韩国"
    if any(x in countries for x in ("usa", "canada")): return "北美"
    if any(x in countries for x in ("americas", "puerto rico", "colombia", "brazil", "el salvador")): return "拉美"
    if any(x in countries for x in ("philippines", "singapore", "asia", "middle east", "gulf")): return "其他亚洲"
    if "china" in countries: return "中国"
    return "其他"

# ESPN is reachable from this host only when the environment proxy is bypassed.
# Keep normal certificate verification; this is not an SSL verification bypass.
_ESPN_DIRECT_OPENER = build_opener(
    ProxyHandler({}),
    HTTPSHandler(context=ssl.create_default_context()),
)

REGION_BY_FAMILY = {
    "CHINA": "中国", "JAPAN_KOREA": "日本韩国", "EUROPE": "欧洲",
    "NORTH_AMERICA": "北美", "AMERICAS": "拉美", "OCEANIA": "大洋洲",
    "FIBA": "FIBA", "GULF": "海湾", "ASIA": "其他亚洲",
}

def stamp(dt=None):
    return (dt or datetime.now(UTC)).astimezone(BJ).isoformat()

def parse_time(value):
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(value, UTC)
    text = str(value or "").strip().replace("Z", "+00:00")
    dt = datetime.fromisoformat(text)
    return dt.replace(tzinfo=UTC) if dt.tzinfo is None else dt.astimezone(UTC)

def norm_team(value):
    text = re.sub(r"[^\w\u4e00-\u9fff]+", "", str(value or "").casefold())
    aliases = {
        "北京北汽": "beijingducks", "北京首钢": "beijingducks", "beijingducks": "beijingducks",
        "广东宏远": "guangdongsoutherntigers", "广东东阳光": "guangdongsoutherntigers",
        "guangdongsoutherntigers": "guangdongsoutherntigers",
        "中国台北": "chinesetaipei", "中华台北": "chinesetaipei", "chinesetaipei": "chinesetaipei",
    }
    return aliases.get(text, text)

def classify(competition, country=""):
    text = f"{competition} {country}".casefold()
    exact = re.sub(r"[^\w\u4e00-\u9fff]+", "", str(competition or "").casefold())
    registered = _registered_league_aliases().get(exact)
    if registered:
        return registered[0], _region_for_registered(*registered)
    # 7M commonly supplies Chinese competition labels. Keep this mapping
    # explicit so discovered events are not silently downgraded to
    # UNCLASSIFIED_DISCOVERED when a broad upstream source is unavailable.
    if any(x in text for x in ("亚洲运动会", "亚运会", "亚洲杯", "亚锦赛")):
        return "FIBA_CONTINENTAL", "FIBA"
    if any(x in text for x in ("fiba", "world cup", "qualif", "国家队", "national", "olympic")):
        if any(x in text for x in ("youth", "u16", "u17", "u18", "u19", "u20")): return "FIBA_YOUTH", "FIBA"
        if "qualif" in text: return "FIBA_QUALIFIER", "FIBA"
        return ("FIBA_WOMEN" if any(x in text for x in ("women", "女")) else "FIBA_MEN"), "FIBA"
    if any(x in text for x in ("cba", "wcba", "cuba", "中国", "china")):
        if "wcba" in text or "女子" in text: return "CHINA_WCBA", "中国"
        if "cuba" in text or "大学生" in text: return "CHINA_CUBA", "中国"
        if "nbl" in text: return "CHINA_NBL", "中国"
        return "CHINA_CBA", "中国"
    if any(x in text for x in ("b.league", "japan", "日本")): return "JAPAN_BLEAGUE", "日本韩国"
    if any(x in text for x in ("kbl", "korea", "韩国")): return "KOREA_KBL", "日本韩国"
    if "wnbl" in text or "澳大利亚女子" in text: return "AUSTRALIA_WNBL", "大洋洲"
    if any(x in text for x in ("australia", "nbl australia", "australian nbl", "澳大利亚国家篮球联赛", "澳洲nbl", "nbl(a)")): return "AUSTRALIA_NBL", "大洋洲"
    if any(x in text for x in ("new zealand", "nzbl")): return "NEW_ZEALAND", "大洋洲"
    if any(x in text for x in ("eurocup", "欧篮杯", "欧女杯", "欧洲杯")): return "EUROCUP", "欧洲"
    if any(x in text for x in ("euroleague", "euro", "欧洲篮球联赛", "欧洲篮球冠军联赛", "欧冠")):
        return "EUROLEAGUE", "欧洲"
    if any(x in text for x in ("spain", "acb", "西甲", "德国", "德甲", "germany", "意甲", "italy", "法国", "法甲", "france", "turkey", "土超", "greece", "希腊", "adriatic", "亚得里亚", "欧北联", "欧洲", "以色列联赛")):
        return "EUROPE_DOMESTIC", "欧洲"
    if "wnba" in text or "美国女子职业篮球联赛" in text: return "WNBA", "北美"
    if "nba" in text or "美国职业篮球联赛" in text: return "NBA", "北美"
    if any(x in text for x in ("ncaa", "g league", "college")): return "NORTH_AMERICA_CLUB", "北美"
    if any(x in text for x in ("mexico", "brazil", "argentina", "puerto rico", "chile", "uruguay", "venezuela", "colombia", "dominican")): return "AMERICAS_OTHER", "拉美"
    if any(x in text for x in ("saudi", "uae", "qatar", "bahrain", "kuwait", "gulf")): return "GULF", "海湾"
    if any(x in text for x in ("philippines", "taiwan", "southeast", "asia")): return "OTHER_ASIA", "其他亚洲"
    return "UNCLASSIFIED_DISCOVERED", "其他"

def canonical_id(family, team1, team2, tip_utc, official_id=None):
    if official_id:
        return f"global:{family}:{official_id}"
    minute = parse_time(tip_utc).replace(second=0, microsecond=0).isoformat()
    return f"global:{family}:{norm_team(team1)}:{norm_team(team2)}:{minute}"

def _fetch_json(url, timeout, direct=False):
    req = Request(url, headers={"User-Agent": "basketball-odds-trader/3.0", "Accept": "application/json"})
    if direct:
        try:
            response_ctx = _ESPN_DIRECT_OPENER.open(req, timeout=timeout)
        except OSError:
            # DNS/proxy state on Windows can change during a long collection.
            # Retry through the verified system HTTPS route; certificate
            # verification remains enabled in both attempts.
            response_ctx = urlopen(req, timeout=timeout)
    else:
        response_ctx = urlopen(req, timeout=timeout)
    with response_ctx as response:
        raw = response.read(8_000_001)
        if len(raw) > 8_000_000: raise ValueError("response_too_large")
        if response.status != 200: raise ValueError(f"HTTP_{response.status}")
        return json.loads(raw.decode("utf-8", "replace")), raw

def _fetch_html(url, timeout):
    req=Request(url,headers={"User-Agent":"Mozilla/5.0 basketball-odds-trader/3.0"})
    with urlopen(req,timeout=timeout) as response:
        raw=response.read(8_000_001)
        if response.status!=200: raise ValueError(f"HTTP_{response.status}")
        return raw

def _event(family, region, team1, team2, tip, source, source_url, official_id, competition, raw_path=None):
    dt = parse_time(tip)
    model_family = "NATIONAL_TEAM" if family.startswith("FIBA_") else ("HIGH_UNCERTAINTY" if family in {"UNCLASSIFIED_DISCOVERED","CHINA_CUBA"} else "CLUB_MATURE")
    return {
        "event_id": canonical_id(family, team1, team2, dt, official_id),
        "canonical_event_id": canonical_id(family, team1, team2, dt, official_id),
        "source_event_id": str(official_id) if official_id is not None else None,
        "source": source, "source_name": source, "source_group": "broad",
        "upstream_provider": source.split(":", 1)[0], "source_url": source_url,
        "raw_path": str(raw_path) if raw_path is not None else None, "source_confidence": "medium",
        "team1_name": team1, "team2_name": team2,
        "team1_key": norm_team(team1), "team2_key": norm_team(team2),
        "league": competition or family, "league_family": family, "region": region,
        "competition": competition or family, "competition_type": "CLUB_LEAGUE",
        "gender": "WOMEN" if any(x in str(competition).casefold() for x in ("women", "女", "wnba")) else "MEN",
        "age_group": "SENIOR", "model_family": model_family,
        "tip_at": dt.astimezone(BJ).isoformat(), "tip_time_utc": dt.isoformat(),
        "tip_time_bj": dt.astimezone(BJ).isoformat(), "bj_date": dt.astimezone(BJ).date().isoformat(),
        "source_timezone": "UTC", "identity_verified": True, "discovery_status": "DISCOVERED_ONLY",
        "market_status": "NO_MARKET", "game_minutes": 40, "game_minutes_source": "GLOBAL_DISCOVERY_PRIOR",
        "game_minutes_used_in_pricing": False, "home_sign": 0,
        "home_adjustment_assumption": "NEUTRAL_UNLESS_VERIFIED", "venue_status": "UNKNOWN",
    }

def _espn(day, sport, family, region, timeout, raw_dir):
    url = f"https://site.api.espn.com/apis/site/v2/sports/basketball/{quote(sport)}/scoreboard?dates={day.replace('-', '')}"
    data, raw = _fetch_json(url, timeout, direct=True)
    path = raw_dir / f"espn_{sport.replace('/', '_')}_{day}.json"; path.write_bytes(raw)
    rows=[]
    for item in data.get("events", []):
        comp=(item.get("competitions") or [{}])[0]; competitors=comp.get("competitors") or []
        if len(competitors)<2: continue
        by={x.get("homeAway"):x for x in competitors}; a=by.get("away", competitors[0]); h=by.get("home", competitors[1])
        league=((item.get("league") or {}).get("name") or sport)
        rows.append(_event(family, region, a.get("team",{}).get("displayName", ""), h.get("team",{}).get("displayName", ""), item.get("date"), f"espn:{sport}", url, item.get("id"), league, path))
    return rows

def _sofascore(day, timeout, raw_dir):
    url=f"https://www.sofascore.com/api/v1/sport/basketball/scheduled-events/{day}"
    data,raw=_fetch_json(url,timeout);path=raw_dir/f"sofascore_{day}.json";path.write_bytes(raw);rows=[]
    for item in data.get("events", []):
        h=item.get("homeTeam") or {}; a=item.get("awayTeam") or {}; comp=((item.get("tournament") or {}).get("uniqueTournament") or {}).get("name") or ((item.get("tournament") or {}).get("name") or "basketball")
        family,region=classify(comp, (h.get("country") or {}).get("name", ""))
        if not h.get("name") or not a.get("name") or not item.get("startTimestamp"): continue
        rows.append(_event(family,region,a["name"],h["name"],item["startTimestamp"],"sofascore",url,item.get("id"),comp,path))
    return rows

def _fiba_calendar(day, timeout, raw_dir):
    # The official surface is attempted separately. It is an event discovery
    # source only; it is never used as a market source.
    from parsers.fiba_page_parser import parse_fiba_page, parse_fiba_rendered_landing
    url="https://www.fiba.basketball/en/games";raw=_fetch_html(url,timeout)
    page=raw.decode('utf-8','replace');(raw_dir/'fiba_games.html').write_bytes(raw)
    rows=parse_fiba_page(page,url,stamp())+parse_fiba_rendered_landing(page,url,stamp())
    out=[]
    for x in rows:
        tip=x.get('tip_utc') or x.get('start_time')
        if not tip: continue
        dt=parse_time(tip)
        if dt.astimezone(BJ).date().isoformat()!=day: continue
        fam='FIBA_WOMEN' if 'WOMEN' in str(x.get('league_family','')).upper() or '女' in str(x.get('competition','')) else 'FIBA_MEN'
        if 'QUAL' in str(x.get('competition','')).upper(): fam='FIBA_QUALIFIER'
        out.append(_event(fam,'FIBA',x.get('team_1'),x.get('team_2'),tip,'fiba_official_calendar',url,x.get('official_game_id'),x.get('competition','FIBA'),raw_dir/'fiba_games.html'))
    return out

def discover(day, output_root, timeout=12, workers=4):
    run_id=datetime.now(UTC).strftime("%Y%m%dT%H%M%S")+"_"+uuid.uuid4().hex[:8]
    raw_dir=Path(output_root)/"raw"/"global_discovery"/run_id;raw_dir.mkdir(parents=True,exist_ok=True)
    events=[];health=[];errors=[]
    adapters=[]
    for sport,family,region in (("nba","NBA","北美"),("wnba","WNBA","北美"),("mens-college-basketball","NCAAB","北美"),("womens-college-basketball","WNCAAB","北美")):
        adapters.append((f"espn:{sport}",lambda sport=sport,family=family,region=region:_espn(day,sport,family,region,timeout,raw_dir)))
    adapters.append(("sofascore",lambda:_sofascore(day,timeout,raw_dir)))
    adapters.append(("fiba_official_calendar",lambda:_fiba_calendar(day,timeout,raw_dir)))
    for name,fn in adapters:
        started=stamp()
        try:
            rows=fn();events.extend(rows);health.append({"source":name,"source_group":"broad" if name!="fiba_official_calendar" else "official","upstream_provider":name.split(':',1)[0],"attempted":True,"success":True,"status":"success" if rows else "empty_valid_response","event_count":len(rows),"captured_at":stamp(),"raw_snapshot_path":str(raw_dir)})
        except Exception as exc:
            errors.append({"source":name,"error_type":type(exc).__name__,"error":str(exc)});health.append({"source":name,"source_group":"broad" if name!="fiba_official_calendar" else "official","upstream_provider":name.split(':',1)[0],"attempted":True,"success":False,"status":"source_unavailable","error_type":type(exc).__name__,"error":str(exc),"event_count":0,"captured_at":stamp(),"raw_snapshot_path":str(raw_dir)})
    unique={}
    for e in events:
        key=(e["team1_key"],e["team2_key"],e["tip_time_utc"][:16])
        current=unique.get(key)
        if current:
            current.setdefault("discovery_sources",[]).append({"source":e["source"],"source_url":e["source_url"],"source_event_id":e.get("source_event_id")})
        else:
            e["discovery_sources"]=[{"source":e["source"],"source_url":e["source_url"],"source_event_id":e.get("source_event_id")}];unique[key]=e
    result={"run_id":run_id,"day":day,"events":list(unique.values()),"source_health":health,"errors":errors,"raw_directory":str(raw_dir),"captured_at":stamp()}
    (raw_dir/"global_discovery.json").write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
    return result

def merge_with_primary(primary, discovered, quotes=None):
    """Merge global schedule identities into the existing 7M canonical pool."""
    quotes=quotes or [];out=list(primary);used=set();
    def close(a,b):
        try:return abs((parse_time(a)-parse_time(b)).total_seconds())<=1800
        except Exception:return False
    for p in out:
        p.setdefault("discovery_status","MARKET_FOUND" if any(q.get("event_id")==p.get("event_id") for q in quotes) else "DISCOVERED_ONLY")
        p.setdefault("market_status","MARKET_FOUND" if any(q.get("event_id")==p.get("event_id") for q in quotes) else "NO_MARKET")
        p.setdefault("discovery_sources",[{"source":p.get("source","7M"),"source_url":p.get("source_url")}])
    for g in discovered:
        candidates=[p for p in out if close(p.get("tip_at"),g.get("tip_at")) and {norm_team(p.get("team1_name")),norm_team(p.get("team2_name"))}=={g.get("team1_key"),g.get("team2_key") }]
        if len(candidates)==1:
            p=candidates[0];p.setdefault("discovery_sources",[]).extend(g.get("discovery_sources",[]));p.setdefault("global_source_ids",[]).append(g.get("event_id"));used.add(g.get("event_id"))
        elif not candidates:
            g.setdefault("discovery_status", "DISCOVERED_ONLY")
            g.setdefault("market_status", "NO_MARKET")
            out.append(g)
    return out
