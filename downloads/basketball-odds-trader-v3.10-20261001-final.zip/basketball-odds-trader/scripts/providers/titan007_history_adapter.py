"""Titan007 team-history and box-score reference database.

The public team database is JavaScript-backed.  This adapter downloads the
same normal HTTP resources used by the rendered pages, stores immutable raw
snapshots, and normalizes only source facts.  Handicap/total trend summaries
are deliberately excluded from model history and remain market evidence.
"""
from __future__ import annotations

import hashlib
import html
import json
import math
import re
import sqlite3
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import quote

from repair_v22.common import assignments, competition_key

try:
    from curl_cffi import requests as curl_requests
except ImportError:  # pragma: no cover - production image currently includes it
    curl_requests = None


BJ = timezone(timedelta(hours=8))
BASE = "https://nba.titan007.com"
MAX_BYTES = 8_000_000


def _stamp(value=None):
    value = value or datetime.now(timezone.utc)
    return value.astimezone(timezone.utc).isoformat()


def _sha(blob):
    return hashlib.sha256(blob).hexdigest()


def _token(value):
    text = html.unescape(str(value or "")).casefold()
    return re.sub(r"[^a-z0-9\u4e00-\u9fff]+", "", text)


def _search_name(value):
    """Remove 7M display-only standings/league suffixes, never team text."""
    text = str(value or "").strip()
    while re.search(r"\[[^\[\]]+\]\s*$", text):
        text = re.sub(r"\s*\[[^\[\]]+\]\s*$", "", text).strip()
    return text


def _int(value):
    if isinstance(value, bool):
        return None
    try:
        out = int(value)
    except (TypeError, ValueError):
        return None
    return out


def _float(value):
    if isinstance(value, bool):
        return None
    try:
        out = float(value)
    except (TypeError, ValueError):
        return None
    return out if math.isfinite(out) else None


def _strip_score(value):
    text = re.sub(r"<[^>]+>", "", str(value or ""))
    match = re.search(r"(\d+)\s*-\s*(\d+)", text)
    return (int(match.group(1)), int(match.group(2))) if match else (None, None)


def _tech_url(match_id):
    sid = str(match_id)
    if len(sid) < 3 or not sid.isdigit():
        raise ValueError("INVALID_TITAN_MATCH_ID")
    return f"{BASE}/jsData/tech/{sid[0]}/{sid[1:3]}/{sid}.js"


def parse_search_response(text, query):
    """Parse either the legacy autocomplete payload or Search_Team HTML.

    Search_Team is preferred because the autocomplete handler can legally
    return an empty 200 response.  A mapping is accepted only when exactly
    one distinct TeamID contains an alias equal to the canonical query after
    conservative punctuation/case normalization.
    """
    source = str(text or "")
    by_id = {}
    if "TeamID=" in source:
        for block in re.findall(r"<tr\b[^>]*>(.*?)</tr>", source, re.I | re.S):
            ids = re.findall(r"TeamID=(\d+)", block, re.I)
            if not ids:
                continue
            team_id = ids[0]
            cells = re.findall(r"<td\b[^>]*>(.*?)</td>", block, re.I | re.S)
            values = []
            for cell in cells:
                value = html.unescape(re.sub(r"<[^>]+>", "", cell)).strip()
                value = re.sub(r"\s+", " ", value)
                if value:
                    values.append(value)
            aliases = values[1:] if len(values) > 1 else values
            league_ids = re.findall(r"SclassID=(\d+)", block, re.I)
            row = by_id.setdefault(team_id, {"team_id": team_id, "name": aliases[0] if aliases else "",
                                             "aliases": [], "league_id": league_ids[0] if league_ids else None,
                                             "league": values[0] if len(values) > 1 else None})
            row["aliases"] = list(dict.fromkeys(row["aliases"] + aliases))
    else:
        for raw in source.split(","):
            parts = raw.split("^")
            if len(parts) < 2 or _int(parts[0]) is None:
                continue
            team_id = str(int(parts[0]))
            by_id[team_id] = {"team_id": team_id, "name": parts[1].strip(),
                              "aliases": [parts[1].strip()], "league_id": None, "league": None}
    rows = list(by_id.values())
    query_token = _token(query)
    exact = [row for row in rows if query_token and any(_token(alias) == query_token for alias in row["aliases"])]
    return {"query": query, "candidates": rows, "exact": exact[0] if len(exact) == 1 else None,
            "status": "EXACT" if len(exact) == 1 else "AMBIGUOUS" if len(exact) > 1 else "NOT_FOUND"}


def parse_team_detail(text):
    data = assignments(text)
    summary = data.get("teamSummary")
    league = data.get("arrLeague")
    players = data.get("teamPlayers") or []
    if not isinstance(summary, list) or len(summary) < 15:
        raise ValueError("TITAN_TEAM_SUMMARY_SCHEMA")
    aliases = [summary[i] for i in (1, 2, 3, 4, 5, 6) if i < len(summary) and summary[i]]
    roster = []
    for row in players:
        if not isinstance(row, list) or len(row) < 10:
            continue
        roster.append({"player_id": str(row[0]), "name_zh": row[1], "name_tw": row[2],
                       "name_en": row[3], "number": row[7], "position": row[8], "birth_date": row[9],
                       "height_cm": row[10] if len(row) > 10 else None,
                       "weight_kg": row[11] if len(row) > 11 else None})
    return {"team_id": str(summary[0]), "name_zh": summary[1], "name_tw": summary[2],
            "name_en": summary[3], "aliases": list(dict.fromkeys(aliases)),
            "league_id": str(league[0]) if isinstance(league, list) and league else None,
            "league_name": league[1] if isinstance(league, list) and len(league) > 1 else None,
            "season": league[4] if isinstance(league, list) and len(league) > 4 else None,
            "roster": roster, "source_last_update": data.get("teamLastUpdateTime")}


def parse_team_schedule(text):
    rows = assignments(text).get("teamPageData")
    if not isinstance(rows, list):
        raise ValueError("TITAN_TEAM_SCHEDULE_SCHEMA")
    result = []
    for row in rows:
        if not isinstance(row, list) or len(row) < 20:
            continue
        home_score, away_score = _strip_score(row[6])
        half_home, half_away = _strip_score(row[7])
        try:
            tip_bj = datetime.strptime(str(row[3]), "%Y/%m/%d %H:%M").replace(tzinfo=BJ)
        except ValueError:
            continue
        state = _int(row[19])
        result.append({"match_id": str(row[0]), "league_id": str(row[1]), "league": row[8],
                       "league_en": row[10], "tip_at": tip_bj.astimezone(timezone.utc).isoformat(),
                       "tip_time_bj": tip_bj.isoformat(), "home_team_id": str(row[4]),
                       "away_team_id": str(row[5]), "home_name": row[11], "home_name_en": row[13],
                       "away_name": row[14], "away_name_en": row[16], "home_score": home_score,
                       "away_score": away_score, "half_home": half_home, "half_away": half_away,
                       "match_kind": _int(row[17]), "has_analysis": bool(row[18]),
                       "source_state": state,
                       "status": "FINAL" if state == -1 and home_score is not None else
                                 "CANCELED" if state == -4 else "SCHEDULED"})
    return result


def parse_period_scores(page_html):
    block = re.search(r'<span[^>]+id=["\']scoreData["\'][^>]*>(.*?)</span>', str(page_html or ""), re.I | re.S)
    if not block:
        return None
    rows = re.findall(r"<tr[^>]*>(.*?)</tr>", block.group(1), re.I | re.S)
    numeric = []
    for row in rows[1:]:
        values = [int(x) for x in re.findall(r"<td[^>]*>\s*(\d+)\s*</td>", row, re.I)]
        if values:
            numeric.append(values)
    if len(numeric) < 2 or len(numeric[0]) != len(numeric[1]) or len(numeric[0]) < 6:
        return None
    # Last two columns are half-time and full-time; preceding values are Q1-Q4/OT.
    return {"home_periods": numeric[0][:-2], "away_periods": numeric[1][:-2],
            "half_home": numeric[0][-2], "half_away": numeric[1][-2],
            "home_score": numeric[0][-1], "away_score": numeric[1][-1]}


def _team_box(part):
    rows = str(part or "").split("!")
    if len(rows) < 2:
        return None
    total = rows[-2].split("^")
    if len(total) < 16:
        return None
    fields = {"MIN": _float(total[0]), "FGM": _float(total[1]), "FGA": _float(total[2]),
              "3PM": _float(total[3]), "3PA": _float(total[4]), "FTM": _float(total[5]),
              "FTA": _float(total[6]), "ORB": _float(total[7]), "DRB": _float(total[8]),
              "REB": _float(total[9]), "AST": _float(total[10]), "PF": _float(total[11]),
              "STL": _float(total[12]), "TOV": _float(total[13]), "BLK": _float(total[14]),
              "PTS": _float(total[15])}
    required = ("FGA", "FTA", "ORB", "TOV")
    if all(fields[name] is not None for name in required):
        fields["possessions_estimate"] = fields["FGA"] + 0.44 * fields["FTA"] - fields["ORB"] + fields["TOV"]
    else:
        fields["possessions_estimate"] = None
    return fields


def parse_box_score_blob(text):
    parts = str(text or "").split("$")
    if len(parts) < 3:
        raise ValueError("TITAN_BOX_SCORE_SCHEMA")
    home, away = _team_box(parts[1]), _team_box(parts[2])
    team_ids = []
    if len(parts) > 3:
        for row in parts[3].split("!")[:2]:
            first = row.split("^")[0]
            if _int(first) is not None:
                team_ids.append(str(int(first)))
    complete = bool(home and away and home.get("possessions_estimate") and away.get("possessions_estimate"))
    return {"home": home, "away": away, "team_ids": team_ids,
            "pace_level": "LEVEL_B" if complete else "LEVEL_D",
            "pace_source": "DERIVED_BOX_SCORE" if complete else "UNAVAILABLE",
            "game_possessions_estimate": ((home["possessions_estimate"] + away["possessions_estimate"]) / 2)
                                         if complete else None,
            "formula": "FGA + 0.44 * FTA - ORB + TOV"}


def merge_reference_history(existing, supplemental, events):
    """Merge Titan facts without multiplying an existing mirrored game.

    The cross-provider event IDs are intentionally different.  Duplicate
    detection therefore uses only a current canonical target team, canonical
    competition, target/opponent final scores, and a six-hour tip window.
    Unconnected or cross-competition rows never enter the model history.
    """
    merged = list(existing or [])
    targets = {}
    for event in events or []:
        key = event.get("competition_key") or competition_key(event.get("league"), event.get("gender"))
        for field in ("team1_id", "team2_id"):
            if event.get(field):
                targets[str(event[field])] = key
    observations = []
    for game in merged:
        for target, wanted_key in targets.items():
            if target not in (str(game.get("team1_id")), str(game.get("team2_id"))):
                continue
            game_key = game.get("competition_key") or competition_key(game.get("league"), game.get("gender"))
            if game_key != wanted_key:
                continue
            home = str(game.get("team1_id")) == target
            target_score = game.get("score1_full") if home else game.get("score2_full")
            opponent_score = game.get("score2_full") if home else game.get("score1_full")
            try:
                tip = datetime.fromisoformat(str(game.get("tip_at")).replace("Z", "+00:00"))
            except (TypeError, ValueError):
                continue
            observations.append((target, game_key, target_score, opponent_score, tip))
    audit = Counter(candidates=len(supplemental or []))
    for game in supplemental or []:
        linked = []
        game_key = game.get("competition_key") or competition_key(game.get("league"), game.get("gender"))
        for target, wanted_key in targets.items():
            if target in (str(game.get("team1_id")), str(game.get("team2_id"))):
                if game_key == wanted_key:
                    linked.append(target)
                else:
                    audit["competition_mismatch"] += 1
        if not linked:
            audit["unconnected_or_mismatched"] += 1
            continue
        try:
            tip = datetime.fromisoformat(str(game.get("tip_at")).replace("Z", "+00:00"))
        except (TypeError, ValueError):
            audit["invalid_tip"] += 1
            continue
        duplicate = False
        new_observations = []
        for target in linked:
            home = str(game.get("team1_id")) == target
            target_score = game.get("score1_full") if home else game.get("score2_full")
            opponent_score = game.get("score2_full") if home else game.get("score1_full")
            if any(target == old_target and game_key == old_key and target_score == old_for and
                   opponent_score == old_against and abs((tip - old_tip).total_seconds()) <= 21600
                   for old_target, old_key, old_for, old_against, old_tip in observations):
                duplicate = True
                break
            new_observations.append((target, game_key, target_score, opponent_score, tip))
        if duplicate:
            audit["mirrored_duplicate"] += 1
            continue
        merged.append(game)
        observations.extend(new_observations)
        audit["added"] += 1
    return merged, dict(audit)


class TitanHistoryStore:
    def __init__(self, root):
        self.root = Path(root)
        self.raw_root = self.root / "raw"
        self.raw_root.mkdir(parents=True, exist_ok=True)
        self.db_path = self.root / "titan007_history.sqlite"
        self.db = sqlite3.connect(self.db_path)
        self.db.execute("PRAGMA journal_mode=WAL")
        self._schema()

    def _schema(self):
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS source_snapshot(
          snapshot_id TEXT PRIMARY KEY, url TEXT NOT NULL, captured_at TEXT NOT NULL,
          sha256 TEXT NOT NULL, byte_count INTEGER NOT NULL, content_type TEXT,
          raw_path TEXT NOT NULL, entity_type TEXT, entity_id TEXT);
        CREATE TABLE IF NOT EXISTS team(
          titan_team_id TEXT PRIMARY KEY, name_zh TEXT, name_tw TEXT, name_en TEXT,
          league_id TEXT, league_name TEXT, season TEXT, source_last_update TEXT,
          latest_snapshot_id TEXT, roster_json TEXT, updated_at TEXT);
        CREATE TABLE IF NOT EXISTS team_alias(
          titan_team_id TEXT NOT NULL, alias TEXT NOT NULL, normalized_alias TEXT NOT NULL,
          captured_at TEXT NOT NULL, source_snapshot_id TEXT NOT NULL,
          PRIMARY KEY(titan_team_id, normalized_alias, source_snapshot_id));
        CREATE TABLE IF NOT EXISTS team_mapping(
          canonical_team_id TEXT NOT NULL, raw_team_name TEXT NOT NULL,
          titan_team_id TEXT, status TEXT NOT NULL, candidates_json TEXT NOT NULL,
          observed_at TEXT NOT NULL, PRIMARY KEY(canonical_team_id, observed_at));
        CREATE TABLE IF NOT EXISTS match_history(
          titan_match_id TEXT PRIMARY KEY, league_id TEXT, league TEXT, tip_at TEXT,
          home_titan_team_id TEXT, away_titan_team_id TEXT, home_name TEXT, away_name TEXT,
          home_score INTEGER, away_score INTEGER, half_home INTEGER, half_away INTEGER,
          periods_home_json TEXT, periods_away_json TEXT, match_kind INTEGER,
          source_state INTEGER, status TEXT, source_snapshot_id TEXT, updated_at TEXT);
        CREATE TABLE IF NOT EXISTS box_score(
          titan_match_id TEXT PRIMARY KEY, home_json TEXT, away_json TEXT,
          pace_level TEXT, pace_source TEXT, possessions REAL, formula TEXT,
          source_snapshot_id TEXT, updated_at TEXT);
        CREATE TABLE IF NOT EXISTS capture_run(
          run_id TEXT PRIMARY KEY, started_at TEXT, finished_at TEXT, requested_team_count INTEGER,
          mapped_team_count INTEGER, schedule_row_count INTEGER, box_score_count INTEGER,
          history_row_count INTEGER, status TEXT, audit_json TEXT);
        """)
        self.db.commit()

    def snapshot(self, url, blob, content_type, entity_type, entity_id, captured_at):
        digest = _sha(blob)
        folder = self.raw_root / captured_at[:10].replace("-", "")
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / f"{entity_type}_{entity_id}_{digest[:16]}.raw"
        if not path.exists():
            path.write_bytes(blob)
        elif path.read_bytes() != blob:
            raise ValueError("IMMUTABLE_RAW_SNAPSHOT_CONFLICT")
        snapshot_id = digest[:24]
        self.db.execute("INSERT OR IGNORE INTO source_snapshot VALUES(?,?,?,?,?,?,?,?,?)",
                        (snapshot_id, url, captured_at, digest, len(blob), content_type,
                         str(path), entity_type, str(entity_id)))
        return snapshot_id, str(path), digest

    def close(self):
        self.db.commit()
        self.db.close()


def _fetch(item, timeout=20):
    key, url, referer = item
    captured_at = _stamp()
    if curl_requests is None:
        return {"key": key, "url": url, "ok": False, "captured_at": captured_at,
                "error": "CURL_CFFI_NOT_INSTALLED"}
    last = None
    for attempt in range(2):
        try:
            response = curl_requests.get(url, impersonate="chrome", timeout=timeout,
                                         headers={"Referer": referer, "Accept-Language": "zh-CN,zh;q=0.9"})
            blob = bytes(response.content)
            if response.status_code != 200:
                raise ValueError(f"HTTP_{response.status_code}")
            if not blob or len(blob) > MAX_BYTES:
                raise ValueError("EMPTY_OR_OVERSIZE_RESPONSE")
            return {"key": key, "url": url, "ok": True, "captured_at": captured_at,
                    "status": response.status_code, "content_type": response.headers.get("content-type"),
                    "blob": blob, "text": blob.decode("utf-8-sig", "strict")}
        except Exception as exc:  # exact failure retained in source health
            last = exc
            if attempt == 0:
                time.sleep(0.15)
    return {"key": key, "url": url, "ok": False, "captured_at": captured_at,
            "error": type(last).__name__ + ": " + str(last)}


def _batch(items, workers=4, timeout=20):
    with ThreadPoolExecutor(max_workers=max(1, min(6, int(workers)))) as pool:
        return list(pool.map(lambda item: _fetch(item, timeout), items))


def update_history_database(events, root, cutoff=None, years=None, boxscore_limit=10, workers=4):
    """Incrementally capture relevant teams and return verified fallback facts."""
    cutoff_dt = cutoff if isinstance(cutoff, datetime) else datetime.fromisoformat(str(cutoff).replace("Z", "+00:00")) if cutoff else datetime.now(timezone.utc)
    if cutoff_dt.tzinfo is None:
        cutoff_dt = cutoff_dt.replace(tzinfo=timezone.utc)
    years = list(dict.fromkeys(years or [cutoff_dt.astimezone(BJ).year, cutoff_dt.astimezone(BJ).year - 1]))
    store = TitanHistoryStore(root)
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S") + "_" + hashlib.sha256(str(time.time_ns()).encode()).hexdigest()[:8]
    started = _stamp()
    health, errors = [], []
    teams = {}
    event_teams = {}
    for event in events:
        for side in ("team1", "team2"):
            canonical = str(event.get(side + "_id") or "")
            name = str(event.get(side + "_name") or "").strip()
            if not canonical or not name:
                continue
            teams.setdefault(canonical, {"canonical_team_id": canonical, "name": name,
                                         "league": event.get("league")})
            event_teams.setdefault(event.get("event_id"), {})[side] = canonical
    try:
        search_items = []
        for canonical, team in teams.items():
            team["search_name"] = _search_name(team["name"])
            url = f"{BASE}/cn/aspx/Search_Team.aspx?str1={quote(team['search_name'])}"
            search_items.append(("search:" + canonical, url, BASE + "/index_cn.htm"))
        mappings = {}
        for row in _batch(search_items, workers):
            health.append({k: v for k, v in row.items() if k not in ("blob", "text")})
            canonical = row["key"].split(":", 1)[1]
            if not row.get("ok"):
                result = {"query": teams[canonical]["name"], "candidates": [], "exact": None, "status": "FETCH_FAILED"}
            else:
                store.snapshot(row["url"], row["blob"], row.get("content_type"), "team_search", canonical, row["captured_at"])
                result = parse_search_response(row["text"], teams[canonical]["search_name"])
            titan_id = result["exact"]["team_id"] if result.get("exact") else None
            mappings[canonical] = titan_id
            store.db.execute("INSERT OR REPLACE INTO team_mapping VALUES(?,?,?,?,?,?)",
                             (canonical, teams[canonical]["name"], titan_id, result["status"],
                              json.dumps(result["candidates"], ensure_ascii=False), row["captured_at"]))

        titan_to_canonical = {tid: cid for cid, tid in mappings.items() if tid}
        detail_items = [("detail:" + tid, f"{BASE}/jsData/teamInfo/teamDetail/td{tid}.js",
                         f"{BASE}/cn/Team/Summary.aspx?TeamID={tid}") for tid in sorted(set(titan_to_canonical))]
        details = {}
        for row in _batch(detail_items, workers):
            health.append({k: v for k, v in row.items() if k not in ("blob", "text")})
            if not row.get("ok"):
                continue
            tid = row["key"].split(":", 1)[1]
            snap, _, _ = store.snapshot(row["url"], row["blob"], row.get("content_type"), "team_detail", tid, row["captured_at"])
            try:
                detail = parse_team_detail(row["text"]); details[tid] = detail
                store.db.execute("INSERT OR REPLACE INTO team VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                                 (tid, detail["name_zh"], detail["name_tw"], detail["name_en"],
                                  detail["league_id"], detail["league_name"], detail["season"],
                                  detail["source_last_update"], snap,
                                  json.dumps(detail["roster"], ensure_ascii=False), row["captured_at"]))
                for alias in detail["aliases"]:
                    store.db.execute("INSERT OR IGNORE INTO team_alias VALUES(?,?,?,?,?)",
                                     (tid, alias, _token(alias), row["captured_at"], snap))
            except Exception as exc:
                errors.append({"key": row["key"], "error": str(exc)})

        schedule_items = []
        for tid in sorted(set(titan_to_canonical)):
            for year in years:
                url = f"{BASE}/cn/Team/TeamScheAjax.aspx?TeamID={tid}&y={int(year)}"
                schedule_items.append((f"schedule:{tid}:{year}", url,
                                       f"{BASE}/cn/Team/TeamSche.aspx?TeamID={tid}"))
        matches = {}
        match_snapshots = {}
        for row in _batch(schedule_items, workers):
            health.append({k: v for k, v in row.items() if k not in ("blob", "text")})
            if not row.get("ok"):
                continue
            _, tid, year = row["key"].split(":")
            snap, _, _ = store.snapshot(row["url"], row["blob"], row.get("content_type"), "team_schedule", tid + "_" + year, row["captured_at"])
            try:
                for match in parse_team_schedule(row["text"]):
                    matches[match["match_id"]] = match
                    match_snapshots[match["match_id"]] = snap
            except Exception as exc:
                errors.append({"key": row["key"], "error": str(exc)})

        selected = set()
        for tid in titan_to_canonical:
            candidates = [m for m in matches.values() if m["status"] == "FINAL" and
                          tid in (m["home_team_id"], m["away_team_id"]) and
                          datetime.fromisoformat(m["tip_at"]) < cutoff_dt]
            candidates.sort(key=lambda item: item["tip_at"], reverse=True)
            selected.update(m["match_id"] for m in candidates[:max(0, int(boxscore_limit))])
        tech_data, period_data, tech_snapshots, period_snapshots = {}, {}, {}, {}
        cache_hits = {"period": 0, "box_score": 0}
        for mid in sorted(selected):
            cached_match = store.db.execute(
                "SELECT periods_home_json,periods_away_json,half_home,half_away,home_score,away_score "
                "FROM match_history WHERE titan_match_id=?", (mid,)).fetchone()
            if cached_match and cached_match[0] and cached_match[1]:
                cached_home_periods = json.loads(cached_match[0])
                cached_away_periods = json.loads(cached_match[1])
                if isinstance(cached_home_periods, list) and isinstance(cached_away_periods, list):
                    period_data[mid] = {"home_periods": cached_home_periods,
                                        "away_periods": cached_away_periods,
                                        "half_home": cached_match[2], "half_away": cached_match[3],
                                        # Recompute from the period evidence.  Never
                                        # copy the schedule final into the validator.
                                        "home_score": sum(cached_home_periods),
                                        "away_score": sum(cached_away_periods)}
                    cache_hits["period"] += 1
                    snap = store.db.execute(
                        "SELECT snapshot_id,raw_path,sha256,captured_at FROM source_snapshot "
                        "WHERE entity_type='period' AND entity_id=? ORDER BY captured_at DESC LIMIT 1", (mid,)).fetchone()
                    if snap:
                        period_snapshots[mid] = snap
            cached_box = store.db.execute(
                "SELECT home_json,away_json,pace_level,pace_source,possessions,formula,source_snapshot_id,updated_at "
                "FROM box_score WHERE titan_match_id=?", (mid,)).fetchone()
            if cached_box:
                tech_data[mid] = {"home": json.loads(cached_box[0]), "away": json.loads(cached_box[1]),
                                  "team_ids": [], "pace_level": cached_box[2], "pace_source": cached_box[3],
                                  "game_possessions_estimate": cached_box[4], "formula": cached_box[5]}
                snap = store.db.execute(
                    "SELECT snapshot_id,raw_path,sha256,captured_at FROM source_snapshot WHERE snapshot_id=?",
                    (cached_box[6],)).fetchone()
                if snap:
                    tech_snapshots[mid] = snap
                cache_hits["box_score"] += 1
        tech_items = []
        for mid in sorted(selected):
            if mid not in tech_data:
                tech_items.append(("tech:" + mid, _tech_url(mid), f"{BASE}/cn/Tech/TechTxtLive.aspx?matchid={mid}"))
            if mid not in period_data:
                tech_items.append(("period:" + mid, f"{BASE}/cn/Tech/TechTxtLive.aspx?matchid={mid}",
                                   f"{BASE}/analysis/{mid}.htm"))
        for row in _batch(tech_items, workers):
            health.append({k: v for k, v in row.items() if k not in ("blob", "text")})
            if not row.get("ok"):
                continue
            kind, mid = row["key"].split(":")
            snap, path, digest = store.snapshot(row["url"], row["blob"], row.get("content_type"), kind, mid, row["captured_at"])
            try:
                if kind == "tech":
                    tech_data[mid] = parse_box_score_blob(row["text"])
                    tech_snapshots[mid] = (snap, path, digest, row["captured_at"])
                else:
                    period_data[mid] = parse_period_scores(row["text"])
                    period_snapshots[mid] = (snap, path, digest, row["captured_at"])
            except Exception as exc:
                errors.append({"key": row["key"], "error": str(exc)})

        history_rows, box_score_games, invalid_periods = [], [], set()
        for mid, match in matches.items():
            period = period_data.get(mid)
            if match["status"] != "FINAL" or not period:
                continue
            if period["home_score"] != match["home_score"] or period["away_score"] != match["away_score"]:
                errors.append({"key": "match:" + mid, "error": "SCHEDULE_PERIOD_SCORE_CONFLICT"})
                invalid_periods.add(mid)
                continue
            home_periods, away_periods = period["home_periods"], period["away_periods"]
            if len(home_periods) < 4 or len(away_periods) < 4:
                continue
            home_id = titan_to_canonical.get(match["home_team_id"], "titan-team:" + match["home_team_id"])
            away_id = titan_to_canonical.get(match["away_team_id"], "titan-team:" + match["away_team_id"])
            source_snap = period_snapshots.get(mid)
            known_at = source_snap[3] if source_snap else started
            row = {"event_id": "titan:" + mid, "source_event_id": mid, "tip_at": match["tip_at"],
                   "status": "FINAL", "competition_id": None,
                   "competition_key": competition_key(match["league"]),
                   "competition_identity_level": "CANONICAL_SOURCE_LABEL", "league": match["league"],
                   "team1_id": home_id, "team2_id": away_id, "team1_name": match["home_name"],
                   "team2_name": match["away_name"], "gender": "WOMEN" if "女" in match["league"] + match["home_name"] + match["away_name"] else "MEN",
                   "format_id": "BASKETBALL", "period_count": len(home_periods),
                   "period_points_team1": home_periods, "period_points_team2": away_periods,
                   "score1_regulation": sum(home_periods[:4]), "score2_regulation": sum(away_periods[:4]),
                   "score1_full": sum(home_periods), "score2_full": sum(away_periods),
                   "ot_points1": sum(home_periods[4:]), "ot_points2": sum(away_periods[4:]),
                   "score_basis": "TITAN_PERIOD_TABLE", "known_final_at": known_at,
                   "evidence_kind": "TEAM_HISTORY", "source_url": f"{BASE}/cn/Tech/TechTxtLive.aspx?matchid={mid}",
                   "raw_path": source_snap[1] if source_snap else None,
                   "raw_sha256": source_snap[2] if source_snap else None,
                   "source_variable": "teamPageData+scoreData", "source_schema": "TITAN_TEAM_SCHE_TECH_V1",
                   "source_status": match["source_state"], "home_sign": 0,
                   "home_adjustment_assumption": "UNVERIFIED_NO_HOME_ADJUSTMENT"}
            history_rows.append(row)
            box = tech_data.get(mid)
            if box:
                box_snap = tech_snapshots.get(mid)
                box_score_games.append({"event_id": row["event_id"], "tip_at": row["tip_at"],
                                        "team_ids": [home_id, away_id], "teams": [box["home"], box["away"]],
                                        "pace_level": box["pace_level"], "pace_source": box["pace_source"],
                                        "possessions_per_game": box["game_possessions_estimate"],
                                        "source_url": _tech_url(mid),
                                        "known_at": box_snap[3] if box_snap else known_at})

        for mid, match in matches.items():
            period = {} if mid in invalid_periods else (period_data.get(mid) or {})
            store.db.execute("INSERT OR REPLACE INTO match_history VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                             (mid, match["league_id"], match["league"], match["tip_at"], match["home_team_id"],
                              match["away_team_id"], match["home_name"], match["away_name"], match["home_score"],
                              match["away_score"], match["half_home"], match["half_away"],
                              json.dumps(period.get("home_periods"), ensure_ascii=False),
                              json.dumps(period.get("away_periods"), ensure_ascii=False), match["match_kind"],
                              match["source_state"], match["status"],
                              (period_snapshots.get(mid) or (match_snapshots.get(mid),))[0], started))
        for mid, box in tech_data.items():
            snap = tech_snapshots[mid][0]
            store.db.execute("INSERT OR REPLACE INTO box_score VALUES(?,?,?,?,?,?,?,?,?)",
                             (mid, json.dumps(box["home"], ensure_ascii=False), json.dumps(box["away"], ensure_ascii=False),
                              box["pace_level"], box["pace_source"], box["game_possessions_estimate"], box["formula"], snap, started))
        mapping_status_counts = Counter()
        for canonical in mappings:
            row = store.db.execute(
                "SELECT status FROM team_mapping WHERE canonical_team_id=? ORDER BY observed_at DESC LIMIT 1",
                (canonical,)).fetchone()
            mapping_status_counts[row[0] if row else "UNKNOWN"] += 1
        pace_levels = Counter(box.get("pace_level") or "UNKNOWN" for box in tech_data.values())
        fetch_failures = Counter(row["key"].split(":", 1)[0] for row in health if not row.get("ok"))
        audit = {"run_id": run_id, "requested_teams": len(teams),
                 "mapped_teams": sum(v is not None for v in mappings.values()), "years": years,
                 "mapping_status_counts": dict(mapping_status_counts), "detailed_teams": len(details),
                 "schedule_rows": len(matches), "selected_box_score_matches": len(selected),
                 "box_scores": len(tech_data), "history_rows": len(history_rows), "errors": errors,
                 "pace_level_counts": dict(pace_levels), "cache_hits": cache_hits,
                 "network_fetch_failures_by_stage": dict(fetch_failures),
                 "market_history_used_in_model": False,
                 "provisional_or_qualified_ledger_modified": False}
        finished = _stamp()
        store.db.execute("INSERT OR REPLACE INTO capture_run VALUES(?,?,?,?,?,?,?,?,?,?)",
                         (run_id, started, finished, len(teams), audit["mapped_teams"], len(matches),
                          len(tech_data), len(history_rows), "OK" if not errors else "PARTIAL", json.dumps(audit, ensure_ascii=False)))
        store.db.commit()
        audit_path = Path(root) / "latest_audit.json"
        audit_path.write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")
        return {"database": str(store.db_path), "audit_path": str(audit_path), "mappings": mappings,
                "history_rows": history_rows, "box_score_games": box_score_games,
                "source_health": health, "audit": audit}
    finally:
        store.close()
